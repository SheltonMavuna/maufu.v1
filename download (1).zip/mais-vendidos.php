<?php
/**
 * MAUFU PEÇAS — EXPLORAR ELITE V4 (RED EDITION)
 * Design ultra-responsivo com identidade visual em Vermelho.
 */

$destaques = [
    [
        'titulo' => 'Linha Scania',
        'sub'    => 'Performance Pesada',
        'imagens' => ['img/Montagem de faróis de automóvel.png', 'img/Componentes de embraiagem desgastados.png'],
        'classe'  => 'bento-big',
        'link'    => 'catalogo.php?marca=scania'
    ],
    [
        'titulo' => 'Linha Volvo',
        'sub'    => 'Segurança Original',
        'imagens' => ['img/p3.png', 'img/Cilindros de embraiagem em detalhe.png'],  // ← era Unsplash, agora local
        'classe'  => 'bento-sm',
        'link'    => 'catalogo.php?marca=volvo'
    ],
    [
        'titulo' => 'Turbos Iveco',
        'sub'    => 'Potência Máxima',
        'imagens' => ['img/p2.png'],
        'classe'  => 'bento-sm',
        'link'    => 'catalogo.php?marca=iveco'
    ],
    [
        'titulo' => 'Travagem',
        'sub'    => 'Certificação Europeia',
        'imagens' => ['img/p1.png'],                // ← era Unsplash, agora local
        'classe'  => 'bento-wide',
        'link'    => 'catalogo.php?categoria=travagem'
    ],
];
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

<style>
    :root {
        --maufu-red: #dc2626;
        --maufu-red-dark: #991b1b;
        --maufu-dark: #0f172a;
        --radius-lg: 40px;
        --transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .explorar-v4 {
        padding: 80px 5%;
        background-color: #f8fafc;
    }

    .section-header {
        max-width: 1200px;
        margin: 0 auto 40px;
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
    }

    .section-header h2 {
        font-size: clamp(1.5rem, 4vw, 2.5rem);
        font-weight: 900;
        color: var(--maufu-dark);
        letter-spacing: -1.5px;
        line-height: 1;
    }

    /* Bento Grid Responsivo */
    .bento-grid {
        max-width: 1200px;
        margin: 0 auto;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        grid-auto-rows: 240px;
        gap: 20px;
    }

    .bento-item {
        position: relative;
        border-radius: var(--radius-lg);
        overflow: hidden;
        background: #e2e8f0;
        cursor: pointer;
        transition: var(--transition);
        box-shadow: 0 10px 30px -10px rgba(0,0,0,0.1);
    }

    /* Variações de Tamanho */
    .bento-big  { grid-column: span 1; grid-row: span 2; }
    .bento-wide { grid-column: span 2; grid-row: span 1; }
    .bento-sm   { grid-column: span 1; grid-row: span 1; }

    /* Swiper Engine */
    .swiper { width: 100%; height: 100%; }
    .swiper-slide img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.8s ease;
    }

    /* Paginação Customizada em Vermelho */
    .swiper-pagination-bullets { bottom: 20px !important; }
    .swiper-pagination-bullet {
        background: #fff !important;
        width: 12px;
        height: 3px;
        border-radius: 2px;
        opacity: 0.4;
        transition: 0.3s;
    }
    .swiper-pagination-bullet-active {
        width: 24px;
        opacity: 1 !important;
        background: var(--maufu-red) !important;
    }

    /* Overlays */
    .overlay-static {
        position: absolute;
        inset: 0;
        background: linear-gradient(to top, rgba(15, 23, 42, 0.85) 0%, transparent 60%);
        padding: 30px;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        z-index: 10;
        pointer-events: none;
        transition: var(--transition);
    }

    .overlay-static h3 {
        color: #fff;
        font-size: 1.2rem;
        font-weight: 800;
        text-transform: uppercase;
    }
    .overlay-static p {
        color: rgba(255,255,255,0.7);
        font-size: 0.8rem;
        font-weight: 500;
    }

    /* Camada Interativa "Ver Mais" em Vermelho */
    .overlay-hover {
        position: absolute;
        inset: 0;
        background: rgba(220, 38, 38, 0.9);
        backdrop-filter: blur(10px);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        opacity: 0;
        z-index: 20;
        transition: var(--transition);
        transform: translateY(100%);
    }

    .btn-circle {
        width: 60px;
        height: 60px;
        background: #fff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 15px;
        color: var(--maufu-red);
        font-size: 1.5rem;
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }

    .overlay-hover span {
        color: #fff;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 2px;
        font-size: 0.75rem;
    }

    /* Estados de Hover */
    .bento-item:hover { transform: scale(0.97); box-shadow: 0 20px 40px -10px rgba(220, 38, 38, 0.3); }
    .bento-item:hover .swiper-slide img { transform: scale(1.1); }
    .bento-item:hover .overlay-static { opacity: 0; }
    .bento-item:hover .overlay-hover { opacity: 1; transform: translateY(0); }

    /* Link de cabeçalho */
    .btn-view-all {
        color: var(--maufu-red);
        font-weight: 800;
        text-decoration: none;
        border-bottom: 2px solid transparent;
        padding-bottom: 5px;
        transition: 0.3s;
    }
    .btn-view-all:hover { border-color: var(--maufu-red); }

    @media (max-width: 1024px) {
        .bento-grid { grid-template-columns: repeat(2, 1fr); grid-auto-rows: 220px; }
        .bento-big  { grid-row: span 2; }
        .bento-wide { grid-column: span 2; }
    }

    @media (max-width: 768px) {
        .explorar-v4 { padding: 40px 20px; }
        .bento-grid { grid-template-columns: 1fr; grid-auto-rows: 280px; }
        .bento-big, .bento-wide, .bento-sm { grid-column: span 1; grid-row: span 1; }
        :root { --radius-lg: 30px; }
        .section-header { flex-direction: column; align-items: flex-start; gap: 15px; }
    }
</style>

<section id="explorar" class="explorar-v4">
    <div class="section-header">
        <div>
            <p style="color: var(--maufu-red); font-weight: 900; text-transform: uppercase; letter-spacing: 3px; font-size: 0.7rem; margin-bottom: 10px;">Stock Em Destaque</p>
            <h2>Explorar Categorias</h2>
        </div>
        <a href="catalogo.php" class="btn-view-all">Ver Tudo <i class="fa-solid fa-arrow-right"></i></a>
    </div>

    <div class="bento-grid">
        <?php foreach ($destaques as $index => $item): ?>
            <div class="bento-item <?= htmlspecialchars($item['classe']) ?>"
                 onclick="window.location.href='<?= htmlspecialchars($item['link']) ?>'"
                 data-swiper-index="<?= $index ?>">

                <!-- ✅ CORRIGIDO: class única por item via data-index -->
                <div class="swiper explorerSwiper-<?= $index ?>">
                    <div class="swiper-wrapper">
                        <?php foreach ($item['imagens'] as $img): ?>
                            <div class="swiper-slide">
                                <img src="<?= htmlspecialchars($img) ?>" loading="lazy" alt="<?= htmlspecialchars($item['titulo']) ?>">
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (count($item['imagens']) > 1): ?>
                        <div class="swiper-pagination"></div>
                    <?php endif; ?>
                </div>

                <div class="overlay-static">
                    <p><?= htmlspecialchars($item['sub']) ?></p>
                    <h3><?= htmlspecialchars($item['titulo']) ?></h3>
                </div>

                <div class="overlay-hover">
                    <div class="btn-circle">
                        <i class="fa-solid fa-plus"></i>
                    </div>
                    <span>Ver Detalhes</span>
                </div>

            </div>
        <?php endforeach; ?>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // ✅ CORRIGIDO: inicializa cada swiper individualmente pela sua classe única
        const totalItems = <?= count($destaques) ?>;

        for (let i = 0; i < totalItems; i++) {
            const el = document.querySelector('.explorerSwiper-' + i);
            if (!el) continue;

            // Só ativa autoplay e paginação se houver mais de 1 slide
            const slides = el.querySelectorAll('.swiper-slide');
            const hasMultiple = slides.length > 1;

            new Swiper('.explorerSwiper-' + i, {
                loop: hasMultiple,
                effect: 'fade',
                fadeEffect: { crossFade: true },
                speed: 800,
                autoplay: hasMultiple ? {
                    delay: 3500,
                    disableOnInteraction: false,
                } : false,
                pagination: hasMultiple ? {
                    el: el.querySelector('.swiper-pagination'),
                    clickable: true,
                } : false,
                touchEventsTarget: 'container',
                grabCursor: true,
            });
        }
    });
</script>