<?php
/**
 * MAUFU LOGISTICS OS V3.1 - LIGHT EDITION
 */

$host = "sql100.infinityfree.com";
$user = "if0_40911457";
$pass = "tuLX88H1Oqp";
$db   = "if0_40911457_maufu";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Erro de Conexão: " . $conn->connect_error);
}

/* ── ENCODING FIX ─────────────────────────────────────
   Os dados na BD estão em latin1/ISO-8859-1.
   Não alteramos o charset da conexão — convertemos
   manualmente com mb_convert_encoding ao ler.
   ─────────────────────────────────────────────────── */
function toUtf8(string $str): string {
    // Se já é UTF-8 válido, devolve como está
    if (mb_check_encoding($str, 'UTF-8')) return $str;
    return mb_convert_encoding($str, 'UTF-8', 'ISO-8859-1');
}

if (!is_dir('uploads')) { mkdir('uploads', 0777, true); }

if (isset($_POST['add_product'])) {
    $nome      = mysqli_real_escape_string($conn, $_POST['nome']);
    $codigo    = mysqli_real_escape_string($conn, $_POST['codigo']);
    $marca     = mysqli_real_escape_string($conn, $_POST['marca']);
    $descricao = mysqli_real_escape_string($conn, $_POST['descricao']);

    $imagens_caminhos = [];
    if (!empty($_FILES['imagens']['name'][0])) {
        foreach ($_FILES['imagens']['tmp_name'] as $key => $tmp_name) {
            $file_name = time() . "_" . basename($_FILES['imagens']['name'][$key]);
            $location  = "uploads/" . $file_name;
            if (move_uploaded_file($tmp_name, $location)) {
                $imagens_caminhos[] = $location;
            }
        }
    }
    $imgs = implode(",", $imagens_caminhos);
    $sql  = "INSERT INTO produtos (nome, codigo, marca, descricao, imagem_url) VALUES ('$nome', '$codigo', '$marca', '$descricao', '$imgs')";
    if ($conn->query($sql)) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?success=true");
        exit();
    }
}

$pecas = $conn->query("SELECT * FROM produtos ORDER BY id DESC LIMIT 2000");
$produtos_json = [];
while ($row = $pecas->fetch_assoc()) {
    $fotos        = explode(",", $row['imagem_url']);
    $primeira_foto = !empty($fotos[0]) ? $fotos[0]
        : 'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&q=80&w=600';

    $nome_utf8      = toUtf8($row['nome']);
    $marca_utf8     = toUtf8($row['marca']);
    $descricao_utf8 = toUtf8($row['descricao']);

    $produtos_json[] = [
        'id'       => $row['id'],
        'name'     => mb_strtoupper($nome_utf8,  'UTF-8'),
        'code'     => $row['codigo'],
        'brand'    => mb_strtoupper($marca_utf8, 'UTF-8'),
        'desc'     => $descricao_utf8,
        'price'    => 0,
        'img'      => $primeira_foto,
    ];
}
?>
<!DOCTYPE html>
<html lang="pt-pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maufu Peças, Lda | Qualidade Sem Compromisso</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Barlow:ital,wght@0,400;0,500;0,600;0,700;0,900;1,400;1,700&family=Barlow+Condensed:ital,wght@0,400;0,600;0,700;1,600;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
/* ===== RESET & TOKENS ===== */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

:root{
    --white:     #ffffff;
    --off:       #f6f7f9;
    --off2:      #edeef2;
    --border:    #e0e3eb;
    --red:       #e8162e;
    --red-light: #fff1f2;
    --red-mid:   #fecdd3;
    --red-dim:   rgba(232,22,46,0.07);
    --red-glow:  rgba(232,22,46,0.22);
    --ink:       #181c28;
    --muted:     #7a8190;
    --wa:        #25D366;
    --wa-dim:    rgba(37,211,102,0.1);
    --font-d:    'Bebas Neue', sans-serif;
    --font-b:    'Barlow', sans-serif;
    --font-c:    'Barlow Condensed', sans-serif;
    --nav-h:     70px;
    --sh-sm:     0 2px 8px rgba(0,0,0,0.06);
    --sh-md:     0 6px 22px rgba(0,0,0,0.08);
    --sh-lg:     0 18px 44px rgba(0,0,0,0.1);
    --sh-red:    0 10px 28px -4px rgba(232,22,46,0.3);
    --sh-wa:     0 10px 28px -4px rgba(37,211,102,0.35);
}

html{scroll-behavior:smooth}
body{font-family:var(--font-b);background:var(--off);color:var(--ink);overflow-x:hidden;-webkit-font-smoothing:antialiased}
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:var(--off2)}
::-webkit-scrollbar-thumb{background:var(--red);border-radius:4px}

/* ===== SPLASH ===== */
#splash{position:fixed;inset:0;z-index:9999;background:var(--white);display:flex;flex-direction:column;align-items:center;justify-content:center;transition:opacity .8s ease,transform .8s ease}
#splash.hidden{opacity:0;transform:scale(1.03);pointer-events:none}
.sp-ring{width:88px;height:88px;border-radius:26px;background:var(--off);border:1.5px solid var(--border);display:flex;align-items:center;justify-content:center;padding:15px;margin-bottom:22px;box-shadow:0 0 0 10px var(--red-dim),var(--sh-md);animation:spBreath 2s ease-in-out infinite}
@keyframes spBreath{0%,100%{box-shadow:0 0 0 10px var(--red-dim),var(--sh-md)}50%{box-shadow:0 0 0 18px rgba(232,22,46,.03),var(--sh-md)}}
.sp-ring img{width:100%;object-fit:contain}
.sp-lbl{font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.45em;text-transform:uppercase;color:var(--muted);margin-bottom:22px}
.sp-bar{width:110px;height:2px;background:var(--off2);border-radius:4px;overflow:hidden;position:relative}
.sp-fill{position:absolute;height:100%;width:45%;background:var(--red);border-radius:4px;animation:spSlide 1.1s ease-in-out infinite}
@keyframes spSlide{0%{left:-50%}100%{left:110%}}

/* ===== NAV ===== */
nav{position:fixed;top:0;left:0;right:0;z-index:1000;height:var(--nav-h);background:rgba(255,255,255,.92);backdrop-filter:blur(22px) saturate(180%);-webkit-backdrop-filter:blur(22px) saturate(180%);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 clamp(14px,4vw,40px)}
.nav-inner{width:100%;max-width:1400px;margin:0 auto;display:flex;align-items:center}
.nav-logo{display:flex;align-items:center;gap:10px;text-decoration:none;flex-shrink:0;margin-right:26px}
.nav-logo img{height:35px;width:auto;object-fit:contain}
.nav-logo-text{display:flex;flex-direction:column;line-height:1}
.nav-logo-text .t1{font-family:var(--font-d);font-size:19px;letter-spacing:.05em;color:var(--ink)}
.nav-logo-text .t2{font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:var(--red)}
.nav-links{display:none;padding-left:18px;border-left:1px solid var(--border);margin-left:4px}
@media(min-width:1024px){.nav-links{display:flex}}
.nav-links a{font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:var(--muted);text-decoration:none;padding:7px 11px;border-radius:8px;transition:color .2s,background .2s}
.nav-links a:hover{color:var(--red);background:var(--red-dim)}
.nav-right{margin-left:auto;display:flex;align-items:center;gap:8px}
.nav-sw{display:none;align-items:center;background:var(--off);border:1.5px solid var(--border);border-radius:10px;padding:0 13px;height:40px;min-width:200px;transition:border-color .2s,box-shadow .2s}
@media(min-width:640px){.nav-sw{display:flex}}
.nav-sw:focus-within{border-color:var(--red);box-shadow:0 0 0 3px var(--red-dim)}
.nav-sw i{color:var(--muted);font-size:12px;flex-shrink:0}
.nav-sw input{background:transparent;border:none;outline:none;color:var(--ink);font-family:var(--font-b);font-size:13px;font-weight:500;width:100%;padding:0 9px}
.nav-sw input::placeholder{color:var(--muted)}
.btn-ico{width:40px;height:40px;border-radius:10px;background:var(--off);border:1.5px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:14px;cursor:pointer;transition:all .2s;text-decoration:none}
.btn-ico:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}
.msrch-btn{display:flex}
@media(min-width:640px){.msrch-btn{display:none}}
.call-btn{display:flex;align-items:center;gap:7px;background:var(--red);color:var(--white);border:none;border-radius:10px;padding:0 15px;height:40px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;cursor:pointer;transition:background .2s,transform .15s;box-shadow:var(--sh-red);text-decoration:none}
.call-btn:hover{background:#c2001f;transform:translateY(-1px)}
.call-btn:active{transform:scale(.97)}
.call-btn .lbl{display:none}
@media(min-width:768px){.call-btn .lbl{display:inline}}

/* ===== MOBILE SEARCH ===== */
.msrch-bar{position:fixed;top:var(--nav-h);left:0;right:0;z-index:990;background:var(--white);border-bottom:1px solid var(--border);padding:11px 15px;transform:translateY(-110%);transition:transform .3s ease}
.msrch-bar.open{transform:translateY(0)}
.msrch-bar input{width:100%;background:var(--off);border:1.5px solid var(--border);border-radius:10px;color:var(--ink);font-family:var(--font-b);font-size:15px;font-weight:500;padding:11px 15px;outline:none}
.msrch-bar input:focus{border-color:var(--red)}

/* ===== HERO ===== */
.hero{margin-top:var(--nav-h);position:relative;overflow:hidden;background:#0d1117}
.h-slide{display:none;position:relative;min-height:clamp(400px,62vw,660px);overflow:hidden}
.h-slide.active{display:block}
.h-bg{position:absolute;inset:0;background-size:cover;background-position:center;transform:scale(1.05);animation:kBurns 8s ease forwards}
@keyframes kBurns{to{transform:scale(1)}}
.h-ov{position:absolute;inset:0;background:linear-gradient(110deg,rgba(8,10,14,.84) 0%,rgba(8,10,14,.52) 45%,rgba(8,10,14,.15) 100%)}
.h-ov2{position:absolute;inset:0;background:linear-gradient(to right,transparent 50%,rgba(8,10,14,.25) 100%)}
.h-cnt{position:relative;z-index:2;max-width:1400px;margin:0 auto;padding:clamp(44px,7.5vw,86px) clamp(14px,4.5vw,56px);display:flex;flex-direction:column;justify-content:center;min-height:clamp(400px,62vw,660px)}
.h-inner{max-width:570px}
.slide-tag{display:inline-flex;align-items:center;gap:7px;border-radius:100px;padding:5px 13px 5px 8px;margin-bottom:18px;width:fit-content;font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.2em;text-transform:uppercase}
.slide-tag .td{width:6px;height:6px;border-radius:50%;animation:blink 1.5s infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}
.tag-red{background:rgba(232,22,46,.18);border:1px solid rgba(232,22,46,.35);color:#ff8091}
.tag-red .td{background:#ff8091}
.tag-blue{background:rgba(59,130,246,.18);border:1px solid rgba(59,130,246,.35);color:#93c5fd}
.tag-blue .td{background:#93c5fd}
.tag-green{background:rgba(34,197,94,.18);border:1px solid rgba(34,197,94,.35);color:#86efac}
.tag-green .td{background:#86efac}
.tag-amber{background:rgba(251,191,36,.18);border:1px solid rgba(251,191,36,.35);color:#fde68a}
.tag-amber .td{background:#fde68a}
.h-title{font-family:var(--font-d);font-size:clamp(48px,8vw,104px);line-height:.9;letter-spacing:.02em;color:#fff;margin-bottom:16px}
.h-title .r{color:var(--red)}
.h-title .b{color:#60a5fa}
.h-title .g{color:#34d399}
.h-title .a{color:#fbbf24}
.h-sub{font-size:clamp(13px,1.7vw,16px);font-weight:400;color:rgba(255,255,255,.6);line-height:1.75;margin-bottom:28px;max-width:420px}
.h-sub b{color:rgba(255,255,255,.9);font-weight:600}
.h-ctas{display:flex;align-items:center;gap:11px;flex-wrap:wrap}
.btn-hm{display:inline-flex;align-items:center;gap:8px;padding:13px 24px;border-radius:11px;font-family:var(--font-c);font-size:12px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;text-decoration:none;color:#fff;border:none;cursor:pointer;transition:transform .2s,box-shadow .2s,background .2s}
.btn-hm:hover{transform:translateY(-2px)}
.btn-hm.r{background:var(--red);box-shadow:var(--sh-red)}
.btn-hm.r:hover{background:#c2001f}
.btn-hm.b{background:#2563eb;box-shadow:0 10px 26px -4px rgba(37,99,235,.38)}
.btn-hm.b:hover{background:#1d4ed8}
.btn-hm.g{background:#16a34a;box-shadow:0 10px 26px -4px rgba(22,163,74,.38)}
.btn-hm.g:hover{background:#15803d}
.btn-hm.am{background:#d97706;box-shadow:0 10px 26px -4px rgba(217,119,6,.38)}
.btn-hm.am:hover{background:#b45309}
.btn-hg{display:inline-flex;align-items:center;gap:7px;padding:13px 18px;border-radius:11px;font-family:var(--font-c);font-size:12px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;text-decoration:none;color:rgba(255,255,255,.72);border:1px solid rgba(255,255,255,.2);transition:all .2s}
.btn-hg:hover{color:#fff;border-color:rgba(255,255,255,.48);background:rgba(255,255,255,.07)}

/* Hero thumbs */
.hero-thumbs{position:absolute;bottom:0;left:0;right:0;z-index:10;display:flex;border-top:1px solid rgba(255,255,255,.07)}
.hero-thumb{flex:1;position:relative;overflow:hidden;cursor:pointer;height:clamp(58px,9.5vw,96px);transition:flex .42s ease;border-right:1px solid rgba(255,255,255,.06)}
.hero-thumb:last-child{border-right:none}
.hero-thumb.active{flex:2.2}
.ht-bg{position:absolute;inset:0;background-size:cover;background-position:center;transition:transform .5s ease}
.hero-thumb:hover .ht-bg{transform:scale(1.06)}
.ht-ov{position:absolute;inset:0;background:rgba(8,10,14,.58);transition:background .3s}
.hero-thumb.active .ht-ov{background:rgba(8,10,14,.28)}
.ht-lbl{position:absolute;bottom:0;left:0;right:0;padding:7px 11px;background:linear-gradient(to top,rgba(0,0,0,.65),transparent);font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.75);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hero-thumb.active .ht-lbl{color:#fff}
.ht-bar{position:absolute;bottom:0;left:0;right:0;height:2px;background:rgba(255,255,255,.12);overflow:hidden}
.ht-prog{height:100%;background:var(--red);width:0}
.hero-thumb.active .ht-prog{animation:htProg 6.5s linear forwards}
@keyframes htProg{from{width:0}to{width:100%}}

/* ===== STATS BAR ===== */
.stats-bar{background:var(--ink);display:grid;grid-template-columns:repeat(2,1fr);padding:0 clamp(14px,4vw,56px)}
@media(min-width:768px){.stats-bar{grid-template-columns:repeat(4,1fr)}}
.stat-item{padding:clamp(16px,2.8vw,26px) 18px;border-right:1px solid rgba(255,255,255,.06);display:flex;flex-direction:column;gap:4px}
.stat-item:last-child{border-right:none}
.stat-val{font-family:var(--font-d);font-size:clamp(26px,3.8vw,42px);letter-spacing:.02em;color:#fff}
.stat-val span{color:var(--red)}
.stat-lbl{font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.24em;text-transform:uppercase;color:rgba(255,255,255,.33)}

/* ===== BRAND TICKER ===== */
.brand-ticker{background:var(--white);border-bottom:1px solid var(--border);overflow:hidden;position:relative}
.bt-track{display:flex;width:max-content;animation:btScroll 26s linear infinite}
.brand-ticker:hover .bt-track{animation-play-state:paused}
@keyframes btScroll{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
.brand-chip{display:flex;align-items:center;justify-content:center;padding:17px clamp(22px,3vw,42px);border-right:1px solid var(--border);font-family:var(--font-d);font-size:clamp(17px,2.2vw,25px);letter-spacing:.08em;color:#b0b8c8;text-decoration:none;white-space:nowrap;cursor:pointer;transition:color .25s,background .25s;min-width:130px}
.brand-chip:hover,.brand-chip.active{color:var(--red);background:var(--red-dim)}
.brand-ticker::before,.brand-ticker::after{content:'';position:absolute;top:0;bottom:0;z-index:1;width:56px;pointer-events:none}
.brand-ticker::before{left:0;background:linear-gradient(to right,var(--white),transparent)}
.brand-ticker::after{right:0;background:linear-gradient(to left,var(--white),transparent)}

/* ===== SECTION HEADERS ===== */
.s-eyebrow{font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.3em;text-transform:uppercase;color:var(--red);margin-bottom:9px;display:flex;align-items:center;gap:9px}
.s-eyebrow::before{content:'';width:20px;height:2px;background:var(--red);border-radius:2px;display:inline-block}
.s-title{font-family:var(--font-d);font-size:clamp(32px,5.2vw,65px);letter-spacing:.02em;line-height:.95;color:var(--ink)}
.s-title .ac{color:var(--red)}
.s-hdr{display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:clamp(26px,3.8vw,48px);gap:18px;flex-wrap:wrap}

/* ===== PRODUCTS SECTION ===== */
.prod-sec-wrap{background:linear-gradient(180deg,var(--off) 0%,var(--off2) 100%);position:relative}
.prod-sec-wrap::before{content:'';position:absolute;inset:0;background-image:linear-gradient(rgba(232,22,46,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(232,22,46,.04) 1px,transparent 1px);background-size:40px 40px;pointer-events:none}
.prod-sec{padding:clamp(50px,6.5vw,84px) clamp(14px,4vw,52px);max-width:1400px;margin:0 auto;position:relative;z-index:1}

/* ===== PRODUCT HEADER ===== */
.prod-hdr{display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:clamp(26px,3.8vw,48px);gap:18px;flex-wrap:wrap}
.prod-hdr-left{position:relative}
.prod-hdr-top-row{display:flex;align-items:center;gap:12px;margin-bottom:14px;flex-wrap:wrap}
.prod-eyebrow{display:inline-flex;align-items:center;gap:8px;font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.32em;text-transform:uppercase;color:var(--muted)}
.prod-eyebrow-line{display:flex;align-items:center;gap:4px}
.prod-eyebrow-line::before{content:'';width:18px;height:1.5px;background:linear-gradient(to right,var(--red),rgba(232,22,46,.3));border-radius:2px;display:inline-block}
.prod-eyebrow-line::after{content:'';width:6px;height:1.5px;background:rgba(232,22,46,.25);border-radius:2px;display:inline-block}
.prod-stock-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(74,222,128,.07);border:1px solid rgba(74,222,128,.2);border-radius:6px;padding:4px 11px 4px 8px;font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:#4ade80;position:relative;overflow:hidden}
.prod-stock-badge::after{content:'';position:absolute;top:0;left:-60%;width:40%;height:100%;background:linear-gradient(to right,transparent,rgba(74,222,128,.15),transparent);animation:badgeSweep 3s ease-in-out infinite}
@keyframes badgeSweep{0%,100%{left:-60%}50%{left:130%}}
.stock-dot{width:5px;height:5px;border-radius:50%;background:#4ade80;box-shadow:0 0 0 2px rgba(74,222,128,.2),0 0 8px rgba(74,222,128,.35);flex-shrink:0;animation:blink 1.8s infinite}
.prod-main-title{font-family:var(--font-d);font-size:clamp(38px,6vw,72px);letter-spacing:.025em;line-height:.9;color:var(--ink);position:relative;display:inline-block}
.prod-main-title .ac{color:var(--red);position:relative;display:inline-block}
.prod-main-title .ac::after{content:'';position:absolute;bottom:-4px;left:0;right:0;height:2px;background:linear-gradient(to right,var(--red),rgba(232,22,46,.3));border-radius:2px;transform:scaleX(0);transform-origin:left;animation:acUnderline 1s cubic-bezier(.34,1.3,.64,1) .5s forwards}
@keyframes acUnderline{to{transform:scaleX(1)}}
.prod-count-tag{display:inline-flex;flex-direction:column;align-items:center;justify-content:center;background:rgba(232,22,46,.08);border:1px solid rgba(232,22,46,.18);border-radius:8px;padding:8px 14px;min-width:52px;align-self:flex-end;margin-bottom:4px}
.prod-count-num{font-family:var(--font-d);font-size:22px;letter-spacing:.04em;color:var(--red);line-height:1}
.prod-count-lbl{font-family:var(--font-c);font-size:7px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:rgba(232,22,46,.5);margin-top:2px;white-space:nowrap}
.prod-title-row{display:flex;align-items:flex-end;gap:14px}
.prod-hdr-right{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.btn-shuffle{display:inline-flex;align-items:center;gap:7px;background:var(--white);border:1.5px solid var(--border);color:var(--muted);padding:9px 16px;border-radius:9px;font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;cursor:pointer;transition:all .22s}
.btn-shuffle:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}
.btn-shuffle i{transition:transform .4s ease}
.btn-shuffle:hover i{transform:rotate(180deg)}
.prod-hdr .btn-ghost{color:var(--muted);border-color:var(--border);background:var(--white)}
.prod-hdr .btn-ghost:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}

/* ===== PRODUCT GRID — grelha responsiva ===== */
.p-row{
    display:grid;
    gap:14px;
    grid-template-columns:repeat(2,1fr);
    margin-bottom:0;
}
@media(min-width:600px){.p-row{grid-template-columns:repeat(3,1fr)}}
@media(min-width:1024px){.p-row{grid-template-columns:repeat(5,1fr)}}
.p-row-gap{height:14px}
.p-scroll-hint{display:none}

/* ===== PRODUCT CARD ===== */
.p-card{background:var(--white);border:1.5px solid var(--border);border-radius:16px;overflow:hidden;display:flex;flex-direction:column;transition:transform .38s cubic-bezier(.34,1.3,.64,1),box-shadow .38s;position:relative;will-change:transform;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.05);width:100%}
.p-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--red);z-index:2;transform:scaleY(0);transform-origin:bottom;transition:transform .3s cubic-bezier(.34,1.3,.64,1)}
.p-card:hover::before{transform:scaleY(1)}
.p-card:hover{transform:translateY(-7px) scale(1.012);box-shadow:0 18px 40px -8px rgba(0,0,0,.12),0 0 0 1.5px var(--red-mid)}

/* Imagem */
.p-img{width:100%;aspect-ratio:4/3;overflow:hidden;position:relative;background:var(--off2);flex-shrink:0}
.p-img::before{content:'';position:absolute;inset:0;z-index:1;background-image:linear-gradient(rgba(232,22,46,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(232,22,46,.05) 1px,transparent 1px);background-size:24px 24px;pointer-events:none;opacity:0;transition:opacity .3s}
.p-card:hover .p-img::before{opacity:1}
.p-img::after{content:'';position:absolute;inset:0;z-index:1;background:linear-gradient(to bottom,transparent 45%,rgba(255,255,255,.55) 100%);pointer-events:none}
.p-img img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .55s cubic-bezier(.34,1,.64,1),filter .4s;filter:brightness(1) saturate(.9)}
.p-card:hover .p-img img{transform:scale(1.08);filter:brightness(1.04) saturate(1.1)}

/* Ações */
.p-actions{position:absolute;top:9px;right:9px;z-index:4;display:flex;flex-direction:column;gap:4px;opacity:0;transform:translateY(-6px);transition:opacity .2s,transform .2s;pointer-events:none}
.p-card:hover .p-actions{opacity:1;transform:translateY(0);pointer-events:auto}
.p-act-btn{width:28px;height:28px;border-radius:6px;background:rgba(255,255,255,.88);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:10px;color:var(--muted);cursor:pointer;transition:background .15s,color .15s,border-color .15s,transform .15s}
.p-act-btn:hover{background:var(--red);color:#fff;border-color:var(--red);transform:scale(1.1)}

/* Badge */
.p-badge{position:absolute;bottom:9px;left:9px;z-index:3;display:flex;align-items:center;gap:5px;background:rgba(255,255,255,.92);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);color:#4ade80;font-family:var(--font-c);font-size:7.5px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;padding:3px 8px 3px 6px;border-radius:4px;border:1px solid rgba(74,222,128,.22)}
.p-badge::before{content:'';width:4px;height:4px;border-radius:50%;background:#4ade80;box-shadow:0 0 0 2px rgba(74,222,128,.25);flex-shrink:0;animation:blink 1.8s infinite}

/* Corpo */
.p-body{padding:12px 13px 13px;flex:1;display:flex;flex-direction:column;background:transparent;position:relative}
.p-body::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(to right,var(--red),transparent 70%);opacity:.35}
.p-brand{font-family:var(--font-d);font-size:10px;letter-spacing:.22em;text-transform:uppercase;color:var(--red);margin-bottom:4px}
.p-name{font-family:var(--font-c);font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--ink);line-height:1.28;flex:1;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.p-code{font-size:9px;color:var(--muted);font-weight:600;font-family:'Courier New',monospace;letter-spacing:.1em;margin-top:5px;display:flex;align-items:center;gap:5px}
.p-code::before{content:'#';font-size:9px;font-weight:700;color:var(--red);opacity:.7}
.p-btns{display:flex;gap:5px;margin-top:10px}
.p-wa{flex:1;height:33px;background:transparent;border:1px solid rgba(37,211,102,.4);border-radius:7px;color:#4ade80;font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:5px;transition:background .2s,border-color .2s,color .2s,transform .15s;text-decoration:none;position:relative;overflow:hidden}
.p-wa:hover{background:var(--wa);border-color:var(--wa);color:#fff;transform:translateY(-1px);box-shadow:0 6px 18px -4px rgba(37,211,102,.45)}
.p-wa:active{transform:scale(.97)}
.p-wa i{font-size:12px}
.p-copy-btn{width:33px;height:33px;flex-shrink:0;border-radius:7px;background:transparent;border:1.5px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:11px;cursor:pointer;transition:all .18s}
.p-copy-btn:hover{color:var(--red);border-color:rgba(232,22,46,.4);background:rgba(232,22,46,.08)}

/* Card "Ver Tudo" */
.p-all{background:var(--off);border:1.5px solid var(--border);border-radius:16px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-decoration:none;padding:22px 14px;cursor:pointer;transition:transform .38s cubic-bezier(.34,1.3,.64,1),background .3s,box-shadow .38s,border-color .3s;min-height:200px;position:relative;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,.04);width:100%}
.p-all::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(232,22,46,.06) 0%,transparent 55%),radial-gradient(ellipse at 50% 120%,rgba(232,22,46,.12) 0%,transparent 65%);pointer-events:none}
.p-all::after{content:'';position:absolute;inset:0;background-image:linear-gradient(rgba(232,22,46,.06) 1px,transparent 1px),linear-gradient(90deg,rgba(232,22,46,.06) 1px,transparent 1px);background-size:22px 22px;pointer-events:none}
.p-all:hover{transform:translateY(-7px);background:var(--red-light);border-color:var(--red-mid);box-shadow:0 18px 40px -8px rgba(232,22,46,.12),0 0 0 1.5px var(--red-mid)}
.p-all-ico{width:48px;height:48px;border-radius:10px;background:rgba(232,22,46,.1);border:1px solid rgba(232,22,46,.28);display:flex;align-items:center;justify-content:center;font-size:16px;color:var(--red);margin-bottom:14px;transition:background .2s,transform .35s cubic-bezier(.34,1.3,.64,1),border-color .2s;position:relative;z-index:1}
.p-all:hover .p-all-ico{background:var(--red);color:#fff;border-color:var(--red);transform:scale(1.1) rotate(8deg)}
.p-all-t{font-family:var(--font-d);font-size:22px;letter-spacing:.08em;color:var(--ink);text-align:center;margin-bottom:5px;line-height:1;position:relative;z-index:1}
.p-all-s{font-family:var(--font-c);font-size:8px;font-weight:700;letter-spacing:.26em;text-transform:uppercase;color:var(--muted);text-align:center;position:relative;z-index:1}

.s-empty{text-align:center;padding:50px 18px;font-family:var(--font-c);font-size:13px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}

/* ===== CATEGORIES ===== */
.cat-sec{background:var(--white);border-top:1px solid var(--border);border-bottom:1px solid var(--border);padding:clamp(50px,6.5vw,84px) clamp(14px,4vw,52px)}
.cat-grid{max-width:1400px;margin:0 auto;display:grid;grid-template-columns:repeat(2,1fr);gap:13px}
@media(min-width:768px){.cat-grid{grid-template-columns:repeat(4,1fr);gap:16px}}
.cat-card{background:var(--off);border:1.5px solid var(--border);border-radius:22px;padding:clamp(17px,3.2vw,28px);cursor:pointer;transition:border-color .3s,transform .4s cubic-bezier(.34,1.3,.64,1),box-shadow .3s;position:relative;overflow:hidden}
.cat-card:hover{border-color:var(--red-mid);transform:translateY(-5px);box-shadow:0 14px 38px -7px rgba(232,22,46,.1)}
.cat-ico{width:44px;height:44px;border-radius:13px;background:var(--red-light);border:1.5px solid var(--red-mid);display:flex;align-items:center;justify-content:center;color:var(--red);font-size:17px;margin-bottom:16px;transition:transform .3s}
.cat-card:hover .cat-ico{transform:scale(1.1) rotate(-5deg)}
.cat-nm{font-family:var(--font-c);font-size:clamp(13px,1.8vw,17px);font-weight:700;font-style:italic;text-transform:uppercase;letter-spacing:.02em;line-height:1.25;color:var(--ink)}
.cat-nm span{color:var(--red)}
.cat-ds{margin-top:6px;font-size:12px;color:var(--muted)}

/* ===== WHY ===== */
.why-sec{padding:clamp(50px,6.5vw,84px) clamp(14px,4vw,52px);max-width:1400px;margin:0 auto}
.why-grid{display:grid;gap:16px;grid-template-columns:1fr}
@media(min-width:768px){.why-grid{grid-template-columns:repeat(3,1fr)}}
.why-card{background:var(--white);border:1.5px solid var(--border);border-radius:22px;padding:clamp(20px,3.2vw,32px);transition:border-color .3s,transform .4s cubic-bezier(.34,1.3,.64,1),box-shadow .3s}
.why-card:hover{border-color:var(--red-mid);transform:translateY(-5px);box-shadow:var(--sh-md)}
.why-ico{width:48px;height:48px;border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:19px;margin-bottom:20px;border:1.5px solid}
.wi-r{background:var(--red-light);border-color:var(--red-mid);color:var(--red)}
.wi-d{background:var(--off);border-color:var(--border);color:var(--ink)}
.wi-b{background:#eff6ff;border-color:#bfdbfe;color:#2563eb}
.why-t{font-family:var(--font-c);font-size:clamp(15px,2vw,19px);font-weight:700;font-style:italic;text-transform:uppercase;letter-spacing:.02em;color:var(--ink);margin-bottom:9px;line-height:1.2}
.why-t span{color:var(--red)}
.why-p{font-size:14px;line-height:1.72;color:var(--muted)}
.why-p b{color:var(--ink);font-weight:600}

/* ===== FOOTER ===== */
footer{background:var(--ink);border-top:1px solid rgba(255,255,255,.05);position:relative;overflow:hidden}
footer::before{content:'';position:absolute;top:-180px;right:-180px;width:520px;height:520px;border-radius:50%;background:radial-gradient(circle,rgba(232,22,46,.07) 0%,transparent 65%);pointer-events:none}
footer::after{content:'';position:absolute;bottom:-100px;left:-100px;width:380px;height:380px;border-radius:50%;background:radial-gradient(circle,rgba(232,22,46,.04) 0%,transparent 70%);pointer-events:none}
.ft-cta-band{background:var(--red);padding:clamp(24px,3.5vw,38px) clamp(14px,4vw,52px);display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;position:relative;z-index:1}
.ft-cta-band::before{content:'';position:absolute;inset:0;background:linear-gradient(110deg,rgba(0,0,0,.15) 0%,transparent 55%);pointer-events:none}
.ft-cta-text{position:relative;z-index:1}
.ft-cta-text h3{font-family:var(--font-d);font-size:clamp(22px,3.5vw,40px);letter-spacing:.03em;color:#fff;line-height:1;margin-bottom:5px}
.ft-cta-text p{font-family:var(--font-c);font-size:12px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.72)}
.ft-cta-actions{display:flex;gap:10px;flex-wrap:wrap;position:relative;z-index:1}
.ft-cta-btn{display:inline-flex;align-items:center;gap:7px;padding:11px 20px;border-radius:10px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.17em;text-transform:uppercase;text-decoration:none;transition:all .2s}
.ft-cta-btn.wa{background:var(--wa);color:#fff;box-shadow:var(--sh-wa)}
.ft-cta-btn.wa:hover{background:#1da851;transform:translateY(-1px)}
.ft-cta-btn.ghost{background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.28)}
.ft-cta-btn.ghost:hover{background:rgba(255,255,255,.2)}
.ft-body{padding:clamp(40px,5.5vw,68px) clamp(14px,4vw,52px) clamp(28px,4vw,48px);max-width:1400px;margin:0 auto;display:grid;gap:40px;grid-template-columns:1fr;position:relative;z-index:1}
@media(min-width:768px){.ft-body{grid-template-columns:1.6fr 1fr 1.1fr 1.2fr;gap:34px}}
.ft-logo-row{display:flex;align-items:center;gap:9px;margin-bottom:14px}
.ft-logo-ico{width:40px;height:40px;border-radius:10px;background:var(--red);display:flex;align-items:center;justify-content:center;font-family:var(--font-d);font-size:20px;color:#fff;flex-shrink:0}
.ft-logo-text{display:flex;flex-direction:column;line-height:1}
.ft-logo-name{font-family:var(--font-d);font-size:21px;letter-spacing:.04em;color:#fff}
.ft-logo-sub{font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.24em;text-transform:uppercase;color:var(--red);margin-top:2px}
.ft-tag{font-size:14px;line-height:1.72;color:rgba(255,255,255,.38);max-width:255px;margin-bottom:20px}
.ft-soc-label{font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.26em;text-transform:uppercase;color:rgba(255,255,255,.25);margin-bottom:10px}
.ft-soc{display:flex;gap:7px}
.soc-btn{width:36px;height:36px;border-radius:9px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.38);font-size:13px;text-decoration:none;transition:background .2s,color .2s,border-color .2s,transform .2s}
.soc-btn:hover{background:var(--red);color:#fff;border-color:var(--red);transform:translateY(-2px)}
.ft-col-t{font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.3em;text-transform:uppercase;color:var(--red);margin-bottom:18px;display:flex;align-items:center;gap:8px}
.ft-col-t::before{content:'';width:14px;height:1.5px;background:var(--red);border-radius:2px;display:inline-block}
.ft-links{display:flex;flex-direction:column;gap:10px}
.ft-links a{font-size:14px;color:rgba(255,255,255,.42);text-decoration:none;transition:color .2s,padding-left .2s;display:flex;align-items:center;gap:7px}
.ft-links a::before{content:'';width:0;height:1.5px;background:var(--red);border-radius:2px;display:inline-block;transition:width .2s;flex-shrink:0}
.ft-links a:hover{color:#fff;padding-left:4px}
.ft-links a:hover::before{width:10px}
.ft-bank{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:16px 18px;margin-bottom:14px}
.ft-bank-lbl{font-family:var(--font-c);font-size:8px;font-weight:700;letter-spacing:.26em;text-transform:uppercase;color:rgba(255,255,255,.28);margin-bottom:6px;display:flex;align-items:center;gap:5px}
.ft-bank-lbl i{color:var(--red);font-size:9px}
.ft-bank-num{font-family:'Courier New',monospace;font-size:15px;font-weight:700;color:#fff;margin-bottom:10px;letter-spacing:.05em}
.ft-bank-nuit{font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.14em;color:rgba(255,255,255,.28);display:flex;align-items:center;gap:6px}
.ft-bank-nuit span{color:#fff;background:rgba(255,255,255,.07);padding:2px 8px;border-radius:5px;font-size:11px}
.ft-contact-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:16px 18px}
.ft-phone{font-family:var(--font-d);font-size:28px;letter-spacing:.03em;color:#fff;margin-bottom:3px;display:flex;align-items:center;gap:9px}
.ft-phone i{font-size:14px;color:var(--red)}
.ft-email{font-size:13px;color:rgba(255,255,255,.4);margin-bottom:12px;display:flex;align-items:center;gap:7px}
.ft-email i{font-size:11px;color:rgba(255,255,255,.3)}
.ft-addr{font-size:12px;font-style:italic;color:rgba(255,255,255,.22);line-height:1.65;display:flex;align-items:flex-start;gap:7px}
.ft-addr i{font-size:11px;color:rgba(255,255,255,.2);margin-top:2px;flex-shrink:0}
.ft-divider{border:none;border-top:1px solid rgba(255,255,255,.06);margin:0}
.ft-bot{padding:16px clamp(14px,4vw,52px);max-width:1400px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:9px;position:relative;z-index:1}
.ft-copy{font-family:var(--font-c);font-size:10px;font-weight:600;letter-spacing:.2em;text-transform:uppercase;color:rgba(255,255,255,.2)}
.ft-bot-right{display:flex;align-items:center;gap:14px}
.ft-pow{font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:rgba(255,255,255,.13)}
.ft-bot-links{display:flex;gap:12px}
.ft-bot-links a{font-family:var(--font-c);font-size:10px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.18);text-decoration:none;transition:color .2s}
.ft-bot-links a:hover{color:rgba(255,255,255,.5)}

/* ===== SHARED BUTTONS ===== */
.btn-ghost{display:inline-flex;align-items:center;gap:7px;color:var(--muted);text-decoration:none;padding:11px 17px;border-radius:10px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;border:1.5px solid var(--border);transition:all .2s}
.btn-ghost:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}

/* ===== WA FAB ===== */
.wa-fab{position:fixed;bottom:26px;right:26px;z-index:9000;display:flex;flex-direction:column;align-items:flex-end;gap:9px}
.wa-bubble{background:var(--white);border-radius:16px 16px 4px 16px;padding:9px 15px;box-shadow:var(--sh-lg);border:1px solid var(--border);font-family:var(--font-c);font-size:12px;font-weight:700;letter-spacing:.06em;color:var(--ink);white-space:nowrap;display:none;transform-origin:bottom right}
.wa-bubble.show{display:block;animation:waBub .4s cubic-bezier(.34,1.56,.64,1)}
@keyframes waBub{from{opacity:0;transform:scale(.7) translateY(8px)}to{opacity:1;transform:scale(1)}}
.wa-btn{width:56px;height:56px;border-radius:50%;background:#25D366;display:flex;align-items:center;justify-content:center;font-size:25px;color:#fff;text-decoration:none;box-shadow:0 8px 22px rgba(37,211,102,.42),0 2px 8px rgba(0,0,0,.14);transition:transform .2s,box-shadow .2s;position:relative;animation:waPop .6s cubic-bezier(.34,1.56,.64,1) 2.4s both}
@keyframes waPop{from{opacity:0;transform:scale(0)}to{opacity:1;transform:scale(1)}}
.wa-btn::before{content:'';position:absolute;inset:-4px;border-radius:50%;background:rgba(37,211,102,.24);animation:waPulse 2.2s ease-in-out 3.2s infinite}
@keyframes waPulse{0%,100%{transform:scale(1);opacity:1}70%{transform:scale(1.5);opacity:0}}
.wa-btn:hover{transform:scale(1.1);box-shadow:0 12px 30px rgba(37,211,102,.52)}
.wa-notif{position:absolute;top:-3px;right:-3px;width:16px;height:16px;border-radius:50%;background:var(--red);border:2px solid var(--white);font-size:8px;font-weight:900;color:#fff;display:flex;align-items:center;justify-content:center}

/* ===== TOAST ===== */
.toast{position:fixed;top:calc(var(--nav-h) + 13px);right:16px;z-index:9100;background:var(--white);border:1px solid var(--border);border-radius:13px;padding:11px 17px;display:flex;align-items:center;gap:9px;box-shadow:var(--sh-lg);font-family:var(--font-c);font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--ink);animation:tIn .4s cubic-bezier(.34,1.56,.64,1);transition:opacity .3s,transform .3s}
@keyframes tIn{from{opacity:0;transform:translateX(34px) scale(.9)}}
.toast i{color:#22c55e;font-size:15px}
.toast.red i{color:var(--red)}
</style>
</head>
<body>

<!-- ===== SPLASH ===== -->
<div id="splash">
    <div class="sp-ring"><img src="img/logo_Maufu.png" alt="Maufu Logo"></div>
    <p class="sp-lbl">Maufu Peças</p>
    <div class="sp-bar"><div class="sp-fill"></div></div>
</div>

<!-- ===== MOBILE SEARCH ===== -->
<div class="msrch-bar" id="msrchBar">
    <input type="text" id="msrchInput" placeholder="Pesquisar peça, marca ou código..." onkeyup="syncSearch(this.value)">
</div>

<!-- ===== NAV ===== -->
<nav>
    <div class="nav-inner">
        <a href="/" class="nav-logo">
            <img src="img/logo_Maufu.png" alt="Maufu Peças">
            <div class="nav-logo-text">
                <span class="t1">MAUFU</span>
                <span class="t2">Peças &amp; Logística</span>
            </div>
        </a>
        <div class="nav-links">
            <a href="#destaque">Destaques</a>
            <a href="#categorias">Categorias</a>
            <a href="#travao">Travão</a>
            <a href="#embraiagem">Embraiagem</a>
            <a href="#motor">Motor</a>
        </div>
        <div class="nav-right">
            <div class="nav-sw">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" id="srchInput" placeholder="Pesquisar peça ou código..." onkeyup="syncSearch(this.value)">
            </div>
            <button class="btn-ico msrch-btn" onclick="toggleMsrch()" aria-label="Pesquisar">
                <i class="fa-solid fa-magnifying-glass"></i>
            </button>
            <a href="tel:+258848684494" class="call-btn" aria-label="Ligar agora">
                <i class="fa-solid fa-phone"></i>
                <span class="lbl">Ligar</span>
            </a>
        </div>
    </div>
</nav>

<!-- ===== HERO SLIDER ===== -->
<section class="hero" id="hero">

    <div class="h-slide active" id="hs1">
        <div class="h-bg" style="background-image:url('img/Cilindros de embraiagem em detalhe.png'),linear-gradient(135deg,#1a1f2e,#0d1117);background-color:#1a1f2e"></div>
        <div class="h-ov"></div><div class="h-ov2"></div>
        <div class="h-cnt"><div class="h-inner">
            <div class="slide-tag tag-red"><div class="td"></div>Oferta Especial</div>
            <h1 class="h-title">CILINDROS<br>DE <span class="r">EMBRAIAGEM</span><br>IVECO</h1>
            <p class="h-sub">Qualidade certificada para máxima performance da sua transmissão. <b>Stock disponível</b> em Matola A com entrega imediata.</p>
            <div class="h-ctas">
                <a href="#destaque" class="btn-hm r"><i class="fa-solid fa-bolt"></i>Ver Oferta</a>
                <a href="#catalogo" class="btn-hg">Catálogo Completo <i class="fa-solid fa-arrow-right"></i></a>
            </div>
        </div></div>
    </div>

    <div class="h-slide" id="hs2">
        <div class="h-bg" style="background-image:url('img/Faróis automóveis modernos e detalhados.png'),linear-gradient(135deg,#0c1733,#0d1117);background-color:#0c1733"></div>
        <div class="h-ov"></div><div class="h-ov2"></div>
        <div class="h-cnt"><div class="h-inner">
            <div class="slide-tag tag-blue"><div class="td"></div>Segurança Máxima</div>
            <h1 class="h-title">FARÓIS<br><span class="b">SCANIA</span><br>&amp; DAF</h1>
            <p class="h-sub">Visibilidade total em qualquer condição. <b>Peças originais</b> com garantia de fabricante para frotas pesadas.</p>
            <div class="h-ctas">
                <a href="#destaque" class="btn-hm b"><i class="fa-solid fa-lightbulb"></i>Ver Detalhes</a>
                <a href="#catalogo" class="btn-hg">Catálogo Completo <i class="fa-solid fa-arrow-right"></i></a>
            </div>
        </div></div>
    </div>

    <div class="h-slide" id="hs3">
        <div class="h-bg" style="background-image:url('img/Componentes de embraiagem em detalhe.png'),linear-gradient(135deg,#0f1a0e,#0d1117);background-color:#0f1a0e"></div>
        <div class="h-ov"></div><div class="h-ov2"></div>
        <div class="h-cnt"><div class="h-inner">
            <div class="slide-tag tag-green"><div class="td"></div>Alta Durabilidade</div>
            <h1 class="h-title">SISTEMAS<br>DE <span class="g">EMBREAGEM</span><br>SCANIA</h1>
            <p class="h-sub">Pastilhas, discos e calços com <b>máxima resistência</b> para as estradas mais exigentes de Moçambique.</p>
            <div class="h-ctas">
                <a href="#destaque" class="btn-hm g"><i class="fa-solid fa-circle-stop"></i>Explorar Gama</a>
                <a href="#catalogo" class="btn-hg">Catálogo Completo <i class="fa-solid fa-arrow-right"></i></a>
            </div>
        </div></div>
    </div>

    <div class="h-slide" id="hs4">
        <div class="h-bg" style="background-image:url('img/Tensionadores de correia automóvel detalhados.png'),linear-gradient(135deg,#1a1200,#0d1117);background-color:#1a1200"></div>
        <div class="h-ov"></div><div class="h-ov2"></div>
        <div class="h-cnt"><div class="h-inner">
            <div class="slide-tag tag-amber"><div class="td"></div>Tensionadores &amp; correia</div>
            <h1 class="h-title">POTÊNCIA<br>COM <span class="a">GARANTIA</span><br>MAN</h1>
            <p class="h-sub">Componentes de motor para <b>MAN, Volvo e Iveco</b>. Importação direta, qualidade certificada, preços competitivos.</p>
            <div class="h-ctas">
                <a href="#destaque" class="btn-hm am"><i class="fa-solid fa-gears"></i>Ver Stock</a>
                <a href="#catalogo" class="btn-hg">Catálogo Completo <i class="fa-solid fa-arrow-right"></i></a>
            </div>
        </div></div>
    </div>

    <div class="hero-thumbs" id="heroThumbs">
        <div class="hero-thumb active" onclick="goSlide(1)" id="t1">
            <div class="ht-bg" style="background-image:url('img/Cilindros de embraiagem em detalhe.png')"></div>
            <div class="ht-ov"></div>
            <div class="ht-lbl">Embraiagem Iveco</div>
            <div class="ht-bar"><div class="ht-prog"></div></div>
        </div>
        <div class="hero-thumb" onclick="goSlide(2)" id="t2">
            <div class="ht-bg" style="background-image:url('img/Faróis automóveis modernos e detalhados.png')"></div>
            <div class="ht-ov"></div>
            <div class="ht-lbl">Faróis Scania &amp; DAF</div>
            <div class="ht-bar"><div class="ht-prog"></div></div>
        </div>
        <div class="hero-thumb" onclick="goSlide(3)" id="t3">
            <div class="ht-bg" style="background-image:url('img/Componentes de embraiagem em detalhe.png');background-color:#0f1a0e"></div>
            <div class="ht-ov"></div>
            <div class="ht-lbl">Travagem Scania</div>
            <div class="ht-bar"><div class="ht-prog"></div></div>
        </div>
        <div class="hero-thumb" onclick="goSlide(4)" id="t4">
            <div class="ht-bg" style="background-image:url('img/Tensionadores de correia automóvel detalhados.png');background-color:#1a1200"></div>
            <div class="ht-ov"></div>
            <div class="ht-lbl">Motor &amp; MAN</div>
            <div class="ht-bar"><div class="ht-prog"></div></div>
        </div>
    </div>
</section>

<!-- ===== STATS BAR ===== -->
<div class="stats-bar">
    <div class="stat-item"><div class="stat-val">500<span>+</span></div><div class="stat-lbl">Referências em Stock</div></div>
    <div class="stat-item"><div class="stat-val">5</div><div class="stat-lbl">Marcas Parceiras</div></div>
    <div class="stat-item"><div class="stat-val">24<span>h</span></div><div class="stat-lbl">Entrega Rápida</div></div>
    <div class="stat-item"><div class="stat-val">100<span>%</span></div><div class="stat-lbl">Qualidade Garantida</div></div>
</div>

<!-- ===== BRAND TICKER ===== -->
<div class="brand-ticker">
    <div class="bt-track">
        <?php
        $marcas = [
            ['nome'=>'SCANIA', 'url'=>'catalogo.php?marca=SCANIA'],
            ['nome'=>'IVECO',  'url'=>'catalogo.php?marca=IVECO'],
            ['nome'=>'DAF',    'url'=>'catalogo.php?marca=DAF'],
            ['nome'=>'MAN',    'url'=>'catalogo.php?marca=MAN'],
            ['nome'=>'VOLVO',  'url'=>'catalogo.php?marca=VOLVO'],
        ];
        $loop = array_merge($marcas, $marcas, $marcas, $marcas);
        foreach ($loop as $m):
            $a = (isset($_GET['marca']) && strtoupper($_GET['marca']) === $m['nome']) ? 'active' : '';
        ?>
        <a href="<?php echo $m['url']; ?>" class="brand-chip <?php echo $a; ?>"><?php echo $m['nome']; ?></a>
        <?php endforeach; ?>
    </div>
</div>

<!-- ===== PRODUCTS ===== -->
<div class="prod-sec-wrap">
<main id="destaque" class="prod-sec">

    <div class="prod-hdr">
        <div class="prod-hdr-left">
            <div class="prod-hdr-top-row">
                <div class="prod-eyebrow">
                    <span class="prod-eyebrow-line"></span>
                    Inventário Atualizado
                </div>
                <div class="prod-stock-badge">
                    <span class="stock-dot"></span>
                    Em Stock
                </div>
            </div>
            <div class="prod-title-row">
                <h2 class="prod-main-title">Peças em <span class="ac">Destaque</span></h2>
                <div class="prod-count-tag">
                    <span class="prod-count-num"><?php echo count($produtos_json); ?></span>
                    <span class="prod-count-lbl">Refs</span>
                </div>
            </div>
        </div>
        <div class="prod-hdr-right">
            <button class="btn-shuffle" onclick="shuffleProducts()" id="shuffleBtn">
                <i class="fa-solid fa-shuffle"></i> Aleatórios
            </button>
            <a href="catalogo.php" class="btn-ghost">Ver Catálogo <i class="fa-solid fa-arrow-right"></i></a>
        </div>
    </div>

    <div id="productGrid"></div>
</main>
</div>

<?php include 'mais-vendidos.php'; ?>

<!-- ===== CATEGORIES ===== -->
<section class="cat-sec" id="categorias">
    <div style="max-width:1400px;margin:0 auto">
        <div class="s-hdr">
            <div>
                <p class="s-eyebrow">Navegue por Área</p>
                <h2 class="s-title">Cate<span class="ac">gorias</span></h2>
            </div>
        </div>
        <div class="cat-grid">
            <div class="cat-card" id="motor">
                <div class="cat-ico"><i class="fa-solid fa-gears"></i></div>
                <h4 class="cat-nm">Motor &amp; <span>Transmissão</span></h4>
                <p class="cat-ds">Pistões, juntas, caixas de velocidade</p>
            </div>
            <div class="cat-card" id="travao">
                <div class="cat-ico"><i class="fa-solid fa-circle-stop"></i></div>
                <h4 class="cat-nm">Sistemas de <span>Travagem</span></h4>
                <p class="cat-ds">Pastilhas, discos, calços, tambores</p>
            </div>
            <div class="cat-card">
                <div class="cat-ico" style="background:#eff6ff;border-color:#bfdbfe;color:#2563eb"><i class="fa-solid fa-bolt"></i></div>
                <h4 class="cat-nm">Elétrica &amp; <span>Iluminação</span></h4>
                <p class="cat-ds">Faróis, alternadores, baterias</p>
            </div>
            <div class="cat-card" id="embraiagem">
                <div class="cat-ico" style="background:var(--off);border-color:var(--border);color:var(--ink)"><i class="fa-solid fa-truck-monster"></i></div>
                <h4 class="cat-nm">Suspensão &amp; <span>Chassis</span></h4>
                <p class="cat-ds">Amortecedores, molas, braços</p>
            </div>
        </div>
    </div>
</section>

<!-- ===== WHY ===== -->
<section class="why-sec">
    <div class="s-hdr">
        <div>
            <p class="s-eyebrow">Por que Escolher-nos</p>
            <h2 class="s-title">Nossos <span class="ac">Diferenciais</span></h2>
        </div>
    </div>
    <div class="why-grid">
        <div class="why-card">
            <div class="why-ico wi-r"><i class="fa-solid fa-bolt-lightning"></i></div>
            <h4 class="why-t">Stock Pronta <span>Entrega</span></h4>
            <p class="why-p">Componentes críticos disponíveis em <b>Matola A</b>. Reduzimos o seu tempo de paragem ao mínimo absoluto.</p>
        </div>
        <div class="why-card">
            <div class="why-ico wi-d"><i class="fa-solid fa-shield-check"></i></div>
            <h4 class="why-t">Qualidade <span>Certificada</span></h4>
            <p class="why-p">Importação direta com <b>garantia de fabricante</b>. Especialistas em frotas pesadas há mais de uma década.</p>
        </div>
        <div class="why-card">
            <div class="why-ico wi-b"><i class="fa-solid fa-truck-fast"></i></div>
            <h4 class="why-t">Logística <span>Eficiente</span></h4>
            <p class="why-p">Processamento via <b>Primavera BSS</b> para faturação e orçamentos rápidos, precisos e rastreáveis.</p>
        </div>
    </div>
</section>

<!-- ===== FOOTER ===== -->
<footer id="catalogo">
    <div class="ft-cta-band">
        <div class="ft-cta-text">
            <h3>Precisa de uma Peça?</h3>
            <p>Fale connosco agora — resposta imediata</p>
        </div>
        <div class="ft-cta-actions">
            <a href="https://wa.me/258848684494?text=Ol%C3%A1%2C%20vim%20do%20site%20Maufu%20Pe%C3%A7as%20e%20preciso%20de%20ajuda." class="ft-cta-btn wa" target="_blank" rel="noopener">
                <i class="fa-brands fa-whatsapp"></i> WhatsApp
            </a>
            <a href="tel:+258848684494" class="ft-cta-btn ghost">
                <i class="fa-solid fa-phone"></i> Ligar Agora
            </a>
        </div>
    </div>

    <div class="ft-body">
        <div class="ft-brand-col">
            <div class="ft-logo-row">
                <div class="ft-logo-ico">M</div>
                <div class="ft-logo-text">
                    <span class="ft-logo-name">MAUFU PEÇAS</span>
                    <span class="ft-logo-sub">Lda · Est. 2012</span>
                </div>
            </div>
            <p class="ft-tag">Líder no fornecimento de peças sobressalentes para veículos pesados em Moçambique. Qualidade garantida, entrega rápida.</p>
            <p class="ft-soc-label">Siga-nos</p>
            <div class="ft-soc">
                <a href="#" class="soc-btn" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="https://wa.me/258848684494" class="soc-btn" aria-label="WhatsApp" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i></a>
                <a href="mailto:maufulda@gmail.com" class="soc-btn" aria-label="Email"><i class="fa-solid fa-envelope"></i></a>
            </div>
        </div>

        <div>
            <p class="ft-col-t">Navegação</p>
            <div class="ft-links">
                <a href="/"><i class="fa-solid fa-house" style="font-size:10px;opacity:.5"></i>Início</a>
                <a href="#destaque"><i class="fa-solid fa-star" style="font-size:10px;opacity:.5"></i>Destaques</a>
                <a href="#categorias"><i class="fa-solid fa-grid-2" style="font-size:10px;opacity:.5"></i>Categorias</a>
                <a href="catalogo.php"><i class="fa-solid fa-book" style="font-size:10px;opacity:.5"></i>Catálogo Completo</a>
                <a href="#"><i class="fa-solid fa-circle-info" style="font-size:10px;opacity:.5"></i>Sobre Nós</a>
            </div>
        </div>

        <div>
            <p class="ft-col-t">Informação Fiscal</p>
            <div class="ft-bank">
                <p class="ft-bank-lbl"><i class="fa-solid fa-building-columns"></i> Conta BCI (MZN)</p>
                <p class="ft-bank-num">1623 1592 11000 01</p>
                <p class="ft-bank-nuit">NUIT: <span>400 753 581</span></p>
            </div>
            <div class="ft-links" style="margin-top:4px">
                <a href="catalogo.php"><i class="fa-solid fa-file-invoice" style="font-size:10px;opacity:.5"></i>Solicitar Fatura</a>
                <a href="catalogo.php"><i class="fa-solid fa-file-lines" style="font-size:10px;opacity:.5"></i>Pedir Orçamento</a>
            </div>
        </div>

        <div>
            <p class="ft-col-t">Contacto</p>
            <div class="ft-contact-card">
                <p class="ft-phone"><i class="fa-solid fa-phone"></i>+258 84 868 4494</p>
                <p class="ft-email"><i class="fa-solid fa-envelope"></i>maufulda@gmail.com</p>
                <p class="ft-addr"><i class="fa-solid fa-location-dot"></i>Av. União Africana, Matola A,<br>Moçambique</p>
            </div>
        </div>
    </div>

    <hr class="ft-divider">

    <div class="ft-bot">
        <p class="ft-copy">© 2026 Maufu Peças, Lda. Todos os direitos reservados.</p>
        <div class="ft-bot-right">
            <div class="ft-bot-links">
                <a href="#">Privacidade</a>
                <a href="#">Termos</a>
            </div>
            <p class="ft-pow">Powered by Primavera BSS</p>
        </div>
    </div>
</footer>

<!-- ===== WA FAB ===== -->
<div class="wa-fab">
    <div class="wa-bubble" id="waBubble">💬 Fale connosco agora!</div>
    <a href="https://wa.me/258848684494?text=Ol%C3%A1%2C%20vim%20do%20site%20Maufu%20Pe%C3%A7as%20e%20gostaria%20de%20informa%C3%A7%C3%B5es."
       class="wa-btn" target="_blank" rel="noopener" aria-label="WhatsApp"
       onclick="document.getElementById('waBubble').classList.remove('show')">
        <i class="fa-brands fa-whatsapp"></i>
        <span class="wa-notif">1</span>
    </a>
</div>

<script>
const products = <?php echo json_encode($produtos_json, JSON_UNESCAPED_UNICODE); ?>;
const WA_NUM  = '258848684494';
const SITE_URL = window.location.origin + window.location.pathname;

/* ── SPLASH ───────────────────────────────────────── */
window.addEventListener('load', () => {
    setTimeout(() => {
        const s = document.getElementById('splash');
        if (s) { s.classList.add('hidden'); setTimeout(() => s.style.display = 'none', 820); }
        <?php if (isset($_GET['success'])): ?>
        showToast('Produto adicionado com sucesso!');
        <?php endif; ?>
    }, 2100);
});

/* ── WA BUBBLE ────────────────────────────────────── */
setTimeout(() => {
    const b = document.getElementById('waBubble');
    if (b) { b.classList.add('show'); setTimeout(() => b.classList.remove('show'), 6000); }
}, 4200);

/* ── TOAST ────────────────────────────────────────── */
function showToast(msg, isRed) {
    const t = document.createElement('div');
    t.className = 'toast' + (isRed ? ' red' : '');
    t.innerHTML = `<i class="fa-solid fa-circle-check"></i>${msg}`;
    document.body.appendChild(t);
    setTimeout(() => {
        t.style.opacity = '0'; t.style.transform = 'translateX(34px)';
        setTimeout(() => t.remove(), 350);
    }, 3000);
}

/* ── HERO SLIDER ──────────────────────────────────── */
const TOTAL = 4;
let cur = 1, iv;

function goSlide(n) {
    document.getElementById('hs' + cur).classList.remove('active');
    document.getElementById('t'  + cur).classList.remove('active');
    cur = n;
    document.getElementById('hs' + cur).classList.add('active');
    const th = document.getElementById('t' + cur);
    th.classList.add('active');
    const pr = th.querySelector('.ht-prog');
    pr.style.animation = 'none'; pr.offsetHeight; pr.style.animation = '';
    resetIv();
}
function resetIv() {
    clearInterval(iv);
    iv = setInterval(() => goSlide(cur === TOTAL ? 1 : cur + 1), 6500);
}
resetIv();

/* swipe */
(() => {
    let sx = 0;
    const h = document.getElementById('hero');
    h.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true });
    h.addEventListener('touchend',   e => {
        const dx = e.changedTouches[0].clientX - sx;
        if (Math.abs(dx) > 48) goSlide(dx < 0 ? (cur === TOTAL ? 1 : cur + 1) : (cur === 1 ? TOTAL : cur - 1));
    }, { passive: true });
})();

/* ── MOBILE SEARCH ────────────────────────────────── */
let mOpen = false;
function toggleMsrch() {
    mOpen = !mOpen;
    document.getElementById('msrchBar').classList.toggle('open', mOpen);
    if (mOpen) document.getElementById('msrchInput').focus();
}
function syncSearch(v) {
    document.getElementById('srchInput').value  = v;
    document.getElementById('msrchInput').value = v;
    renderProducts(v.trim().toLowerCase());
    if (v.trim().length > 0) {
        const sec = document.getElementById('destaque');
        if (sec) window.scrollTo({ top: sec.getBoundingClientRect().top + window.scrollY - 80, behavior: 'smooth' });
    }
}

/* ── WHATSAPP ─────────────────────────────────────── */
function contactWA(id) {
    const p = products.find(x => x.id == id);
    if (!p) return;
    let imgUrl = p.img || '';
    if (imgUrl && !imgUrl.startsWith('http')) imgUrl = window.location.origin + '/' + imgUrl.replace(/^\//, '');
    const imgLine = imgUrl ? `%0A%F0%9F%93%B8 *Imagem:* ${encodeURIComponent(imgUrl)}` : '';
    const msg = `Ol%C3%A1! Tenho interesse na seguinte pe%C3%A7a:%0A%0A`
              + `%F0%9F%94%A7 *Nome:* ${encodeURIComponent(p.name)}%0A`
              + `%F0%9F%8F%AD *Marca:* ${encodeURIComponent(p.brand)}%0A`
              + `%F0%9F%94%96 *Refer%C3%AAncia:* ${p.code ? encodeURIComponent('#' + p.code) : 'N/D'}`
              + imgLine
              + `%0A%0APoderia informar disponibilidade e pre%C3%A7o%3F`;
    window.open(`https://wa.me/${WA_NUM}?text=${msg}`, '_blank', 'noopener');
}

/* ── COPIAR ───────────────────────────────────────── */
function copyProduct(id, e) {
    if (e) e.stopPropagation();
    const p = products.find(x => x.id == id);
    if (!p) return;
    const txt = `${p.name} | Marca: ${p.brand}${p.code ? ' | Ref: #' + p.code : ''}\nVer em: ${SITE_URL}#destaque\nContacto: +258 84 868 4494`;
    navigator.clipboard.writeText(txt)
        .then(() => showToast('Copiado para a área de transferência!'))
        .catch(() => {
            const ta = document.createElement('textarea');
            ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
            document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
            showToast('Copiado!');
        });
}

/* ── PARTILHAR ────────────────────────────────────── */
function shareProduct(id, e) {
    if (e) e.stopPropagation();
    const p = products.find(x => x.id == id);
    if (!p) return;
    const data = {
        title: p.name + ' — Maufu Peças',
        text:  `${p.name} | ${p.brand}${p.code ? ' | Ref: #' + p.code : ''}`,
        url:   `${SITE_URL}?produto=${p.id}#destaque`
    };
    if (navigator.share) navigator.share(data).catch(() => {});
    else navigator.clipboard.writeText(data.url).then(() => showToast('Link copiado para partilhar!')).catch(() => {});
}

/* ── SHUFFLE ──────────────────────────────────────── */
function shuffleArray(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

let shuffledProducts = [...products];
let isShuffled = false;

function shuffleProducts() {
    const btn = document.getElementById('shuffleBtn');
    btn.querySelector('i').style.animation = 'spin360 .4s ease';
    setTimeout(() => { if (btn.querySelector('i')) btn.querySelector('i').style.animation = ''; }, 400);
    shuffledProducts = shuffleArray(products);
    isShuffled = true;
    renderProducts(document.getElementById('srchInput').value.trim().toLowerCase(), shuffledProducts);
    showToast('Produtos aleatórios carregados!');
}

/* ── RENDER PRODUCTS ──────────────────────────────── */
function renderProducts(q, src) {
    const source = src || (isShuffled ? shuffledProducts : products);
    const all = q
        ? source.filter(p =>
            p.name.includes(q.toUpperCase()) ||
            p.code.toLowerCase().includes(q) ||
            p.brand.includes(q.toUpperCase()) ||
            (p.desc && p.desc.toLowerCase().includes(q)))
        : source;

    const g = document.getElementById('productGrid');
    if (!all.length) {
        g.innerHTML = '<div class="s-empty"><i class="fa-solid fa-magnifying-glass" style="margin-right:9px;opacity:.25"></i>Nenhum produto encontrado</div>';
        return;
    }

    const PER_ROW  = 5;
    const isSearch = q && q.length > 0;

    let data, showVerTudo;
    if (isSearch) {
        data = all; showVerTudo = false;
    } else {
        data = all.slice(0, 3 * PER_ROW); showVerTudo = true;
    }

    const chunks = [];
    for (let i = 0; i < data.length; i += PER_ROW) chunks.push(data.slice(i, i + PER_ROW));

    const verTudo = `
        <a href="catalogo.php" class="p-all">
            <div class="p-all-ico"><i class="fa-solid fa-arrow-right"></i></div>
            <p class="p-all-t">VER TODO</p>
            <p class="p-all-s">Catálogo Completo</p>
        </a>`;

    const searchHeader = isSearch ? `
        <div style="margin-bottom:18px;display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <span style="font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--muted)">
                <i class="fa-solid fa-magnifying-glass" style="color:var(--red);margin-right:6px"></i>
                ${all.length} resultado${all.length !== 1 ? 's' : ''} para "<strong style="color:var(--ink)">${q}</strong>"
            </span>
            <button onclick="syncSearch('')" style="background:var(--red-light);border:1.5px solid var(--red-mid);color:var(--red);border-radius:7px;padding:4px 12px;font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.15em;text-transform:uppercase;cursor:pointer">
                <i class="fa-solid fa-xmark"></i> Limpar
            </button>
        </div>` : '';

    let html = searchHeader;
    chunks.forEach((chunk, ri) => {
        const cards = chunk.map(p => `
            <div class="p-card" onclick="window.location='detalhes.php?id=${p.id}'">
                <div class="p-img">
                    <div class="p-badge">Disponível</div>
                    <div class="p-actions">
                        <button class="p-act-btn" title="Partilhar" onclick="shareProduct(${p.id}, event)">
                            <i class="fa-solid fa-share-nodes"></i>
                        </button>
                        <button class="p-act-btn" title="Copiar info" onclick="copyProduct(${p.id}, event)">
                            <i class="fa-solid fa-copy"></i>
                        </button>
                    </div>
                    <img src="${p.img}" alt="${p.name}"
                         onerror="this.src='https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&q=80&w=600'">
                </div>
                <div class="p-body">
                    <p class="p-brand">${p.brand}</p>
                    <h4 class="p-name">${p.name}</h4>
                    ${p.code ? `<p class="p-code">${p.code}</p>` : ''}
                    <div class="p-btns">
                        <button class="p-wa" onclick="event.stopPropagation();contactWA(${p.id})">
                            <i class="fa-brands fa-whatsapp"></i>Contactar
                        </button>
                        <button class="p-copy-btn" title="Copiar" onclick="copyProduct(${p.id}, event)">
                            <i class="fa-solid fa-copy"></i>
                        </button>
                    </div>
                </div>
            </div>`).join('');

        const isLast = ri === chunks.length - 1;
        const extra  = (!isSearch && isLast && showVerTudo) ? verTudo : '';

        html += `<div class="p-row p-row-${ri}" id="pRow${ri}">${cards}${extra}</div>`;
        if (ri < chunks.length - 1) html += `<div class="p-row-gap"></div>`;
    });

    g.innerHTML = html;
}

/* ── INIT ─────────────────────────────────────────── */
shuffledProducts = [...products];
isShuffled = false;
renderProducts('');

document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && mOpen) toggleMsrch();
});
</script>

<style>
@keyframes spin360{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
</style>
</body>
</html>