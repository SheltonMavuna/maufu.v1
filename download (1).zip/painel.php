<?php
/**
 * MAUFU LOGISTICS OS V2.1 - FIXED EDITION
 */

$host = "sql100.infinityfree.com";
$user = "if0_40911457";
$pass = "tuLX88H1Oqp";
$db   = "if0_40911457_maufu";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Erro de Conexão: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// ─── ENSURE updated_at COLUMN EXISTS ─────────────────────────────────────────
$conn->query("ALTER TABLE produtos ADD COLUMN IF NOT EXISTS updated_at DATETIME NULL DEFAULT NULL");

// ─── UPLOAD DIR ───────────────────────────────────────────────────────────────
$upload_dir = __DIR__ . '/uploads/';
if (!is_dir($upload_dir)) {
    @mkdir($upload_dir, 0755, true);
}

// ─── SELF URL (safe for all hosts) ───────────────────────────────────────────
function selfUrl() {
    $script = $_SERVER['SCRIPT_NAME'] ?? $_SERVER['PHP_SELF'] ?? '/index.php';
    return $script;
}

// ─── DELETE ───────────────────────────────────────────────────────────────────
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id   = intval($_GET['delete']);
    $stmt = $conn->prepare("SELECT imagem_url FROM produtos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && $p = $res->fetch_assoc()) {
        if (!empty($p['imagem_url'])) {
            foreach (explode(',', $p['imagem_url']) as $img) {
                $img = trim($img);
                $full = __DIR__ . '/' . ltrim($img, '/');
                if ($img && file_exists($full)) {
                    @unlink($full);
                }
            }
        }
    }
    $stmt->close();

    $del = $conn->prepare("DELETE FROM produtos WHERE id = ?");
    $del->bind_param("i", $id);
    $del->execute();
    $del->close();

    header("Location: " . selfUrl() . "?msg=deleted");
    exit();
}

// ─── UPLOAD HELPER ────────────────────────────────────────────────────────────
function handleUploads($files, $upload_dir) {
    $paths = [];
    if (empty($files['tmp_name']) || !is_array($files['tmp_name'])) {
        return '';
    }
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    foreach ($files['tmp_name'] as $key => $tmp_name) {
        if (
            isset($files['error'][$key]) &&
            $files['error'][$key] === UPLOAD_ERR_OK &&
            is_uploaded_file($tmp_name)
        ) {
            $ext = strtolower(pathinfo($files['name'][$key], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed)) {
                continue;
            }
            $file_name = time() . "_" . uniqid() . "." . $ext;
            $dest      = $upload_dir . $file_name;
            if (move_uploaded_file($tmp_name, $dest)) {
                $paths[] = 'uploads/' . $file_name;
            }
        }
    }
    return implode(",", $paths);
}

// ─── INSERT ───────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $nome      = trim($_POST['nome']      ?? '');
    $codigo    = trim($_POST['codigo']    ?? '');
    $marca     = trim($_POST['marca']     ?? '');
    $descricao = trim($_POST['descricao'] ?? '');

    if ($nome === '' || $codigo === '') {
        header("Location: " . selfUrl() . "?error=empty");
        exit();
    }

    // Duplicate check
    $check = $conn->prepare("SELECT id FROM produtos WHERE codigo = ?");
    $check->bind_param("s", $codigo);
    $check->execute();
    $check->store_result();
    $isDuplicate = $check->num_rows > 0;
    $check->close();

    if ($isDuplicate) {
        header("Location: " . selfUrl() . "?error=duplicate");
        exit();
    }

    $imgs = (!empty($_FILES['imagens']['tmp_name'][0]))
        ? handleUploads($_FILES['imagens'], $upload_dir)
        : '';

    $stmt = $conn->prepare("INSERT INTO produtos (nome, codigo, marca, descricao, imagem_url) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $nome, $codigo, $marca, $descricao, $imgs);
    if ($stmt->execute()) {
        $stmt->close();
        header("Location: " . selfUrl() . "?msg=success");
        exit();
    }
    $stmt->close();
}

// ─── EDIT ─────────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_product'])) {
    $id        = intval($_POST['id']        ?? 0);
    $nome      = trim($_POST['nome']        ?? '');
    $codigo    = trim($_POST['codigo']      ?? '');
    $marca     = trim($_POST['marca']       ?? '');
    $descricao = trim($_POST['descricao']   ?? '');

    if ($id <= 0) {
        header("Location: " . selfUrl() . "?error=invalid");
        exit();
    }

    $hasNewImages = !empty($_FILES['imagens']['tmp_name'][0])
                    && $_FILES['imagens']['error'][0] === UPLOAD_ERR_OK;

    $now = date('Y-m-d H:i:s');

    if ($hasNewImages) {
        // Delete old images
        $res = $conn->prepare("SELECT imagem_url FROM produtos WHERE id = ?");
        $res->bind_param("i", $id);
        $res->execute();
        $row = $res->get_result()->fetch_assoc();
        $res->close();
        if ($row && !empty($row['imagem_url'])) {
            foreach (explode(',', $row['imagem_url']) as $img) {
                $img  = trim($img);
                $full = __DIR__ . '/' . ltrim($img, '/');
                if ($img && file_exists($full)) {
                    @unlink($full);
                }
            }
        }
        $imgs = handleUploads($_FILES['imagens'], $upload_dir);
        $stmt = $conn->prepare("UPDATE produtos SET nome=?, codigo=?, marca=?, descricao=?, imagem_url=?, updated_at=? WHERE id=?");
        $stmt->bind_param("ssssssi", $nome, $codigo, $marca, $descricao, $imgs, $now, $id);
    } else {
        $stmt = $conn->prepare("UPDATE produtos SET nome=?, codigo=?, marca=?, descricao=?, updated_at=? WHERE id=?");
        $stmt->bind_param("sssssi", $nome, $codigo, $marca, $descricao, $now, $id);
    }

    if ($stmt->execute()) {
        $stmt->close();
        header("Location: " . selfUrl() . "?msg=updated");
        exit();
    }
    $stmt->close();
}

// ─── FETCH PRODUCTS ───────────────────────────────────────────────────────────
$produtos_array = [];
$result = $conn->query("SELECT * FROM produtos ORDER BY id DESC LIMIT 2000");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $produtos_array[] = $row;
    }
}

// ─── HELPER: is recently edited (within 7 days) ───────────────────────────────
function isRecentlyEdited($updated_at) {
    if (empty($updated_at)) return false;
    $updatedTs = strtotime($updated_at);
    if ($updatedTs === false) return false;
    return (time() - $updatedTs) <= (7 * 24 * 60 * 60);
}
?>
<!DOCTYPE html>
<html lang="pt-pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAUFU PEÇAS | PAINEL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        :root {
            --maufu-red:  #e11d48;
            --maufu-dark: #0f172a;
        }

        * { box-sizing: border-box; }
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #ffffff; }

        /* ── field ── */
        .field-group {
            position: relative;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            padding: 8px 16px;
            transition: all 0.2s;
        }
        .field-group:focus-within {
            border-color: var(--maufu-red);
            background: white;
            box-shadow: 0 4px 12px rgba(225, 29, 72, 0.08);
        }
        .field-label {
            font-size: 9px;
            font-weight: 800;
            text-transform: uppercase;
            color: #94a3b8;
            letter-spacing: 0.05em;
            display: block;
            margin-bottom: 2px;
        }
        .field-input {
            width: 100%;
            background: transparent;
            border: none;
            outline: none;
            font-size: 14px;
            font-weight: 700;
            color: var(--maufu-dark);
            font-family: inherit;
        }
        select.field-input { cursor: pointer; }

        /* ── layers ── */
        .layer {
            position: fixed;
            inset: 0;
            z-index: 100;
            background: white;
            transform: translateY(100%);
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            flex-direction: column;
        }
        .layer.open { transform: translateY(0); }

        /* ── lightbox ── */
        #lightbox {
            position: fixed;
            inset: 0;
            z-index: 200;
            background: rgba(0,0,0,0.85);
            display: none;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        #lightbox.open { display: flex; }
        #lightbox img {
            max-width: 90vw;
            max-height: 85vh;
            border-radius: 16px;
            object-fit: contain;
        }
        #lightbox-close {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 44px;
            height: 44px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 18px;
        }
        #lb-prev, #lb-next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 44px;
            height: 44px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
        }
        #lb-prev { left: 20px; }
        #lb-next { right: 20px; }

        /* ── toast ── */
        #toast {
            position: fixed;
            bottom: 32px;
            left: 50%;
            transform: translateX(-50%) translateY(80px);
            background: var(--maufu-dark);
            color: white;
            padding: 12px 28px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 700;
            z-index: 999;
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            white-space: nowrap;
        }
        #toast.show { transform: translateX(-50%) translateY(0); }

        /* ── product card ── */
        .prod-card {
            background: white;
            padding: 12px;
            border-radius: 20px;
            border: 1px solid #f1f5f9;
            box-shadow: 0 1px 4px rgba(0,0,0,0.04);
            transition: box-shadow 0.2s, transform 0.2s;
            position: relative;
        }
        .prod-card:hover {
            box-shadow: 0 8px 24px rgba(0,0,0,0.09);
            transform: translateY(-2px);
        }
        .prod-card .thumb {
            position: relative;
            overflow: hidden;
            border-radius: 14px;
            aspect-ratio: 1/1;
            margin-bottom: 10px;
            cursor: pointer;
        }
        .prod-card .thumb img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s; }
        .prod-card:hover .thumb img { transform: scale(1.06); }
        .prod-card .overlay {
            position: absolute;
            inset: 0;
            background: rgba(0,0,0,0.45);
            opacity: 0;
            transition: opacity 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .prod-card:hover .overlay { opacity: 1; }
        .overlay-btn {
            width: 34px;
            height: 34px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform 0.15s;
            border: none;
            text-decoration: none;
        }
        .overlay-btn:hover { transform: scale(1.15); }

        /* ── card number badge ── */
        .card-number {
            position: absolute;
            top: 8px;
            left: 8px;
            z-index: 10;
            background: var(--maufu-dark);
            color: white;
            font-size: 8px;
            font-weight: 900;
            letter-spacing: 0.04em;
            padding: 2px 7px;
            border-radius: 20px;
            pointer-events: none;
            line-height: 1.6;
        }

        /* ── recently edited badge ── */
        .badge-edited {
            display: inline-flex;
            align-items: center;
            gap: 3px;
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
            font-size: 7px;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            padding: 2px 7px;
            border-radius: 20px;
            margin-top: 3px;
            white-space: nowrap;
            animation: pulse-badge 2s ease-in-out infinite;
        }
        @keyframes pulse-badge {
            0%, 100% { opacity: 1; }
            50%       { opacity: 0.75; }
        }

        /* ── btn-submit ── */
        .btn-submit {
            background: var(--maufu-dark);
            color: white;
            width: 100%;
            padding: 16px;
            border-radius: 16px;
            font-weight: 800;
            text-transform: uppercase;
            font-size: 11px;
            cursor: pointer;
            border: none;
            transition: background 0.25s, transform 0.2s;
            font-family: inherit;
            letter-spacing: 0.05em;
        }
        .btn-submit:hover { background: var(--maufu-red); transform: translateY(-2px); }
        .btn-blue { background: #2563eb !important; }
        .btn-blue:hover { background: #1d4ed8 !important; }

        /* ── image strip in edit ── */
        .edit-img-strip { display: flex; gap: 8px; flex-wrap: wrap; }
        .edit-img-strip img {
            width: 72px;
            height: 72px;
            object-fit: cover;
            border-radius: 10px;
            cursor: pointer;
            border: 2px solid transparent;
            transition: border-color 0.2s;
        }
        .edit-img-strip img:hover { border-color: var(--maufu-red); }

        /* ── layout ── */
        .main-grid { display: grid; grid-template-columns: 1fr; }
        @media (min-width: 1024px) {
            .main-grid { grid-template-columns: 450px 1fr; height: 100vh; }
        }

        /* ── search bar ── */
        #search-input {
            width: 100%;
            padding: 10px 16px 10px 40px;
            border-radius: 14px;
            border: 1px solid #e2e8f0;
            font-size: 13px;
            font-weight: 600;
            font-family: inherit;
            outline: none;
            background: #f8fafc;
            color: var(--maufu-dark);
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        #search-input:focus {
            border-color: var(--maufu-red);
            background: white;
            box-shadow: 0 4px 12px rgba(225,29,72,0.08);
        }
        .search-wrap { position: relative; }
        .search-wrap i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            font-size: 13px;
        }

        /* ── confirm modal ── */
        #confirm-modal {
            position: fixed;
            inset: 0;
            z-index: 300;
            background: rgba(0,0,0,0.6);
            display: none;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        #confirm-modal.open { display: flex; }
        #confirm-modal .box {
            background: white;
            border-radius: 24px;
            padding: 32px;
            max-width: 360px;
            width: 100%;
            text-align: center;
        }
    </style>
</head>
<body class="overflow-x-hidden">

<!-- ── TOAST ─────────────────────────────────────────────────────────────── -->
<div id="toast"></div>

<!-- ── LIGHTBOX ──────────────────────────────────────────────────────────── -->
<div id="lightbox">
    <div id="lightbox-close" onclick="closeLightbox()"><i class="fa-solid fa-xmark"></i></div>
    <div id="lb-prev" onclick="lbShift(-1)"><i class="fa-solid fa-chevron-left"></i></div>
    <img id="lightbox-img" src="" alt="">
    <div id="lb-next" onclick="lbShift(1)"><i class="fa-solid fa-chevron-right"></i></div>
</div>

<!-- ── CONFIRM MODAL ─────────────────────────────────────────────────────── -->
<div id="confirm-modal">
    <div class="box">
        <div class="w-14 h-14 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fa-solid fa-trash text-rose-600 text-xl"></i>
        </div>
        <h3 class="text-lg font-black text-slate-800 mb-2">Eliminar Produto?</h3>
        <p class="text-sm text-slate-500 mb-6">Esta ação é irreversível. O produto e as suas imagens serão eliminados permanentemente.</p>
        <div class="flex gap-3">
            <button onclick="closeConfirm()" class="flex-1 py-3 rounded-2xl border border-slate-200 font-bold text-sm text-slate-600 hover:bg-slate-50 transition">Cancelar</button>
            <a id="confirm-delete-link" href="#" class="flex-1 py-3 rounded-2xl bg-rose-600 font-bold text-sm text-white text-center hover:bg-rose-700 transition">Eliminar</a>
        </div>
    </div>
</div>

<!-- ── INVENTORY LAYER ────────────────────────────────────────────────────── -->
<div id="inventory-layer" class="layer">
    <div class="p-5 border-b flex justify-between items-center bg-white flex-shrink-0">
        <div>
            <h2 class="text-2xl font-black italic uppercase">Database <span class="text-rose-600">Stock</span></h2>
            <p class="text-xs text-slate-400 font-semibold mt-0.5"><?php echo count($produtos_array); ?> produtos registados</p>
        </div>
        <button onclick="toggleInv()" class="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center hover:bg-rose-600 hover:text-white transition-all">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>

    <!-- Search -->
    <div class="px-5 pt-4 pb-2 flex-shrink-0">
        <div class="search-wrap">
            <i class="fa-solid fa-search"></i>
            <input type="text" id="search-input" placeholder="Pesquisar por nome, SKU ou marca..." oninput="filterCards(this.value)">
        </div>
    </div>

    <div class="flex-1 overflow-y-auto p-4 md:p-6 bg-slate-50">
        <div id="cards-grid" class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            <?php
            $totalProdutos = count($produtos_array);
            foreach ($produtos_array as $cardIndex => $row):
                $cardNumber = $totalProdutos - $cardIndex; // highest number = most recent
                $files = array_values(array_filter(array_map('trim', explode(',', $row['imagem_url'] ?? ''))));
                $imgSrc = '';
                foreach ($files as $f) {
                    if ($f && file_exists(__DIR__ . '/' . ltrim($f, '/'))) {
                        $imgSrc = $f;
                        break;
                    }
                }
                if (!$imgSrc) $imgSrc = 'https://placehold.co/400x400/f1f5f9/94a3b8?text=Sem+Foto';
                $imgsJson   = htmlspecialchars(json_encode($files), ENT_QUOTES, 'UTF-8');
                $rowJson    = htmlspecialchars(json_encode($row),   ENT_QUOTES, 'UTF-8');
                $recentEdit = isRecentlyEdited($row['updated_at'] ?? '');
            ?>
            <div class="prod-card"
                 data-nome="<?php echo strtolower(htmlspecialchars($row['nome']   ?? '')); ?>"
                 data-codigo="<?php echo strtolower(htmlspecialchars($row['codigo'] ?? '')); ?>"
                 data-marca="<?php echo strtolower(htmlspecialchars($row['marca']  ?? '')); ?>">

                <!-- Número do produto -->
                <span class="card-number">#<?php echo $cardNumber; ?></span>

                <div class="thumb" onclick='openLightbox(<?php echo $imgsJson; ?>, 0)'>
                    <img src="<?php echo htmlspecialchars($imgSrc); ?>" alt="<?php echo htmlspecialchars($row['nome'] ?? ''); ?>" loading="lazy">
                    <div class="overlay" onclick="event.stopPropagation()">
                        <button class="overlay-btn text-blue-600"
                                onclick='openEdit(<?php echo $rowJson; ?>, <?php echo $imgsJson; ?>)'
                                title="Editar">
                            <i class="fa-solid fa-pen text-xs"></i>
                        </button>
                        <button class="overlay-btn text-rose-600"
                                onclick="askDelete(<?php echo intval($row['id']); ?>)"
                                title="Eliminar">
                            <i class="fa-solid fa-trash text-xs"></i>
                        </button>
                        <?php if (count($files) > 1): ?>
                        <button class="overlay-btn text-slate-600"
                                onclick='openLightbox(<?php echo $imgsJson; ?>, 0)'
                                title="Ver fotos">
                            <i class="fa-solid fa-images text-xs"></i>
                        </button>
                        <?php endif; ?>
                    </div>
                </div>

                <p class="text-[8px] font-black text-rose-600 uppercase tracking-wider">#<?php echo htmlspecialchars($row['codigo'] ?? ''); ?></p>
                <h3 class="font-bold text-slate-800 text-xs truncate"><?php echo htmlspecialchars($row['nome']  ?? ''); ?></h3>
                <p class="text-[9px] text-slate-400 font-semibold truncate"><?php echo htmlspecialchars($row['marca'] ?? ''); ?></p>

                <?php if ($recentEdit): ?>
                <span class="badge-edited">
                    <i class="fa-solid fa-clock-rotate-left" style="font-size:6px;"></i>
                    Editado Recentemente
                </span>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <p id="no-results" class="text-center text-slate-400 font-semibold mt-12 hidden">Nenhum produto encontrado.</p>
    </div>
</div>

<!-- ── EDIT LAYER ─────────────────────────────────────────────────────────── -->
<div id="edit-layer" class="layer">
    <div class="p-5 border-b flex justify-between items-center bg-white flex-shrink-0">
        <div>
            <h2 class="text-xl font-black italic uppercase">Editar <span class="text-blue-600">Produto</span></h2>
            <p id="edit-sku-label" class="text-xs text-slate-400 font-semibold mt-0.5"></p>
        </div>
        <button onclick="closeEdit()" class="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center hover:bg-rose-600 hover:text-white transition-all">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>

    <div class="flex-1 overflow-y-auto">
        <!-- action="" garante que submete sempre para o ficheiro actual -->
        <form method="POST" action="" enctype="multipart/form-data" id="edit-form" class="p-6 md:p-8 max-w-lg mx-auto flex flex-col gap-4">
            <input type="hidden" name="edit_product" value="1">
            <input type="hidden" name="id" id="edit-id">

            <!-- Current images strip -->
            <div>
                <p class="text-[9px] font-black uppercase text-slate-400 mb-2">Fotos actuais</p>
                <div id="edit-imgs-strip" class="edit-img-strip"></div>
            </div>

            <div class="field-group">
                <label class="field-label">Peça / Componente</label>
                <input type="text" name="nome" id="edit-nome" required class="field-input">
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div class="field-group">
                    <label class="field-label">SKU</label>
                    <input type="text" name="codigo" id="edit-codigo" required class="field-input">
                </div>
                <div class="field-group">
                    <label class="field-label">Marca</label>
                    <select name="marca" id="edit-marca" class="field-input">
                        <option value="MULTIMARCAS">MULTIMARCAS</option>
                        <option value="VOLVO">VOLVO</option>
                        <option value="SCANIA">SCANIA</option>
                        <option value="MERCEDES">MERCEDES BENZ</option>
                        <option value="HINO">HINO</option>
                        <option value="DAF">DAF</option>
                        <option value="MAN">MAN</option>
                        <option value="IVECO">IVECO</option>
                    </select>
                </div>
            </div>
            <div class="field-group">
                <label class="field-label">Especificações / Descrição</label>
                <textarea name="descricao" id="edit-desc" rows="4" class="field-input resize-none"></textarea>
            </div>
            <div class="field-group border-dashed border-2 py-5 text-center cursor-pointer hover:border-blue-500 transition relative overflow-hidden">
                <input type="file" name="imagens[]" multiple class="absolute inset-0 opacity-0 cursor-pointer w-full h-full" accept="image/*" id="edit-file-input" onchange="previewEditFiles(this)">
                <i class="fa-solid fa-camera-rotate text-slate-300 block text-xl mb-1"></i>
                <span class="text-[10px] font-bold text-slate-400 uppercase">Substituir Fotos (Opcional)</span>
                <p id="edit-file-names" class="text-[9px] text-blue-500 font-semibold mt-1"></p>
            </div>

            <div class="flex gap-3">
                <button type="button" onclick="closeEdit()" class="flex-1 py-4 rounded-2xl border border-slate-200 font-bold text-sm text-slate-600 hover:bg-slate-50 transition">Cancelar</button>
                <button type="submit" class="btn-submit btn-blue flex-1">
                    <i class="fa-solid fa-floppy-disk mr-2"></i>Guardar Alterações
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ── MAIN LAYOUT ─────────────────────────────────────────────────────────── -->
<main class="main-grid">

    <!-- LEFT: Add form -->
    <section class="p-6 md:p-8 flex flex-col bg-white border-r overflow-y-auto">
        <div class="flex justify-between mb-8">
            <div class="flex items-center gap-2">
                <div class="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center text-white font-black text-sm">M</div>
                <span class="font-black text-xs uppercase tracking-wider">Maufu OS v2.1</span>
            </div>
            <button onclick="toggleInv()" class="text-[10px] font-black uppercase text-rose-600 hover:underline">
                Stock <i class="fa-solid fa-layer-group ml-1"></i>
            </button>
        </div>

        <h1 class="text-4xl font-black italic uppercase mb-8">
            Novo <span class="text-rose-600">Registo</span>
        </h1>

        <!-- action="" garante POST para o ficheiro actual -->
        <form method="POST" action="" enctype="multipart/form-data" id="add-form" class="flex flex-col gap-4">
            <input type="hidden" name="add_product" value="1">
            <div class="field-group">
                <label class="field-label">Peça / Componente</label>
                <input type="text" name="nome" placeholder="Ex: Filtro de Combustível" required class="field-input" autocomplete="off">
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div class="field-group">
                    <label class="field-label">SKU</label>
                    <input type="text" name="codigo" placeholder="#MF-..." required class="field-input" autocomplete="off">
                </div>
                <div class="field-group">
                    <label class="field-label">Marca</label>
                    <select name="marca" class="field-input">
                        <option value="MULTIMARCAS">MULTIMARCAS</option>
                        <option value="VOLVO">VOLVO</option>
                        <option value="SCANIA">SCANIA</option>
                        <option value="MERCEDES">MERCEDES BENZ</option>
                        <option value="HINO">HINO</option>
                        <option value="DAF">DAF</option>
                        <option value="MAN">MAN</option>
                        <option value="IVECO">IVECO</option>
                    </select>
                </div>
            </div>
            <div class="field-group">
                <label class="field-label">Especificações</label>
                <textarea name="descricao" rows="3" class="field-input resize-none" placeholder="Dimensões, compatibilidade, OEM..."></textarea>
            </div>
            <div class="field-group border-dashed border-2 py-6 text-center cursor-pointer hover:border-rose-500 transition relative overflow-hidden">
                <input type="file" name="imagens[]" id="img-main" multiple class="absolute inset-0 opacity-0 cursor-pointer w-full h-full" accept="image/*" onchange="previewAddFiles(this)">
                <i class="fa-solid fa-camera text-slate-300 mb-2 block text-xl"></i>
                <span class="text-[10px] font-bold text-slate-400 uppercase">Anexar Fotos</span>
                <p id="add-file-names" class="text-[9px] text-rose-500 font-semibold mt-1"></p>
            </div>
            <button type="submit" class="btn-submit">
                <i class="fa-solid fa-plus mr-2"></i>Confirmar Registo
            </button>
        </form>
    </section>

    <!-- RIGHT: Hero -->
    <section class="hidden lg:block relative bg-slate-900 overflow-hidden">
        <img src="https://images.unsplash.com/photo-1592838064575-70ed626d3a0e?auto=format&fit=crop&q=80&w=1200"
             class="absolute inset-0 w-full h-full object-cover opacity-40">
        <div class="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent"></div>
        <div class="absolute bottom-16 left-16 z-10">
            <p class="text-rose-500 font-black text-xs uppercase tracking-widest mb-3">Maufu Logistics OS</p>
            <h2 class="text-[5vw] font-black italic uppercase text-white leading-none">Fast<br><span class="text-rose-600">Cargo</span></h2>
            <p class="text-slate-400 text-sm font-semibold mt-4 max-w-xs">Gestão inteligente de peças e componentes para frotas pesadas.</p>
        </div>
        <!-- Live counter -->
        <div class="absolute top-8 right-8 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-5 text-white">
            <p class="text-xs font-black uppercase text-rose-400 mb-1">Total em Stock</p>
            <p class="text-4xl font-black"><?php echo count($produtos_array); ?></p>
            <p class="text-xs text-slate-400 font-semibold">produtos</p>
        </div>
    </section>
</main>

<!-- ── SCRIPTS ─────────────────────────────────────────────────────────────── -->
<script>
// ─── TOAST ───────────────────────────────────────────────────────────────────
function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3500);
}

<?php
$msg = $_GET['msg'] ?? '';
if ($msg === 'success')  echo "showToast('✅ Produto registado com sucesso!');";
if ($msg === 'updated')  echo "showToast('🔄 Produto atualizado com sucesso!');";
if ($msg === 'deleted')  echo "showToast('🗑️ Produto eliminado!');";
$err = $_GET['error'] ?? '';
if ($err === 'duplicate') echo "showToast('❌ SKU já existe! Use um código único.');";
if ($err === 'empty')     echo "showToast('⚠️ Nome e SKU são obrigatórios.');";
if ($err === 'invalid')   echo "showToast('⚠️ ID inválido.');";
?>

// ─── LAYER TOGGLE ─────────────────────────────────────────────────────────────
function toggleInv() {
    document.getElementById('inventory-layer').classList.toggle('open');
}

// ─── EDIT ─────────────────────────────────────────────────────────────────────
function openEdit(data, imgs) {
    document.getElementById('inventory-layer').classList.remove('open');

    document.getElementById('edit-id').value     = data.id;
    document.getElementById('edit-nome').value   = data.nome    || '';
    document.getElementById('edit-codigo').value = data.codigo  || '';
    document.getElementById('edit-desc').value   = data.descricao || '';
    document.getElementById('edit-sku-label').textContent = 'SKU: #' + (data.codigo || '');

    const sel = document.getElementById('edit-marca');
    const marcaUpper = (data.marca || '').toUpperCase();
    let matched = false;
    for (let i = 0; i < sel.options.length; i++) {
        if (sel.options[i].value.toUpperCase() === marcaUpper) {
            sel.selectedIndex = i;
            matched = true;
            break;
        }
    }
    if (!matched) {
        // Remove previously injected custom option if any
        const existing = sel.querySelector('option[data-custom]');
        if (existing) existing.remove();
        const opt = document.createElement('option');
        opt.value = data.marca;
        opt.textContent = data.marca;
        opt.setAttribute('data-custom', '1');
        sel.appendChild(opt);
        sel.value = data.marca;
    }

    const strip = document.getElementById('edit-imgs-strip');
    strip.innerHTML = '';
    if (imgs && imgs.length > 0) {
        imgs.forEach((src, idx) => {
            if (src) {
                const img = document.createElement('img');
                img.src     = src;
                img.alt     = 'Foto ' + (idx + 1);
                img.title   = 'Ver foto';
                img.onclick = () => openLightbox(imgs, idx);
                strip.appendChild(img);
            }
        });
    } else {
        strip.innerHTML = '<p class="text-[10px] text-slate-400 font-semibold italic">Sem fotos</p>';
    }

    document.getElementById('edit-file-input').value = '';
    document.getElementById('edit-file-names').textContent = '';

    document.getElementById('edit-layer').classList.add('open');
}

function closeEdit() {
    document.getElementById('edit-layer').classList.remove('open');
}

// ─── DELETE CONFIRM ───────────────────────────────────────────────────────────
function askDelete(id) {
    document.getElementById('confirm-delete-link').href = '?delete=' + id;
    document.getElementById('confirm-modal').classList.add('open');
}
function closeConfirm() {
    document.getElementById('confirm-modal').classList.remove('open');
}

// ─── LIGHTBOX ─────────────────────────────────────────────────────────────────
let lbImages = [];
let lbIndex  = 0;

function openLightbox(imgs, idx) {
    lbImages = (imgs || []).filter(Boolean);
    lbIndex  = idx || 0;
    if (lbImages.length === 0) return;
    document.getElementById('lightbox-img').src = lbImages[lbIndex];
    document.getElementById('lightbox').classList.add('open');
    document.getElementById('lb-prev').style.display = lbImages.length > 1 ? 'flex' : 'none';
    document.getElementById('lb-next').style.display = lbImages.length > 1 ? 'flex' : 'none';
}
function closeLightbox() {
    document.getElementById('lightbox').classList.remove('open');
}
function lbShift(dir) {
    lbIndex = (lbIndex + dir + lbImages.length) % lbImages.length;
    document.getElementById('lightbox-img').src = lbImages[lbIndex];
}

// Keyboard navigation
document.addEventListener('keydown', e => {
    if (document.getElementById('lightbox').classList.contains('open')) {
        if (e.key === 'ArrowRight') lbShift(1);
        if (e.key === 'ArrowLeft')  lbShift(-1);
        if (e.key === 'Escape')     closeLightbox();
    } else if (document.getElementById('edit-layer').classList.contains('open')) {
        if (e.key === 'Escape') closeEdit();
    } else if (document.getElementById('inventory-layer').classList.contains('open')) {
        if (e.key === 'Escape') toggleInv();
    }
});

// ─── SEARCH / FILTER ──────────────────────────────────────────────────────────
function filterCards(q) {
    q = q.toLowerCase().trim();
    const cards = document.querySelectorAll('#cards-grid .prod-card');
    let visible = 0;
    cards.forEach(card => {
        const nome   = card.dataset.nome   || '';
        const codigo = card.dataset.codigo || '';
        const marca  = card.dataset.marca  || '';
        const match  = !q || nome.includes(q) || codigo.includes(q) || marca.includes(q);
        card.style.display = match ? '' : 'none';
        if (match) visible++;
    });
    document.getElementById('no-results').classList.toggle('hidden', visible > 0);
}

// ─── FILE PREVIEW ─────────────────────────────────────────────────────────────
function previewAddFiles(input) {
    document.getElementById('add-file-names').textContent =
        input.files.length > 0 ? input.files.length + ' foto(s) selecionada(s)' : '';
}
function previewEditFiles(input) {
    document.getElementById('edit-file-names').textContent =
        input.files.length > 0 ? input.files.length + ' nova(s) foto(s) selecionada(s)' : '';
}

// ─── PREVENT FORM RESUBMIT ────────────────────────────────────────────────────
if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href);
}
</script>
</body>
</html>