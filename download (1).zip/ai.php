<?php
/* ══════════════════════════════════════════════
   MAUFU AI — ai.php  (Light Edition)
   Busca produtos da base de dados Maufu
   ══════════════════════════════════════════════ */

$host = "sql100.infinityfree.com";
$user = "if0_40911457";
$pass = "tuLX88H1Oqp";
$db   = "if0_40911457_maufu";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Erro de Conexão: " . $conn->connect_error);
}

/* Encoding fix — dados em latin1 na BD */
function toUtf8(string $s): string {
    if (mb_check_encoding($s, 'UTF-8')) return $s;
    return mb_convert_encoding($s, 'UTF-8', 'ISO-8859-1');
}

/* Buscar todos os produtos */
$produtos_json = [];
$res = $conn->query("SELECT id, nome, codigo, marca, descricao, imagem_url FROM produtos ORDER BY id DESC LIMIT 2000");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $fotos = explode(",", $row['imagem_url'] ?? '');
        $foto  = trim($fotos[0] ?? '');

        /* Normaliza URL da imagem
           A BD guarda: "uploads/1234567_abc.jpg"
           O ficheiro está em: /maufu/uploads/1234567_abc.jpg
           URL final: https://dominio.com/maufu/uploads/1234567_abc.jpg
        */
        if (empty($foto)) {
            $foto = 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&q=80&w=400';
        } elseif (!str_starts_with($foto, 'http')) {
            $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $base  = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
            /* $foto já contém "uploads/ficheiro.jpg" — só precisa de /maufu/ na frente */
            $foto  = $base . '/maufu/' . ltrim($foto, '/');
        }

        $produtos_json[] = [
            'id'    => (int)$row['id'],
            'name'  => mb_strtoupper(toUtf8($row['nome']  ?? ''), 'UTF-8'),
            'code'  => $row['codigo'] ?? '',
            'brand' => mb_strtoupper(toUtf8($row['marca'] ?? ''), 'UTF-8'),
            'desc'  => toUtf8($row['descricao'] ?? ''),
            'img'   => $foto,
        ];
    }
}
$conn->close();

$total = count($produtos_json);
?>
<!DOCTYPE html>
<html lang="pt-pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MaufuAI — Encontre a Sua Peça</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Barlow:wght@400;500;600;700&family=Barlow+Condensed:ital,wght@0,400;0,600;0,700;1,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --red:#e8162e;
  --red2:#c2001f;
  --red-dim:rgba(232,22,46,.08);
  --red-mid:rgba(232,22,46,.22);
  --red-glow:rgba(232,22,46,.18);
  --ink:#181c28;
  --ink2:#0d1117;
  --muted:#7a8190;
  --border:#e4e7ef;
  --border2:#d0d4df;
  --off:#f5f6fa;
  --off2:#edeef4;
  --white:#fff;
  --wa:#25D366;
  --fd:'Bebas Neue',sans-serif;
  --fb:'Barlow',sans-serif;
  --fc:'Barlow Condensed',sans-serif;
  --nav:60px;
  --sb-w:248px;
}
html{height:100%;scroll-behavior:smooth}
body{font-family:var(--fb);background:var(--off);color:var(--ink);height:100%;overflow:hidden;display:flex;flex-direction:column;-webkit-font-smoothing:antialiased}
::-webkit-scrollbar{width:3px}
::-webkit-scrollbar-thumb{background:var(--red);border-radius:3px}

/* ── SIDEBAR ── */
.sb{
  position:fixed;top:0;left:0;bottom:0;width:var(--sb-w);
  background:var(--white);border-right:1px solid var(--border);
  display:flex;flex-direction:column;z-index:200;
  transition:transform .3s ease;
}
.sb-head{
  padding:16px 16px 14px;border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:9px;flex-shrink:0;
}
.sb-logo{
  width:34px;height:34px;border-radius:8px;background:var(--red);
  display:flex;align-items:center;justify-content:center;
  font-family:var(--fd);font-size:19px;color:#fff;flex-shrink:0;
  box-shadow:0 4px 12px var(--red-glow);
}
.sb-name{display:flex;flex-direction:column;line-height:1}
.sb-name .n1{font-family:var(--fd);font-size:15px;letter-spacing:.05em;color:var(--ink)}
.sb-name .n2{font-family:var(--fc);font-size:9px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:var(--red);margin-top:1px}
.sb-body{flex:1;overflow-y:auto;padding:12px 12px 0}
.btn-new{
  width:100%;display:flex;align-items:center;gap:7px;
  background:var(--red-dim);border:1px solid var(--red-mid);
  border-radius:9px;padding:9px 13px;
  color:var(--red);font-family:var(--fc);font-size:10px;
  font-weight:700;letter-spacing:.18em;text-transform:uppercase;
  cursor:pointer;transition:all .2s;margin-bottom:14px;
}
.btn-new:hover{background:rgba(232,22,46,.15);border-color:rgba(232,22,46,.35)}
.sb-lbl{
  font-family:var(--fc);font-size:9px;font-weight:700;
  letter-spacing:.28em;text-transform:uppercase;
  color:var(--muted);margin:10px 4px 7px;
  display:flex;align-items:center;gap:6px;
}
.sb-lbl::before{content:'';width:10px;height:1px;background:currentColor;border-radius:1px;display:inline-block}
.hist-item{
  display:flex;align-items:center;gap:7px;padding:7px 9px;
  border-radius:7px;cursor:pointer;font-size:12px;
  color:var(--muted);transition:background .15s,color .15s;
  text-decoration:none;
}
.hist-item:hover,.hist-item.cur{background:var(--off);color:var(--ink)}
.hist-item i{font-size:11px;flex-shrink:0}
.hist-item .ht{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.brand-pills{display:flex;flex-wrap:wrap;gap:5px;margin-top:2px}
.bp{
  padding:4px 10px;border-radius:20px;
  font-family:var(--fc);font-size:9px;font-weight:700;
  letter-spacing:.14em;text-transform:uppercase;
  background:var(--off);border:1px solid var(--border2);
  color:var(--muted);cursor:pointer;transition:all .18s;
}
.bp:hover,.bp.on{background:var(--red-dim);border-color:var(--red-mid);color:var(--red)}
.sb-footer{
  padding:12px;border-top:1px solid var(--border);flex-shrink:0;
}
.wa-link{
  display:flex;align-items:center;gap:7px;padding:9px 11px;
  background:rgba(37,211,102,.07);border:1px solid rgba(37,211,102,.22);
  border-radius:8px;font-family:var(--fc);font-size:10px;
  font-weight:700;letter-spacing:.1em;color:#16a34a;
  text-decoration:none;transition:background .2s;
}
.wa-link:hover{background:rgba(37,211,102,.14)}
.wa-link i{color:var(--wa);font-size:14px}

/* ── MAIN ── */
.main{margin-left:var(--sb-w);height:100vh;display:flex;flex-direction:column}

/* ── TOPBAR ── */
.tb{
  height:var(--nav);flex-shrink:0;
  display:flex;align-items:center;padding:0 20px;gap:9px;
  background:rgba(255,255,255,.9);backdrop-filter:blur(18px);
  border-bottom:1px solid var(--border);z-index:10;
}
.tb-title{font-family:var(--fd);font-size:19px;letter-spacing:.06em;color:var(--ink);display:flex;align-items:center;gap:7px}
.tb-title .r{color:var(--red)}
.ai-badge{
  font-family:var(--fc);font-size:9px;font-weight:700;
  letter-spacing:.2em;padding:3px 9px;border-radius:5px;
  background:var(--red-dim);border:1px solid var(--red-mid);color:var(--red);
}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:7px}
.tb-btn{
  height:32px;padding:0 11px;
  background:var(--off);border:1px solid var(--border2);
  border-radius:7px;display:flex;align-items:center;gap:5px;
  font-family:var(--fc);font-size:10px;font-weight:700;
  letter-spacing:.12em;text-transform:uppercase;
  color:var(--muted);cursor:pointer;transition:all .2s;text-decoration:none;white-space:nowrap;
}
.tb-btn:hover{color:var(--ink);border-color:var(--border)}
.mob-btn{
  display:none;width:32px;height:32px;background:var(--off);
  border:1px solid var(--border2);border-radius:7px;
  align-items:center;justify-content:center;
  color:var(--muted);cursor:pointer;font-size:14px;flex-shrink:0;
}

/* ── CHAT AREA ── */
.chat{flex:1;overflow-y:auto;padding-bottom:16px}

/* ── WELCOME ── */
.welcome{max-width:660px;margin:0 auto;padding:clamp(24px,4vh,56px) 16px 20px}
.w-badge{
  display:inline-flex;align-items:center;gap:7px;
  background:var(--red-dim);border:1px solid var(--red-mid);
  border-radius:20px;padding:4px 13px;
  font-family:var(--fc);font-size:9px;font-weight:700;
  letter-spacing:.26em;text-transform:uppercase;color:var(--red);
  margin-bottom:14px;
}
.w-dot{width:5px;height:5px;border-radius:50%;background:var(--red);animation:blink 1.8s infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.2}}
.w-title{
  font-family:var(--fd);font-size:clamp(30px,5vw,58px);
  line-height:.92;letter-spacing:.02em;color:var(--ink);margin-bottom:10px;
}
.w-title .r{color:var(--red)}
.w-sub{font-size:14px;color:var(--muted);line-height:1.7;max-width:440px;margin-bottom:22px}
.w-sub b{color:var(--ink);font-weight:600}
.chips{display:flex;flex-wrap:wrap;gap:7px}
.chip{
  display:inline-flex;align-items:center;gap:6px;
  background:var(--white);border:1.5px solid var(--border);
  border-radius:9px;padding:8px 13px;
  font-family:var(--fc);font-size:10px;font-weight:700;
  letter-spacing:.1em;text-transform:uppercase;
  color:var(--muted);cursor:pointer;transition:all .2s;
}
.chip:hover{background:var(--red-dim);border-color:var(--red-mid);color:var(--red)}
.chip i{font-size:12px;color:var(--red)}

/* ── MESSAGES ── */
.msgs{max-width:660px;margin:0 auto;padding:0 16px}
.msg{margin-bottom:18px;animation:msgIn .3s ease}
@keyframes msgIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}

/* User */
.mu{display:flex;justify-content:flex-end;gap:9px;align-items:flex-end}
.mu .bub{
  background:var(--ink);color:rgba(255,255,255,.9);
  border-radius:15px 15px 4px 15px;padding:10px 15px;
  max-width:78%;font-size:14px;line-height:1.65;word-break:break-word;
}
.mu .av{
  width:26px;height:26px;border-radius:50%;
  background:var(--off2);border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  font-size:10px;color:var(--muted);flex-shrink:0;
}
.img-prev{max-width:180px;border-radius:9px;display:block;margin-bottom:7px;border:1px solid rgba(255,255,255,.12)}

/* AI */
.mai{display:flex;gap:11px;align-items:flex-start}
.mai .aav{
  width:30px;height:30px;border-radius:8px;background:var(--red);
  display:flex;align-items:center;justify-content:center;
  font-family:var(--fd);font-size:16px;color:#fff;flex-shrink:0;
  box-shadow:0 3px 8px var(--red-glow);margin-top:1px;
}
.mai .cnt{flex:1;min-width:0}
.ai-nm{
  font-family:var(--fc);font-size:10px;font-weight:700;
  letter-spacing:.2em;text-transform:uppercase;color:var(--red);
  margin-bottom:6px;display:flex;align-items:center;gap:6px;
}
.ai-nm .mdl{
  font-size:9px;letter-spacing:.12em;color:var(--muted);
  background:var(--off);border:1px solid var(--border);
  padding:2px 7px;border-radius:4px;
}
.ai-txt{font-size:14px;line-height:1.72;color:var(--ink)}
.ai-txt p{margin-bottom:9px}
.ai-txt p:last-child{margin-bottom:0}
.ai-txt strong{font-weight:600;color:var(--ink)}
.hi{color:var(--red);font-weight:600}

/* Typing */
.typing{display:flex;gap:4px;align-items:center;padding:10px 0 4px}
.typing span{
  width:6px;height:6px;border-radius:50%;background:var(--border2);
  animation:td 1.4s ease-in-out infinite;
}
.typing span:nth-child(2){animation-delay:.2s}
.typing span:nth-child(3){animation-delay:.4s}
@keyframes td{0%,80%,100%{transform:scale(.55);opacity:.4}40%{transform:scale(1);opacity:1}}

/* AI analyzing */
.analyzing{
  display:flex;gap:8px;align-items:center;padding:10px 0 4px;
  font-family:var(--fc);font-size:10px;font-weight:700;
  letter-spacing:.16em;text-transform:uppercase;color:var(--muted);
}
.analyzing .sp{
  display:flex;gap:3px;align-items:center;
}
.analyzing .sp span{
  width:5px;height:5px;border-radius:50%;background:var(--red);
  animation:td 1.4s ease-in-out infinite;
}
.analyzing .sp span:nth-child(2){animation-delay:.2s}
.analyzing .sp span:nth-child(3){animation-delay:.4s}

/* Results grid */
.rg{
  display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));
  gap:9px;margin:12px 0 4px;
}
.rc{
  background:var(--white);border:1.5px solid var(--border);
  border-radius:11px;overflow:hidden;cursor:pointer;
  transition:all .3s cubic-bezier(.34,1.3,.64,1);position:relative;
}
.rc:hover{transform:translateY(-4px);border-color:var(--red-mid);box-shadow:0 10px 24px -5px rgba(232,22,46,.1)}
.rc-img{width:100%;aspect-ratio:4/3;object-fit:cover;display:block;background:var(--off2);filter:saturate(.85);transition:filter .3s}
.rc:hover .rc-img{filter:saturate(1)}
.rc-in{padding:9px}
.rc-brand{font-family:var(--fd);font-size:10px;letter-spacing:.18em;color:var(--red);margin-bottom:2px}
.rc-name{font-family:var(--fc);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--ink);line-height:1.25;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:4px}
.rc-code{font-size:9px;color:var(--muted);font-family:'Courier New',monospace;letter-spacing:.08em}
.rc-code::before{content:'#';color:var(--red);opacity:.7}
.rc-acts{display:flex;gap:4px;margin-top:7px}
.rc-wa{
  flex:1;height:27px;border:1px solid rgba(37,211,102,.35);
  border-radius:6px;background:transparent;
  color:#16a34a;font-family:var(--fc);font-size:9px;
  font-weight:700;letter-spacing:.12em;text-transform:uppercase;
  cursor:pointer;display:flex;align-items:center;justify-content:center;gap:4px;
  transition:all .18s;text-decoration:none;
}
.rc-wa:hover{background:var(--wa);color:#fff;border-color:var(--wa)}
.rc-cp{
  width:27px;height:27px;border-radius:6px;
  background:transparent;border:1px solid var(--border2);
  display:flex;align-items:center;justify-content:center;
  color:var(--muted);font-size:10px;cursor:pointer;transition:all .18s;
}
.rc-cp:hover{color:var(--ink);border-color:var(--border)}
.rc-stk{
  position:absolute;top:6px;right:6px;
  background:rgba(255,255,255,.88);backdrop-filter:blur(6px);
  border:1px solid rgba(74,222,128,.3);
  border-radius:4px;padding:2px 6px;
  font-family:var(--fc);font-size:7px;font-weight:700;
  letter-spacing:.16em;text-transform:uppercase;color:#16a34a;
}

/* No results */
.nores{
  background:var(--white);border:1.5px solid var(--border);
  border-radius:11px;padding:18px;margin-top:10px;
  display:flex;align-items:center;gap:12px;
}
.nores i{font-size:20px;color:var(--border2);flex-shrink:0}
.nores p{font-size:13px;color:var(--muted);line-height:1.6}
.nores a{color:var(--wa);text-decoration:none;font-weight:600}

/* Actions row */
.ai-acts{display:flex;gap:5px;flex-wrap:wrap;margin-top:10px}
.aa{
  display:inline-flex;align-items:center;gap:5px;
  background:var(--off);border:1px solid var(--border);
  border-radius:7px;padding:5px 10px;
  font-family:var(--fc);font-size:9px;font-weight:700;
  letter-spacing:.12em;text-transform:uppercase;
  color:var(--muted);cursor:pointer;transition:all .18s;
}
.aa:hover{color:var(--ink);border-color:var(--border2);background:var(--off2)}
.aa i{font-size:10px}

/* Tip box */
.tip{
  margin-top:10px;padding:9px 12px;
  background:var(--off);border-radius:8px;
  border-left:2px solid var(--red);
  font-size:13px;color:var(--muted);line-height:1.6;
}
.tip i{color:var(--red);margin-right:5px;font-size:10px}

/* ── INPUT ── */
.inp-wrap{
  flex-shrink:0;padding:10px 16px 14px;
  border-top:1px solid var(--border);background:var(--off);
  position:relative;
}
.inp-wrap::before{
  content:'';position:absolute;top:-36px;left:0;right:0;height:36px;
  background:linear-gradient(to bottom,transparent,var(--off));pointer-events:none;
}
.inp-box{
  max-width:660px;margin:0 auto;
  background:var(--white);border:1.5px solid var(--border2);
  border-radius:14px;overflow:hidden;transition:border-color .2s,box-shadow .2s;
}
.inp-box:focus-within{border-color:var(--red);box-shadow:0 0 0 3px var(--red-dim)}
.img-strip{display:none;padding:9px 13px 0;gap:7px;flex-wrap:wrap}
.img-strip.on{display:flex}
.img-th{
  position:relative;width:52px;height:52px;border-radius:7px;
  overflow:hidden;border:1px solid var(--border2);flex-shrink:0;
}
.img-th img{width:100%;height:100%;object-fit:cover}
.rm-img{
  position:absolute;top:2px;right:2px;width:16px;height:16px;
  border-radius:50%;background:rgba(0,0,0,.55);
  display:flex;align-items:center;justify-content:center;
  font-size:8px;color:#fff;cursor:pointer;transition:background .15s;
}
.rm-img:hover{background:var(--red)}
.ta-row{display:flex;align-items:flex-end;padding:10px 13px;gap:8px}
.chtx{
  flex:1;background:transparent;border:none;outline:none;
  color:var(--ink);font-family:var(--fb);font-size:14px;
  resize:none;line-height:1.6;min-height:22px;max-height:120px;overflow-y:auto;
}
.chtx::placeholder{color:var(--muted)}
.ia{display:flex;align-items:center;gap:5px;flex-shrink:0}
.ib{
  width:32px;height:32px;border-radius:7px;
  background:var(--off);border:1px solid var(--border);
  display:flex;align-items:center;justify-content:center;
  color:var(--muted);font-size:13px;cursor:pointer;transition:all .18s;
}
.ib:hover{color:var(--ink);border-color:var(--border2)}
.send{
  width:32px;height:32px;border-radius:7px;background:var(--red);
  border:none;display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:12px;cursor:pointer;transition:all .2s;
  box-shadow:0 4px 12px var(--red-glow);
}
.send:hover{background:var(--red2);transform:scale(1.06)}
.send:disabled{background:var(--off2);border:1px solid var(--border);color:var(--border2);cursor:not-allowed;transform:none;box-shadow:none}
.inp-foot{
  display:flex;align-items:center;justify-content:center;
  padding:0 13px 8px;
  font-family:var(--fc);font-size:9px;font-weight:600;
  letter-spacing:.12em;text-transform:uppercase;color:var(--muted);
  gap:12px;
}
.inp-foot a{color:var(--muted);text-decoration:none;transition:color .18s}
.inp-foot a:hover{color:var(--ink)}

/* ── DROP OVERLAY ── */
.drop-ov{
  position:fixed;inset:0;z-index:999;
  background:rgba(245,246,250,.92);backdrop-filter:blur(14px);
  display:none;align-items:center;justify-content:center;
}
.drop-ov.on{display:flex}
.drop-box{
  width:260px;height:200px;border:2px dashed var(--red-mid);
  border-radius:18px;display:flex;flex-direction:column;
  align-items:center;justify-content:center;gap:10px;
  background:var(--red-dim);
}
.drop-box i{font-size:32px;color:var(--red)}
.drop-box p{font-family:var(--fc);font-size:12px;font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:var(--muted)}

/* ── TOAST ── */
.toast{
  position:fixed;bottom:90px;right:20px;z-index:9999;
  background:var(--ink);color:#fff;
  border-radius:10px;padding:9px 15px;
  display:flex;align-items:center;gap:7px;
  font-family:var(--fc);font-size:11px;font-weight:700;
  letter-spacing:.1em;text-transform:uppercase;
  box-shadow:0 8px 24px rgba(0,0,0,.15);
  animation:tIn .3s cubic-bezier(.34,1.56,.64,1);
  max-width:260px;
}
@keyframes tIn{from{opacity:0;transform:translateY(10px) scale(.9)}}
.toast i{color:#22c55e;font-size:13px;flex-shrink:0}

/* ── SB OVERLAY (mobile) ── */
.sb-ov{position:fixed;inset:0;background:rgba(0,0,0,.35);z-index:199;display:none}
.sb-ov.on{display:block}

/* ── RESPONSIVE ── */
@media(max-width:768px){
  :root{--sb-w:0px}
  .sb{transform:translateX(-100%);width:260px}
  .sb.open{transform:translateX(0);--sb-w:0px}
  .main{margin-left:0!important}
  .mob-btn{display:flex}
  .rg{grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:7px}
  .welcome{padding:20px 14px 16px}
  .msgs{padding:0 12px}
  .inp-wrap{padding:8px 12px 12px}
  .tb{padding:0 12px;gap:7px}
  .tb-btn span{display:none}
  .tb-btn{padding:0 9px}
  .chips{gap:6px}
  .chip{padding:7px 10px;font-size:9px}
  .w-title{font-size:clamp(28px,8vw,44px)}
  .mu .bub{max-width:88%}
  .ai-acts{gap:4px}
  .aa{padding:5px 8px;font-size:8px}
}
@media(max-width:380px){
  .rg{grid-template-columns:repeat(2,1fr)}
  .inp-foot{font-size:8px;gap:8px}
}
</style>
</head>
<body>

<div class="sb-ov" id="sbOv" onclick="closeSb()"></div>

<!-- ── SIDEBAR ── -->
<aside class="sb" id="sb">
  <div class="sb-head">
    <div class="sb-logo">M</div>
    <div class="sb-name">
      <span class="n1">MAUFU<span style="color:var(--red)">AI</span></span>
      <span class="n2">Assistente de Peças</span>
    </div>
  </div>
  <div class="sb-body">
    <button class="btn-new" onclick="newChat()"><i class="fa-solid fa-plus"></i>Nova Pesquisa</button>

    <p class="sb-lbl">Histórico</p>
    <a class="hist-item cur" href="#"><i class="fa-solid fa-message"></i><span class="ht">Inicio</span></a>

    <p class="sb-lbl">Filtrar por Marca</p>
    <div class="brand-pills">
      <span class="bp" onclick="brandSearch(this,'SCANIA')">SCANIA</span>
      <span class="bp" onclick="brandSearch(this,'IVECO')">IVECO</span>
      <span class="bp" onclick="brandSearch(this,'DAF')">DAF</span>
      <span class="bp" onclick="brandSearch(this,'MAN')">MAN</span>
      <span class="bp" onclick="brandSearch(this,'VOLVO')">VOLVO</span>
      <span class="bp" onclick="brandSearch(this,'MERCEDES')">MERCEDES</span>
      <span class="bp" onclick="brandSearch(this,'HINO')">HINO</span>
    </div>

    <p class="sb-lbl" style="margin-top:16px">Sugestões</p>
    <a class="hist-item" href="#" onclick="quick('Pastilhas travão SCANIA');return false">
      <i class="fa-solid fa-circle-stop" style="color:var(--red)"></i><span class="ht">Pastilhas travão SCANIA</span>
    </a>
    <a class="hist-item" href="#" onclick="quick('Faróis DAF XF frente');return false">
      <i class="fa-solid fa-lightbulb" style="color:var(--red)"></i><span class="ht">Faróis DAF XF</span>
    </a>
    <a class="hist-item" href="#" onclick="quick('Tensionador correia MAN');return false">
      <i class="fa-solid fa-rotate" style="color:var(--red)"></i><span class="ht">Tensionador MAN</span>
    </a>
    <a class="hist-item" href="#" onclick="quick('Bomba água Volvo FH');return false">
      <i class="fa-solid fa-droplet" style="color:var(--red)"></i><span class="ht">Bomba água Volvo</span>
    </a>
    <a class="hist-item" href="#" onclick="quick('Embraiagem IVECO');return false">
      <i class="fa-solid fa-gears" style="color:var(--red)"></i><span class="ht">Embraiagem IVECO</span>
    </a>
  </div>
  <div class="sb-footer">
    <a class="wa-link" href="https://wa.me/258848684494" target="_blank" rel="noopener">
      <i class="fa-brands fa-whatsapp"></i> Falar com especialista
    </a>
  </div>
</aside>

<!-- ── MAIN ── -->
<div class="main">

  <div class="tb">
    <button class="mob-btn" onclick="toggleSb()"><i class="fa-solid fa-bars"></i></button>
    <div class="tb-title">
      <span class="r" style="font-size:21px">M</span>AUFU <span class="ai-badge">AI</span>
    </div>
    <div class="tb-right">
      <a class="tb-btn" href="/maufu/catalogo.php"><i class="fa-solid fa-shop"></i> <span>Catálogo</span></a>
      <a class="tb-btn" href="https://wa.me/258848684494" target="_blank" rel="noopener" style="color:#16a34a">
        <i class="fa-brands fa-whatsapp"></i> <span>WhatsApp</span>
      </a>
    </div>
  </div>

  <div class="chat" id="chat">
    <div class="welcome" id="wlc">
      <div class="w-badge"><span class="w-dot"></span><?php echo $total; ?> peças em catálogo</div>
      <h1 class="w-title">Encontre a<br>sua <span class="r">Peça</span></h1>
      <p class="w-sub">Escreva o nome, referência, marca ou descrição. Pode também <b>enviar uma foto</b> da peça para identificação automática por IA.</p>
      <div class="chips">
        <button class="chip" onclick="quick('Cilindro embraiagem IVECO')"><i class="fa-solid fa-gears"></i>Embraiagem IVECO</button>
        <button class="chip" onclick="quick('Pastilhas travão SCANIA')"><i class="fa-solid fa-circle-stop"></i>Travão SCANIA</button>
        <button class="chip" onclick="quick('Faróis DAF')"><i class="fa-solid fa-lightbulb"></i>Faróis DAF</button>
        <button class="chip" onclick="quick('Tensionador correia MAN')"><i class="fa-solid fa-rotate"></i>Motor MAN</button>
        <button class="chip" onclick="quick('Volvo FH')"><i class="fa-solid fa-truck"></i>Volvo FH</button>
        <button class="chip" onclick="document.getElementById('fi').click()"><i class="fa-solid fa-camera"></i>Enviar foto</button>
      </div>
    </div>
    <div class="msgs" id="msgs"></div>
  </div>

  <div class="inp-wrap">
    <div class="inp-box" id="inpBox">
      <div class="img-strip" id="iStrip"></div>
      <div class="ta-row">
        <textarea class="chtx" id="tx" rows="1"
          placeholder="Escreva nome, referência ou código..."
          onkeydown="onKey(event)" oninput="resize(this)"></textarea>
        <div class="ia">
          <label class="ib" title="Imagem" for="fi"><i class="fa-solid fa-image"></i></label>
          <input type="file" id="fi" accept="image/*" multiple onchange="addFiles(this.files)" style="display:none">
          <label class="ib" title="Câmera" for="cam"><i class="fa-solid fa-camera"></i></label>
          <input type="file" id="cam" accept="image/*" capture="environment" onchange="addFiles(this.files)" style="display:none">
          <button class="send" id="sb2" onclick="send()" disabled><i class="fa-solid fa-arrow-up"></i></button>
        </div>
      </div>
    </div>
    <div class="inp-foot">
      <span>Maufu Peças · Matola A</span>
      <a href="tel:+258848684494"><i class="fa-solid fa-phone" style="font-size:8px;margin-right:3px"></i>+258 84 868 4494</a>
    </div>
  </div>
</div>

<div class="drop-ov" id="dOv">
  <div class="drop-box">
    <i class="fa-solid fa-cloud-arrow-up"></i>
    <p>Soltar imagem aqui</p>
  </div>
</div>

<script>
/* ── PRODUCTS from PHP ── */
const P = <?php echo json_encode($produtos_json, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
const WA = '258848684494';
let imgs = [], started = false, activeBrand = null;

/* ── ANTHROPIC API KEY ── */
/* Coloque aqui a sua chave API da Anthropic para análise de imagens */
const ANTHROPIC_API_KEY = 'SUA_CHAVE_API_AQUI';

/* ── HELPERS ── */
function resize(el){
  el.style.height='auto';
  el.style.height=Math.min(el.scrollHeight,120)+'px';
  document.getElementById('sb2').disabled = el.value.trim()==='' && imgs.length===0;
}
function onKey(e){ if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();if(!document.getElementById('sb2').disabled)send();} }
function showToast(m,ok=true){
  const t=document.createElement('div');t.className='toast';
  t.innerHTML=`<i class="fa-solid ${ok?'fa-circle-check':'fa-triangle-exclamation'}" style="color:${ok?'#22c55e':'#f59e0b'}"></i>${m}`;
  document.body.appendChild(t);
  setTimeout(()=>{t.style.opacity='0';t.style.transform='translateY(10px)';setTimeout(()=>t.remove(),300);},2800);
}
function scroll(){const c=document.getElementById('chat');setTimeout(()=>c.scrollTo({top:c.scrollHeight,behavior:'smooth'}),60)}

/* ── SIDEBAR ── */
function toggleSb(){document.getElementById('sb').classList.toggle('open');document.getElementById('sbOv').classList.toggle('on');}
function closeSb(){document.getElementById('sb').classList.remove('open');document.getElementById('sbOv').classList.remove('on');}
function newChat(){
  document.getElementById('msgs').innerHTML='';
  document.getElementById('wlc').style.display='';
  started=false;imgs=[];
  document.getElementById('iStrip').classList.remove('on');
  document.getElementById('iStrip').innerHTML='';
  document.getElementById('tx').value='';
  resize(document.getElementById('tx'));
  activeBrand=null;
  document.querySelectorAll('.bp').forEach(b=>b.classList.remove('on'));
  closeSb();
}

/* ── FILES ── */
function addFiles(files){
  Array.from(files).forEach(f=>{
    if(!f.type.startsWith('image/'))return;
    const r=new FileReader();
    r.onload=e=>{imgs.push({data:e.target.result,type:f.type});renderStrip();document.getElementById('sb2').disabled=false;};
    r.readAsDataURL(f);
  });
}
function renderStrip(){
  const s=document.getElementById('iStrip');s.innerHTML='';
  imgs.forEach((u,i)=>{
    const d=document.createElement('div');d.className='img-th';
    d.innerHTML=`<img src="${u.data}"><span class="rm-img" onclick="rmImg(${i})"><i class="fa-solid fa-xmark"></i></span>`;
    s.appendChild(d);
  });
  s.classList.toggle('on',imgs.length>0);
}
function rmImg(i){
  imgs.splice(i,1);renderStrip();
  if(imgs.length===0&&document.getElementById('tx').value.trim()==='')document.getElementById('sb2').disabled=true;
}

/* ── DRAG DROP ── */
document.addEventListener('dragover',e=>{e.preventDefault();document.getElementById('dOv').classList.add('on');});
document.addEventListener('dragleave',e=>{if(!e.relatedTarget)document.getElementById('dOv').classList.remove('on');});
document.addEventListener('drop',e=>{e.preventDefault();document.getElementById('dOv').classList.remove('on');if(e.dataTransfer.files.length)addFiles(e.dataTransfer.files);});

/* ── SEARCH ENGINE (texto) ── */
function search(q, brand){
  if(!q) return [];
  const raw = q.toLowerCase().replace(/[#\-]/g,'');
  const terms = raw.split(/\s+/).filter(Boolean);
  let r = P.filter(p=>{
    if(brand && p.brand!==brand) return false;
    const h=(p.name+' '+p.code+' '+p.brand+' '+p.desc).toLowerCase();
    return terms.some(t=>h.includes(t));
  });
  r = r.map(p=>{
    const h=(p.name+' '+p.code+' '+p.brand).toLowerCase();
    let s=0;
    terms.forEach(t=>{
      if(p.code.toLowerCase().includes(t))s+=12;
      if(p.brand.toLowerCase()===t)s+=6;
      if(p.name.toLowerCase().includes(t))s+=4;
    });
    return{...p,score:s};
  }).sort((a,b)=>b.score-a.score);
  return r.slice(0,9);
}

/* ── ANÁLISE DE IMAGEM COM ANTHROPIC AI ── */
async function analyzeImageWithAI(imageDataList, textHint){
  /* Prepara lista simplificada dos produtos para o contexto da IA */
  const productList = P.slice(0,500).map(p=>
    `ID:${p.id}|${p.brand}|${p.name}|REF:${p.code}`
  ).join('\n');

  const imageContent = imageDataList.map(img=>({
    type:'image',
    source:{
      type:'base64',
      media_type: img.type || 'image/jpeg',
      data: img.data.split(',')[1]
    }
  }));

  const systemPrompt = `Você é um especialista em peças para camiões pesados (SCANIA, IVECO, DAF, MAN, VOLVO, MERCEDES, HINO).
Analise a imagem enviada e identifique que tipo de peça é, marca provável e referência se visível.
Depois retorne APENAS um JSON válido com este formato exacto (sem markdown, sem texto antes ou depois):
{"keywords":["palavra1","palavra2","palavra3"],"brand":"MARCA_OU_VAZIO","description":"Descrição curta da peça em português"}
As keywords devem ser termos de pesquisa em português para encontrar esta peça no catálogo.`;

  const userText = textHint
    ? `Analise a imagem. O utilizador também escreveu: "${textHint}". Identifique a peça.`
    : 'Analise a imagem e identifique a peça de camião.';

  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages',{
      method:'POST',
      headers:{
        'Content-Type':'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version':'2023-06-01',
        'anthropic-dangerous-direct-browser-access':'true'
      },
      body: JSON.stringify({
        model:'claude-sonnet-4-20250514',
        max_tokens:400,
        system: systemPrompt,
        messages:[{
          role:'user',
          content:[
            ...imageContent,
            {type:'text',text:userText}
          ]
        }]
      })
    });

    if(!resp.ok) throw new Error('API error '+resp.status);
    const data = await resp.json();
    const raw = data.content.map(c=>c.text||'').join('').trim();
    /* Remove possíveis backticks */
    const clean = raw.replace(/```json|```/g,'').trim();
    return JSON.parse(clean);
  } catch(err){
    console.error('AI analyze error:',err);
    return null;
  }
}

/* Pesquisa baseada em análise AI */
function searchByAI(aiResult, textHint, brand){
  let allTerms = [...(aiResult?.keywords || [])];
  if(aiResult?.brand) allTerms.push(aiResult.brand);
  if(textHint) allTerms.push(...textHint.toLowerCase().split(/\s+/));

  const forceBrand = brand || aiResult?.brand || null;
  const q = allTerms.join(' ');

  return search(q, forceBrand);
}

/* ── WA LINK (com imagem real do produto) ── */
function waLink(p){
  const imgLine = p.img && p.img.startsWith('http')
    ? `%0A🖼️ *Imagem:* ${encodeURIComponent(p.img)}`
    : '';
  const m=`Olá! Tenho interesse nesta peça:%0A%0A🔧 *${encodeURIComponent(p.name)}*%0A🏭 *Marca:* ${p.brand}%0A🔖 *Ref:* %23${p.code}${imgLine}%0A%0AQual a disponibilidade e preço?`;
  return `https://wa.me/${WA}?text=${m}`;
}

function buildCards(res, q){
  if(!res.length){
    const wm=encodeURIComponent('Olá! Preciso de: '+q);
    return `<div class="nores"><i class="fa-regular fa-face-confused"></i><p>Nenhum resultado para "<strong>${q}</strong>".<br>Contacte um especialista via <a href="https://wa.me/${WA}?text=${wm}" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>.</p></div>`;
  }
  const cards=res.map(p=>`
    <div class="rc" onclick="window.open('${waLink(p)}','_blank','noopener')">
      <img class="rc-img" src="${p.img}" alt="${p.name}" loading="lazy"
           onerror="this.src='https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&q=80&w=400'">
      <span class="rc-stk">Em stock</span>
      <div class="rc-in">
        <p class="rc-brand">${p.brand}</p>
        <h4 class="rc-name">${p.name}</h4>
        ${p.code?`<p class="rc-code">${p.code}</p>`:''}
        <div class="rc-acts">
          <a class="rc-wa" href="${waLink(p)}" target="_blank" rel="noopener" onclick="event.stopPropagation()">
            <i class="fa-brands fa-whatsapp"></i>Pedir
          </a>
          <button class="rc-cp" onclick="event.stopPropagation();cp(${p.id})" title="Copiar">
            <i class="fa-solid fa-copy"></i>
          </button>
        </div>
      </div>
    </div>`).join('');
  return `<div class="rg">${cards}</div>`;
}

function cp(id){
  const p=P.find(x=>x.id===id);if(!p)return;
  const t=`${p.name} | ${p.brand} | Ref: #${p.code}\nMaufu Peças · +258 84 868 4494`;
  navigator.clipboard.writeText(t).then(()=>showToast('Copiado!')).catch(()=>showToast('Erro ao copiar',false));
}

/* ── GENERATE AI TEXT ── */
function aiText(q, res, hasImg, aiDesc){
  if(hasImg){
    if(aiDesc) {
      return res.length
        ? `A IA identificou: <strong>${aiDesc}</strong>. Encontrei <strong>${res.length}</strong> peça${res.length>1?'s':''} correspondente${res.length>1?'s':''}:`
        : `A IA identificou: <strong>${aiDesc}</strong>, mas não encontrei correspondência exacta. Contacte a equipa via WhatsApp com a foto.`;
    }
    return res.length
      ? `Analisei a imagem enviada. Encontrei <strong>${res.length}</strong> peça${res.length>1?'s':''} que podem corresponder:`
      : `Analisei a imagem mas não encontrei correspondência exacta no catálogo. Contacte a equipa via WhatsApp com a foto.`;
  }
  if(res.length){
    const brands=[...new Set(res.map(r=>r.brand))].join(', ');
    return `Encontrei <strong>${res.length}</strong> resultado${res.length>1?'s':''} para <span class="hi">"${q}"</span> — marcas: <strong>${brands}</strong>. Todos disponíveis em Matola A:`;
  }
  return `Sem resultados para <span class="hi">"${q}"</span> no catálogo actual. Tente o código de referência ou fale com o nosso especialista.`;
}

/* ── TIPS ── */
function getTip(q){
  const lq=q.toLowerCase();
  if(lq.includes('travão')||lq.includes('pastilha')||lq.includes('calço')||lq.includes('disco'))
    return '💡 Ao substituir pastilhas recomenda-se verificar também o estado dos discos e calços para garantir segurança máxima.';
  if(lq.includes('embraiagem')||lq.includes('embreagem')||lq.includes('cilindro'))
    return '💡 Num kit de embraiagem é aconselhável substituir disco, plato e rolamento ao mesmo tempo para evitar retrabalho.';
  if(lq.includes('faroi')||lq.includes('farói')||lq.includes('iluminação'))
    return '💡 Verifique sempre a regulação dos faróis após substituição para cumprir a inspecção técnica.';
  if(lq.includes('filtro')||lq.includes('óleo')||lq.includes('combustível')||lq.includes('ar'))
    return '💡 Substitua sempre filtro de óleo, ar e combustível na mesma revisão para proteger o motor.';
  if(lq.includes('tensionador')||lq.includes('correia'))
    return '💡 Substitua o tensionador e a correia em conjunto — uma correia nova num tensionador desgastado pode falhar rapidamente.';
  if(lq.includes('bomba')||lq.includes('água'))
    return '💡 Aproveite a desmontagem da bomba de água para verificar o estado do termostato e mangueiras do arrefecimento.';
  return '';
}

/* ── APPEND MSG ── */
function appendUser(txt, imgUrls){
  const ms=document.getElementById('msgs');
  const d=document.createElement('div');d.className='msg';
  const imgH=(imgUrls&&imgUrls.length)?imgUrls.map(u=>`<img class="img-prev" src="${u}" alt="">`).join(''):'';
  d.innerHTML=`<div class="mu"><div class="bub">${imgH}${txt?`<span>${txt}</span>`:''}</div><div class="av"><i class="fa-solid fa-user"></i></div></div>`;
  ms.appendChild(d);scroll();
}
function appendTyping(analyzing=false){
  const ms=document.getElementById('msgs');
  const t=document.getElementById('typD');if(t)t.remove();
  const d=document.createElement('div');d.className='msg';d.id='typD';
  const inner = analyzing
    ? `<div class="analyzing"><div class="sp"><span></span><span></span><span></span></div>A IA está a analisar a imagem…</div>`
    : `<div class="typing"><span></span><span></span><span></span></div>`;
  d.innerHTML=`<div class="mai"><div class="aav">M</div><div class="cnt"><div class="ai-nm">MaufuAI <span class="mdl">Catálogo v<?php echo $total; ?></span></div>${inner}</div></div>`;
  ms.appendChild(d);scroll();
}
function removeTyping(){const t=document.getElementById('typD');if(t)t.remove();}
function appendAI(html){
  const ms=document.getElementById('msgs');
  const d=document.createElement('div');d.className='msg';
  d.innerHTML=`<div class="mai"><div class="aav">M</div><div class="cnt"><div class="ai-nm">MaufuAI <span class="mdl">Catálogo</span></div><div class="ai-txt">${html}</div></div></div>`;
  ms.appendChild(d);scroll();
}

/* ── SEND ── */
async function send(){
  const tx=document.getElementById('tx');
  const q=tx.value.trim();
  const curImgs=[...imgs];
  if(!q&&!curImgs.length)return;

  if(!started){document.getElementById('wlc').style.display='none';started=true;}

  appendUser(q, curImgs.map(i=>i.data));

  tx.value='';tx.style.height='auto';
  imgs=[];renderStrip();
  document.getElementById('sb2').disabled=true;

  let res = [];
  let aiDesc = '';

  if(curImgs.length > 0){
    /* Análise de imagem com IA */
    appendTyping(true);
    const apiKey = ANTHROPIC_API_KEY;

    if(apiKey && apiKey !== 'SUA_CHAVE_API_AQUI'){
      /* Tenta análise real com Anthropic */
      try {
        const aiResult = await analyzeImageWithAI(curImgs, q);
        removeTyping();
        if(aiResult){
          aiDesc = aiResult.description || '';
          res = searchByAI(aiResult, q, activeBrand);
          /* Se não achou por AI, fallback para pesquisa texto */
          if(res.length === 0 && q) res = search(q, activeBrand);
        } else {
          /* Fallback: pesquisa por texto se houver */
          if(q) res = search(q, activeBrand);
        }
      } catch(e){
        removeTyping();
        if(q) res = search(q, activeBrand);
      }
    } else {
      /* Sem API key: pesquisa texto + fallback geral */
      await new Promise(r=>setTimeout(r,900));
      removeTyping();
      if(q){
        res = search(q, activeBrand);
      } else {
        /* Sem texto nem API: mostra todos os produtos de uma marca aleatória ou primeiros */
        res = P.slice(0,9);
      }
    }
  } else {
    /* Só texto */
    appendTyping(false);
    await new Promise(r=>setTimeout(r,600+Math.random()*400));
    removeTyping();
    res = search(q, activeBrand);
  }

  const intro = aiText(q, res, curImgs.length>0, aiDesc);
  const cards = buildCards(res, q||'peça');
  const tip = getTip(q);
  const tipHtml = tip ? `<div class="tip"><i class="fa-solid fa-circle-info"></i>${tip}</div>` : '';
  const wm = encodeURIComponent('Olá! Preciso de ajuda para: '+(q||'identificar uma peça (imagem enviada)'));
  const acts = `<div class="ai-acts">
    <button class="aa" onclick="window.open('https://wa.me/${WA}?text=${wm}','_blank','noopener')"><i class="fa-brands fa-whatsapp"></i>Falar com especialista</button>
    <button class="aa" onclick="newChat()"><i class="fa-solid fa-rotate-left"></i>Nova pesquisa</button>
  </div>`;

  appendAI(`<p>${intro}</p>${cards}${tipHtml}${acts}`);

  /* Histórico sidebar */
  if(q){
    const hl=document.querySelector('.sb-body .hist-item.cur');
    if(hl){const sp=hl.querySelector('.ht');if(sp)sp.textContent=q.substring(0,32);}
  }
}

/* ── QUICK / BRAND ── */
function quick(t){document.getElementById('tx').value=t;resize(document.getElementById('tx'));send();}
function brandSearch(el,brand){
  document.querySelectorAll('.bp').forEach(b=>b.classList.remove('on'));
  if(activeBrand===brand){activeBrand=null;}
  else{el.classList.add('on');activeBrand=brand;quick('peças '+brand);closeSb();}
}

/* ── INPUT WATCH ── */
document.getElementById('tx').addEventListener('input',function(){resize(this);});
</script>
</body>
</html>