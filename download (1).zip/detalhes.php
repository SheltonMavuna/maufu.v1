<?php
/**
 * MAUFU LOGISTICS OS V3.1 — DETALHES DO PRODUTO
 */

$host = "sql100.infinityfree.com";
$user = "if0_40911457";
$pass = "tuLX88H1Oqp";
$db   = "if0_40911457_maufu";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) { die("Erro de Conexão: " . $conn->connect_error); }
$conn->set_charset("utf8mb4");
$conn->query("SET NAMES 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'");

/* ── produto ──────────────────────────────────────────── */
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$id) { header('Location: catalogo.php'); exit; }

$stmt = $conn->prepare("SELECT * FROM produtos WHERE id = ? LIMIT 1");
$stmt->bind_param('i', $id);
$stmt->execute();
$produto = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$produto) { header('Location: catalogo.php'); exit; }

$fotos    = array_values(array_filter(explode(',', $produto['imagem_url'])));
$nome     = mb_strtoupper($produto['nome'], 'UTF-8');
$marca    = mb_strtoupper($produto['marca'], 'UTF-8');
$codigo   = $produto['codigo'];
$descricao = $produto['descricao'];
$img_principal = !empty($fotos) ? $fotos[0] : '';

/* ── produtos relacionados (mesma marca, excluindo o atual) ── */
$rel_stmt = $conn->prepare(
    "SELECT id, nome, marca, codigo, imagem_url FROM produtos 
     WHERE UPPER(marca) = ? AND id != ? 
     ORDER BY RAND() LIMIT 8"
);
$rel_stmt->bind_param('si', $marca, $id);
$rel_stmt->execute();
$relacionados_res = $rel_stmt->get_result();
$relacionados = [];
while ($r = $relacionados_res->fetch_assoc()) $relacionados[] = $r;
$rel_stmt->close();

/* ── se não há relacionados da mesma marca, pega aleatórios ── */
if (empty($relacionados)) {
    $rel2 = $conn->prepare("SELECT id, nome, marca, codigo, imagem_url FROM produtos WHERE id != ? ORDER BY RAND() LIMIT 8");
    $rel2->bind_param('i', $id);
    $rel2->execute();
    $res2 = $rel2->get_result();
    while ($r = $res2->fetch_assoc()) $relacionados[] = $r;
    $rel2->close();
}

$conn->close();

/* ── marcas URL param ─────────────────────────────────── */
$back_url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'catalogo.php';
?>
<!DOCTYPE html>
<html lang="pt-pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($nome); ?> — Maufu Peças, Lda</title>
<meta name="description" content="<?php echo htmlspecialchars($marca . ' · ' . $nome . ($codigo ? ' · Ref: '.$codigo : '') . ' — Maufu Peças, Lda. Matola, Moçambique.'); ?>">
<meta property="og:title" content="<?php echo htmlspecialchars($nome); ?> — Maufu Peças">
<meta property="og:description" content="<?php echo htmlspecialchars($marca . ($codigo ? ' · Ref: '.$codigo : '')); ?>">
<?php if ($img_principal): ?><meta property="og:image" content="<?php echo htmlspecialchars($img_principal); ?>"><?php endif; ?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Barlow:ital,wght@0,400;0,500;0,600;0,700;0,900;1,400;1,700&family=Barlow+Condensed:ital,wght@0,400;0,600;0,700;1,600;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
/* ===== RESET & TOKENS ===== */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
    --white:#ffffff;--off:#f6f7f9;--off2:#edeef2;--border:#e0e3eb;
    --red:#e8162e;--red-light:#fff1f2;--red-mid:#fecdd3;--red-dim:rgba(232,22,46,.07);
    --ink:#181c28;--muted:#7a8190;--wa:#25D366;
    --font-d:'Bebas Neue',sans-serif;--font-b:'Barlow',sans-serif;--font-c:'Barlow Condensed',sans-serif;
    --nav-h:70px;
    --sh-sm:0 2px 8px rgba(0,0,0,.06);--sh-md:0 6px 22px rgba(0,0,0,.08);--sh-lg:0 18px 44px rgba(0,0,0,.1);
    --sh-red:0 10px 28px -4px rgba(232,22,46,.3);--sh-wa:0 10px 28px -4px rgba(37,211,102,.35);
}
html{scroll-behavior:smooth}
body{font-family:var(--font-b);background:var(--off);color:var(--ink);overflow-x:hidden;-webkit-font-smoothing:antialiased}
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:var(--off2)}
::-webkit-scrollbar-thumb{background:var(--red);border-radius:4px}

/* ===== NAV ===== */
nav{
    position:fixed;top:0;left:0;right:0;z-index:1000;height:var(--nav-h);
    background:rgba(255,255,255,.92);
    backdrop-filter:blur(22px) saturate(180%);-webkit-backdrop-filter:blur(22px) saturate(180%);
    border-bottom:1px solid var(--border);
    display:flex;align-items:center;padding:0 clamp(14px,4vw,40px);
}
.nav-inner{width:100%;max-width:1400px;margin:0 auto;display:flex;align-items:center;gap:10px}
.nav-logo{display:flex;align-items:center;gap:10px;text-decoration:none;flex-shrink:0}
.nav-logo img{height:35px;width:auto;object-fit:contain}
.nav-logo-text{display:flex;flex-direction:column;line-height:1}
.nav-logo-text .t1{font-family:var(--font-d);font-size:19px;letter-spacing:.05em;color:var(--ink)}
.nav-logo-text .t2{font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:var(--red)}
.nav-sep{width:1px;height:26px;background:var(--border);margin:0 4px;flex-shrink:0}
.nav-right{margin-left:auto;display:flex;align-items:center;gap:8px}
.btn-ico{width:40px;height:40px;border-radius:10px;background:var(--off);border:1.5px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:14px;cursor:pointer;transition:all .2s;text-decoration:none}
.btn-ico:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}
.call-btn{display:flex;align-items:center;gap:7px;background:var(--red);color:#fff;border:none;border-radius:10px;padding:0 15px;height:40px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;cursor:pointer;transition:background .2s,transform .15s;box-shadow:var(--sh-red);text-decoration:none}
.call-btn:hover{background:#c2001f;transform:translateY(-1px)}
.call-btn .lbl{display:none}
@media(min-width:768px){.call-btn .lbl{display:inline}}

/* ===== BREADCRUMB ===== */
.breadcrumb-bar{
    margin-top:var(--nav-h);
    background:var(--white);
    border-bottom:1px solid var(--border);
    padding:12px clamp(14px,4vw,52px);
}
.breadcrumb{
    max-width:1400px;margin:0 auto;
    display:flex;align-items:center;gap:8px;flex-wrap:wrap;
}
.bc-item{
    font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.14em;
    text-transform:uppercase;color:var(--muted);text-decoration:none;
    transition:color .2s;
}
.bc-item:hover{color:var(--red)}
.bc-item.active{color:var(--ink)}
.bc-sep{color:var(--border);font-size:10px}

/* ===== PRODUCT DETAIL LAYOUT ===== */
.detail-wrap{
    max-width:1400px;margin:0 auto;
    padding:clamp(22px,3.5vw,44px) clamp(14px,4vw,52px);
    display:grid;
    grid-template-columns:1fr;
    gap:28px;
}
@media(min-width:900px){
    .detail-wrap{grid-template-columns:1fr 1fr;align-items:start}
}
@media(min-width:1200px){
    .detail-wrap{grid-template-columns:1.1fr .9fr}
}

/* ===== GALLERY ===== */
.gallery{position:sticky;top:calc(var(--nav-h) + 16px)}

/* Main image */
.gallery-main{
    position:relative;
    background:var(--white);
    border:1.5px solid var(--border);
    border-radius:22px;
    overflow:hidden;
    aspect-ratio:4/3;
    cursor:zoom-in;
}
.gallery-main::before{
    content:'';position:absolute;inset:0;z-index:1;
    background-image:
        linear-gradient(rgba(232,22,46,.04) 1px,transparent 1px),
        linear-gradient(90deg,rgba(232,22,46,.04) 1px,transparent 1px);
    background-size:28px 28px;pointer-events:none;
}
.gallery-main img{
    width:100%;height:100%;object-fit:cover;display:block;
    transition:transform .6s cubic-bezier(.34,1,.64,1);
}
.gallery-main:hover img{transform:scale(1.04)}

/* Brand tag on image */
.gal-brand-tag{
    position:absolute;top:14px;left:14px;z-index:3;
    background:rgba(24,28,40,.82);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
    border-radius:8px;padding:5px 12px;
    font-family:var(--font-d);font-size:13px;letter-spacing:.14em;color:#fff;
}

/* Image counter */
.gal-counter{
    position:absolute;bottom:14px;right:14px;z-index:3;
    background:rgba(24,28,40,.7);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
    border-radius:7px;padding:4px 11px;
    font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.18em;color:rgba(255,255,255,.8);
}

/* Zoom icon */
.gal-zoom{
    position:absolute;top:14px;right:14px;z-index:3;
    width:34px;height:34px;border-radius:8px;
    background:rgba(255,255,255,.88);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
    border:1px solid var(--border);
    display:flex;align-items:center;justify-content:center;
    font-size:12px;color:var(--muted);cursor:pointer;
    transition:all .2s;opacity:0;
}
.gallery-main:hover .gal-zoom{opacity:1}
.gal-zoom:hover{background:var(--red);color:#fff;border-color:var(--red)}

/* Thumbnails */
.gallery-thumbs{
    display:flex;gap:9px;margin-top:11px;overflow-x:auto;
    scrollbar-width:none;padding-bottom:2px;
}
.gallery-thumbs::-webkit-scrollbar{display:none}
.gal-thumb{
    flex:0 0 72px;height:72px;border-radius:12px;overflow:hidden;
    border:2px solid var(--border);cursor:pointer;
    transition:border-color .2s,transform .2s;
    background:var(--off2);
}
.gal-thumb img{width:100%;height:100%;object-fit:cover;display:block}
.gal-thumb.active,.gal-thumb:hover{border-color:var(--red);transform:scale(1.06)}

/* No image placeholder */
.no-img{
    width:100%;height:100%;
    display:flex;flex-direction:column;align-items:center;justify-content:center;
    gap:12px;color:var(--muted);
    background:linear-gradient(135deg,var(--off2),var(--off));
}
.no-img i{font-size:42px;opacity:.25}
.no-img span{font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;opacity:.4}

/* ===== PRODUCT INFO ===== */
.prod-info{}

/* Header */
.pi-eyebrow{
    display:flex;align-items:center;gap:9px;flex-wrap:wrap;
    margin-bottom:12px;
}
.pi-brand{
    font-family:var(--font-d);font-size:13px;letter-spacing:.18em;
    color:var(--red);text-transform:uppercase;
}
.pi-badge{
    display:inline-flex;align-items:center;gap:5px;
    background:rgba(74,222,128,.08);border:1px solid rgba(74,222,128,.22);
    border-radius:6px;padding:3px 10px 3px 7px;
    font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;
    color:#4ade80;
}
.pi-badge::before{
    content:'';width:5px;height:5px;border-radius:50%;background:#4ade80;
    box-shadow:0 0 0 2px rgba(74,222,128,.25);flex-shrink:0;animation:blink 1.8s infinite;
}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}

.pi-title{
    font-family:var(--font-d);
    font-size:clamp(32px,5vw,58px);
    letter-spacing:.025em;line-height:.9;
    color:var(--ink);
    margin-bottom:16px;
}

/* Meta grid */
.pi-meta{
    display:grid;grid-template-columns:1fr 1fr;gap:10px;
    margin-bottom:22px;
}
.pi-meta-item{
    background:var(--white);border:1.5px solid var(--border);border-radius:13px;
    padding:13px 15px;
    transition:border-color .2s;
}
.pi-meta-item:hover{border-color:var(--red-mid)}
.pi-meta-label{
    font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.28em;
    text-transform:uppercase;color:var(--muted);margin-bottom:5px;
    display:flex;align-items:center;gap:5px;
}
.pi-meta-label i{font-size:9px;color:var(--red)}
.pi-meta-value{
    font-family:var(--font-d);font-size:clamp(15px,2.2vw,19px);letter-spacing:.04em;
    color:var(--ink);line-height:1.1;
}
.pi-meta-value.code{font-family:'Courier New',monospace;font-size:15px;font-weight:700;color:var(--red)}

/* Separator */
.pi-sep{height:1px;background:linear-gradient(to right,var(--red),transparent 60%);opacity:.2;margin:18px 0}

/* Description */
.pi-desc-label{
    font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.28em;
    text-transform:uppercase;color:var(--muted);margin-bottom:10px;
    display:flex;align-items:center;gap:7px;
}
.pi-desc-label::before{content:'';width:14px;height:1.5px;background:var(--red);border-radius:2px;display:inline-block}
.pi-desc{
    font-size:14px;line-height:1.78;color:var(--muted);
    background:var(--white);border:1.5px solid var(--border);border-radius:13px;
    padding:16px 18px;margin-bottom:22px;
    position:relative;
}
.pi-desc::before{
    content:'';position:absolute;top:0;left:0;right:0;height:2px;
    background:linear-gradient(to right,var(--red),transparent 50%);
    border-radius:13px 13px 0 0;opacity:.35;
}
.pi-desc b{color:var(--ink);font-weight:600}
.pi-no-desc{
    font-family:var(--font-c);font-size:11px;font-weight:600;letter-spacing:.14em;
    text-transform:uppercase;color:var(--muted);opacity:.55;
    padding:14px 0;
}

/* Feature tags */
.pi-tags{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:22px}
.pi-tag{
    display:inline-flex;align-items:center;gap:5px;
    background:var(--off2);border:1px solid var(--border);border-radius:7px;
    padding:5px 11px;font-family:var(--font-c);font-size:10px;font-weight:700;
    letter-spacing:.14em;text-transform:uppercase;color:var(--muted);
}
.pi-tag i{font-size:9px;color:var(--red)}

/* ===== CTA BUTTONS ===== */
.pi-ctas{display:flex;flex-direction:column;gap:10px}

.btn-wa-main{
    display:flex;align-items:center;justify-content:center;gap:10px;
    background:var(--wa);color:#fff;border:none;border-radius:14px;
    padding:17px 24px;
    font-family:var(--font-c);font-size:13px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;
    cursor:pointer;transition:background .2s,transform .2s,box-shadow .2s;
    box-shadow:var(--sh-wa);text-decoration:none;width:100%;
}
.btn-wa-main:hover{background:#1da851;transform:translateY(-2px);box-shadow:0 14px 34px -6px rgba(37,211,102,.5)}
.btn-wa-main:active{transform:scale(.98)}
.btn-wa-main i{font-size:20px}

.btn-call-main{
    display:flex;align-items:center;justify-content:center;gap:10px;
    background:var(--red);color:#fff;border:none;border-radius:14px;
    padding:15px 24px;
    font-family:var(--font-c);font-size:13px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;
    cursor:pointer;transition:background .2s,transform .2s;
    box-shadow:var(--sh-red);text-decoration:none;width:100%;
}
.btn-call-main:hover{background:#c2001f;transform:translateY(-2px)}
.btn-call-main i{font-size:16px}

.btn-row{display:flex;gap:9px}
.btn-copy-main,.btn-share-main{
    flex:1;display:flex;align-items:center;justify-content:center;gap:8px;
    background:var(--white);border:1.5px solid var(--border);border-radius:12px;
    padding:13px 16px;
    font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;
    color:var(--muted);cursor:pointer;transition:all .2s;
}
.btn-copy-main:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}
.btn-share-main:hover{color:#2563eb;border-color:#bfdbfe;background:#eff6ff}

/* ===== INFO CARD (Empresa) ===== */
.info-card{
    background:var(--ink);border-radius:16px;padding:20px;
    margin-top:14px;position:relative;overflow:hidden;
}
.info-card::before{
    content:'';position:absolute;top:-50px;right:-50px;
    width:180px;height:180px;border-radius:50%;
    background:radial-gradient(circle,rgba(232,22,46,.1) 0%,transparent 65%);
    pointer-events:none;
}
.info-card-title{
    font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.28em;
    text-transform:uppercase;color:rgba(255,255,255,.3);margin-bottom:13px;
}
.info-card-row{
    display:flex;align-items:center;gap:10px;margin-bottom:9px;
}
.info-card-row:last-child{margin-bottom:0}
.info-card-ico{
    width:32px;height:32px;border-radius:8px;
    background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);
    display:flex;align-items:center;justify-content:center;
    font-size:11px;color:var(--red);flex-shrink:0;
}
.info-card-text{
    font-family:var(--font-c);font-size:11px;font-weight:600;letter-spacing:.07em;
    color:rgba(255,255,255,.55);
}
.info-card-text b{color:#fff;font-weight:700}

/* ===== LIGHTBOX ===== */
.lightbox{
    display:none;position:fixed;inset:0;z-index:9500;
    background:rgba(0,0,0,.94);
    align-items:center;justify-content:center;
    cursor:zoom-out;
}
.lightbox.open{display:flex}
.lightbox-img{
    max-width:92vw;max-height:90vh;
    object-fit:contain;border-radius:12px;
    animation:lbIn .3s cubic-bezier(.34,1.2,.64,1);
}
@keyframes lbIn{from{opacity:0;transform:scale(.88)}to{opacity:1;transform:scale(1)}}
.lb-close{
    position:fixed;top:18px;right:22px;z-index:9501;
    width:42px;height:42px;border-radius:11px;
    background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);
    display:flex;align-items:center;justify-content:center;
    font-size:16px;color:#fff;cursor:pointer;
    transition:background .2s;
}
.lb-close:hover{background:var(--red)}
.lb-nav{
    position:fixed;top:50%;transform:translateY(-50%);z-index:9501;
    width:46px;height:46px;border-radius:12px;
    background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.14);
    display:flex;align-items:center;justify-content:center;
    font-size:16px;color:#fff;cursor:pointer;transition:background .2s;
}
.lb-nav:hover{background:rgba(255,255,255,.2)}
.lb-prev{left:16px}
.lb-next{right:16px}
.lb-counter{
    position:fixed;bottom:22px;left:50%;transform:translateX(-50%);
    font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.2em;
    color:rgba(255,255,255,.45);
}

/* ===== RELATED PRODUCTS ===== */
.related-sec{
    background:linear-gradient(180deg,var(--off) 0%,var(--off2) 100%);
    border-top:1px solid var(--border);
    padding:clamp(40px,5vw,68px) clamp(14px,4vw,52px);
    position:relative;
}
.related-sec::before{
    content:'';position:absolute;inset:0;
    background-image:
        linear-gradient(rgba(232,22,46,.04) 1px,transparent 1px),
        linear-gradient(90deg,rgba(232,22,46,.04) 1px,transparent 1px);
    background-size:40px 40px;pointer-events:none;
}
.related-inner{max-width:1400px;margin:0 auto;position:relative;z-index:1}
.related-hdr{display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:24px;gap:14px;flex-wrap:wrap}
.s-eyebrow{font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.3em;text-transform:uppercase;color:var(--red);margin-bottom:9px;display:flex;align-items:center;gap:9px}
.s-eyebrow::before{content:'';width:20px;height:2px;background:var(--red);border-radius:2px;display:inline-block}
.s-title{font-family:var(--font-d);font-size:clamp(28px,4.5vw,52px);letter-spacing:.02em;line-height:.95;color:var(--ink)}
.s-title .ac{color:var(--red)}
.btn-ghost{display:inline-flex;align-items:center;gap:7px;color:var(--muted);text-decoration:none;padding:10px 15px;border-radius:10px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;border:1.5px solid var(--border);transition:all .2s;background:var(--white)}
.btn-ghost:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}

/* Related scroll row */
.rel-row{
    display:flex;gap:13px;overflow-x:auto;
    scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;
    padding-bottom:10px;scrollbar-width:none;cursor:grab;
}
.rel-row::-webkit-scrollbar{display:none}
.rel-row:active{cursor:grabbing}

/* Related card */
.rel-card{
    flex:0 0 calc(50% - 7px);scroll-snap-align:start;
    background:var(--white);border:1.5px solid var(--border);border-radius:16px;
    overflow:hidden;display:flex;flex-direction:column;
    transition:transform .38s cubic-bezier(.34,1.3,.64,1),box-shadow .38s;
    position:relative;cursor:pointer;
    box-shadow:0 2px 10px rgba(0,0,0,.05);
}
@media(min-width:600px){.rel-card{flex:0 0 calc(33.333% - 9px)}}
@media(min-width:1024px){.rel-card{flex:0 0 calc(20% - 11px)}}

.rel-card::before{
    content:'';position:absolute;left:0;top:0;bottom:0;width:3px;
    background:var(--red);z-index:2;transform:scaleY(0);transform-origin:bottom;
    transition:transform .3s cubic-bezier(.34,1.3,.64,1);
}
.rel-card:hover::before{transform:scaleY(1)}
.rel-card:hover{
    transform:translateY(-7px) scale(1.012);
    box-shadow:0 18px 40px -8px rgba(0,0,0,.12),0 0 0 1.5px var(--red-mid);
}
.rel-img{width:100%;aspect-ratio:4/3;overflow:hidden;background:var(--off2)}
.rel-img img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .5s cubic-bezier(.34,1,.64,1)}
.rel-card:hover .rel-img img{transform:scale(1.08)}
.rel-body{padding:11px 12px 13px;flex:1;display:flex;flex-direction:column;position:relative}
.rel-body::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(to right,var(--red),transparent 70%);opacity:.35}
.rel-brand{font-family:var(--font-d);font-size:10px;letter-spacing:.22em;text-transform:uppercase;color:var(--red);margin-bottom:3px}
.rel-name{font-family:var(--font-c);font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--ink);line-height:1.28;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;flex:1}
.rel-code{font-size:9px;color:var(--muted);font-family:'Courier New',monospace;letter-spacing:.1em;margin-top:4px}
.rel-code::before{content:'#';color:var(--red);opacity:.7;font-weight:700}
.rel-wa{
    margin-top:9px;height:30px;border:1px solid rgba(37,211,102,.4);border-radius:7px;
    background:transparent;color:#4ade80;
    font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;
    cursor:pointer;display:flex;align-items:center;justify-content:center;gap:5px;
    transition:background .2s,border-color .2s,color .2s;
}
.rel-wa:hover{background:var(--wa);border-color:var(--wa);color:#fff}

/* ===== FOOTER ===== */
footer{background:var(--ink);border-top:1px solid rgba(255,255,255,.05)}
.ft-cta-band{background:var(--red);padding:clamp(24px,3.5vw,38px) clamp(14px,4vw,52px);display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap}
.ft-cta-text h3{font-family:var(--font-d);font-size:clamp(22px,3.5vw,40px);letter-spacing:.03em;color:#fff;line-height:1;margin-bottom:5px}
.ft-cta-text p{font-family:var(--font-c);font-size:12px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.72)}
.ft-cta-actions{display:flex;gap:10px;flex-wrap:wrap}
.ft-cta-btn{display:inline-flex;align-items:center;gap:7px;padding:11px 20px;border-radius:10px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.17em;text-transform:uppercase;text-decoration:none;transition:all .2s}
.ft-cta-btn.wa{background:var(--wa);color:#fff;box-shadow:var(--sh-wa)}
.ft-cta-btn.wa:hover{background:#1da851;transform:translateY(-1px)}
.ft-cta-btn.ghost{background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.28)}
.ft-cta-btn.ghost:hover{background:rgba(255,255,255,.2)}
.ft-bot{padding:16px clamp(14px,4vw,52px);max-width:1400px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:9px}
.ft-copy{font-family:var(--font-c);font-size:10px;font-weight:600;letter-spacing:.2em;text-transform:uppercase;color:rgba(255,255,255,.2)}
.ft-pow{font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:rgba(255,255,255,.13)}

/* ===== WA FAB ===== */
.wa-fab{position:fixed;bottom:26px;right:26px;z-index:9000}
.wa-btn{width:56px;height:56px;border-radius:50%;background:#25D366;display:flex;align-items:center;justify-content:center;font-size:25px;color:#fff;text-decoration:none;box-shadow:0 8px 22px rgba(37,211,102,.42),0 2px 8px rgba(0,0,0,.14);transition:transform .2s,box-shadow .2s;position:relative}
.wa-btn::before{content:'';position:absolute;inset:-4px;border-radius:50%;background:rgba(37,211,102,.24);animation:waPulse 2.2s ease-in-out 1s infinite}
@keyframes waPulse{0%,100%{transform:scale(1);opacity:1}70%{transform:scale(1.5);opacity:0}}
.wa-btn:hover{transform:scale(1.1);box-shadow:0 12px 30px rgba(37,211,102,.52)}
.wa-notif{position:absolute;top:-3px;right:-3px;width:16px;height:16px;border-radius:50%;background:var(--red);border:2px solid var(--white);font-size:8px;font-weight:900;color:#fff;display:flex;align-items:center;justify-content:center}

/* ===== TOAST ===== */
.toast{position:fixed;top:calc(var(--nav-h) + 13px);right:16px;z-index:9100;background:var(--white);border:1px solid var(--border);border-radius:13px;padding:11px 17px;display:flex;align-items:center;gap:9px;box-shadow:var(--sh-lg);font-family:var(--font-c);font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--ink);animation:tIn .4s cubic-bezier(.34,1.56,.64,1);transition:opacity .3s,transform .3s}
@keyframes tIn{from{opacity:0;transform:translateX(34px) scale(.9)}}
.toast i{color:#22c55e;font-size:15px}

/* ===== ANIMATIONS ===== */
.fade-up{opacity:0;transform:translateY(20px);animation:fadeUp .5s cubic-bezier(.34,1.2,.64,1) forwards}
@keyframes fadeUp{to{opacity:1;transform:translateY(0)}}
.fade-up:nth-child(1){animation-delay:.05s}
.fade-up:nth-child(2){animation-delay:.12s}
.fade-up:nth-child(3){animation-delay:.18s}
</style>
</head>
<body>

<!-- ===== NAV ===== -->
<nav>
    <div class="nav-inner">
        <a href="/" class="nav-logo">
            <img src="img/logo_Maufu.png" alt="Maufu Peças">
            <div class="nav-logo-text">
                <span class="t1">MAUFU</span>
                <span class="t2">Peças &amp; Logística</span>
            </div>
        </a>
        <div class="nav-sep"></div>
        <div class="nav-right">
            <a href="catalogo.php" class="btn-ico" title="Catálogo" aria-label="Catálogo">
                <i class="fa-solid fa-book"></i>
            </a>
            <a href="/" class="btn-ico" title="Início" aria-label="Início">
                <i class="fa-solid fa-house"></i>
            </a>
            <a href="tel:+258848684494" class="call-btn" aria-label="Ligar agora">
                <i class="fa-solid fa-phone"></i>
                <span class="lbl">Ligar</span>
            </a>
        </div>
    </div>
</nav>

<!-- ===== BREADCRUMB ===== -->
<div class="breadcrumb-bar">
    <div class="breadcrumb">
        <a href="/" class="bc-item"><i class="fa-solid fa-house" style="font-size:10px"></i></a>
        <span class="bc-sep"><i class="fa-solid fa-chevron-right" style="font-size:8px"></i></span>
        <a href="catalogo.php" class="bc-item">Catálogo</a>
        <span class="bc-sep"><i class="fa-solid fa-chevron-right" style="font-size:8px"></i></span>
        <?php if ($marca): ?>
        <a href="catalogo.php?marca=<?php echo urlencode($marca); ?>" class="bc-item"><?php echo htmlspecialchars($marca); ?></a>
        <span class="bc-sep"><i class="fa-solid fa-chevron-right" style="font-size:8px"></i></span>
        <?php endif; ?>
        <span class="bc-item active" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            <?php echo htmlspecialchars($nome); ?>
        </span>
    </div>
</div>

<!-- ===== DETAIL SECTION ===== -->
<div class="detail-wrap">

    <!-- ===== GALLERY ===== -->
    <div class="gallery fade-up">
        <div class="gallery-main" id="galMain" onclick="openLightbox(currentImg)">
            <?php if ($img_principal): ?>
            <div class="gal-brand-tag"><?php echo htmlspecialchars($marca); ?></div>
            <button class="gal-zoom" onclick="event.stopPropagation();openLightbox(currentImg)" aria-label="Ampliar">
                <i class="fa-solid fa-magnifying-glass-plus"></i>
            </button>
            <?php if (count($fotos) > 1): ?>
            <div class="gal-counter" id="galCounter">1 / <?php echo count($fotos); ?></div>
            <?php endif; ?>
            <img src="<?php echo htmlspecialchars($img_principal); ?>"
                 alt="<?php echo htmlspecialchars($nome); ?>"
                 id="galMainImg"
                 onerror="this.parentElement.innerHTML='<div class=\'no-img\'><i class=\'fa-solid fa-image\'></i><span>Sem Imagem</span></div>'">
            <?php else: ?>
            <div class="no-img">
                <i class="fa-solid fa-image"></i>
                <span>Sem Imagem</span>
            </div>
            <?php endif; ?>
        </div>

        <?php if (count($fotos) > 1): ?>
        <div class="gallery-thumbs">
            <?php foreach ($fotos as $i => $foto): ?>
            <div class="gal-thumb <?php echo $i === 0 ? 'active' : ''; ?>"
                 onclick="switchImg(<?php echo $i; ?>, '<?php echo htmlspecialchars(addslashes($foto)); ?>')"
                 id="thumb<?php echo $i; ?>">
                <img src="<?php echo htmlspecialchars($foto); ?>"
                     alt="Foto <?php echo $i+1; ?>"
                     onerror="this.parentElement.style.display='none'">
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- ===== PRODUCT INFO ===== -->
    <div class="prod-info">

        <div class="fade-up">
            <div class="pi-eyebrow">
                <?php if ($marca): ?>
                <span class="pi-brand"><?php echo htmlspecialchars($marca); ?></span>
                <?php endif; ?>
                <span class="pi-badge">Em Stock</span>
            </div>

            <h1 class="pi-title"><?php echo htmlspecialchars($nome); ?></h1>
        </div>

        <div class="fade-up">
            <div class="pi-meta">
                <?php if ($codigo): ?>
                <div class="pi-meta-item">
                    <p class="pi-meta-label"><i class="fa-solid fa-barcode"></i> Referência</p>
                    <p class="pi-meta-value code"><?php echo htmlspecialchars($codigo); ?></p>
                </div>
                <?php endif; ?>
                <?php if ($marca): ?>
                <div class="pi-meta-item">
                    <p class="pi-meta-label"><i class="fa-solid fa-tag"></i> Marca</p>
                    <p class="pi-meta-value"><?php echo htmlspecialchars($marca); ?></p>
                </div>
                <?php endif; ?>
                <div class="pi-meta-item">
                    <p class="pi-meta-label"><i class="fa-solid fa-location-dot"></i> Disponível em</p>
                    <p class="pi-meta-value" style="font-size:14px">Matola A, Moz</p>
                </div>
                <div class="pi-meta-item">
                    <p class="pi-meta-label"><i class="fa-solid fa-truck-fast"></i> Entrega</p>
                    <p class="pi-meta-value" style="font-size:14px">Imediata 24h</p>
                </div>
            </div>
        </div>

        <div class="fade-up">
            <div class="pi-sep"></div>

            <?php if ($descricao): ?>
            <p class="pi-desc-label">Descrição</p>
            <div class="pi-desc"><?php echo nl2br(htmlspecialchars($descricao)); ?></div>
            <?php else: ?>
            <p class="pi-no-desc">Contacte-nos para informações detalhadas sobre esta peça.</p>
            <?php endif; ?>

            <!-- Feature tags -->
            <div class="pi-tags">
                <span class="pi-tag"><i class="fa-solid fa-shield-check"></i> Qualidade Garantida</span>
                <span class="pi-tag"><i class="fa-solid fa-bolt"></i> Stock Disponível</span>
                <span class="pi-tag"><i class="fa-solid fa-file-invoice"></i> Com Fatura</span>
                <?php if ($marca && in_array($marca, ['SCANIA','IVECO','DAF','MAN','VOLVO','MERCEDES','MERCEDES-BENZ'])): ?>
                <span class="pi-tag"><i class="fa-solid fa-star"></i> Marca Original</span>
                <?php endif; ?>
            </div>

            <!-- CTAs -->
            <div class="pi-ctas">
                <button class="btn-wa-main" onclick="contactWA()">
                    <i class="fa-brands fa-whatsapp"></i>
                    Pedir Informações via WhatsApp
                </button>
                <a href="tel:+258848684494" class="btn-call-main">
                    <i class="fa-solid fa-phone"></i>
                    Ligar Agora — +258 84 868 4494
                </a>
                <div class="btn-row">
                    <button class="btn-copy-main" onclick="copyProduct()">
                        <i class="fa-solid fa-copy"></i> Copiar Info
                    </button>
                    <button class="btn-share-main" onclick="shareProduct()">
                        <i class="fa-solid fa-share-nodes"></i> Partilhar
                    </button>
                </div>
            </div>

            <!-- Info empresa -->
            <div class="info-card">
                <p class="info-card-title">Informação da Empresa</p>
                <div class="info-card-row">
                    <div class="info-card-ico"><i class="fa-solid fa-building-columns"></i></div>
                    <p class="info-card-text">BCI (MZN): <b>1623 1592 11000 01</b></p>
                </div>
                <div class="info-card-row">
                    <div class="info-card-ico"><i class="fa-solid fa-receipt"></i></div>
                    <p class="info-card-text">NUIT: <b>400 753 581</b></p>
                </div>
                <div class="info-card-row">
                    <div class="info-card-ico"><i class="fa-solid fa-envelope"></i></div>
                    <p class="info-card-text"><b>maufulda@gmail.com</b></p>
                </div>
                <div class="info-card-row">
                    <div class="info-card-ico"><i class="fa-solid fa-location-dot"></i></div>
                    <p class="info-card-text">Av. União Africana, <b>Matola A</b></p>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- ===== RELATED PRODUCTS ===== -->
<?php if (!empty($relacionados)): ?>
<section class="related-sec">
    <div class="related-inner">
        <div class="related-hdr">
            <div>
                <p class="s-eyebrow">Poderá Gostar</p>
                <h2 class="s-title">Peças <span class="ac">Relacionadas</span></h2>
            </div>
            <a href="catalogo.php<?php echo $marca ? '?marca='.urlencode($marca) : ''; ?>" class="btn-ghost">
                Ver Todos <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>
        <div class="rel-row" id="relRow">
            <?php foreach ($relacionados as $i => $r):
                $rfotos = array_values(array_filter(explode(',', $r['imagem_url'])));
                $rimg   = !empty($rfotos) ? $rfotos[0] : '';
                $rnome  = mb_strtoupper($r['nome'], 'UTF-8');
                $rmarca = mb_strtoupper($r['marca'], 'UTF-8');
                $rcode  = $r['codigo'];
            ?>
            <div class="rel-card" onclick="window.location='detalhes.php?id=<?php echo $r['id']; ?>'">
                <div class="rel-img">
                    <img src="<?php echo htmlspecialchars($rimg); ?>"
                         alt="<?php echo htmlspecialchars($rnome); ?>"
                         loading="lazy"
                         onerror="this.src='https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&q=80&w=400'">
                </div>
                <div class="rel-body">
                    <?php if ($rmarca): ?><p class="rel-brand"><?php echo htmlspecialchars($rmarca); ?></p><?php endif; ?>
                    <h4 class="rel-name"><?php echo htmlspecialchars($rnome); ?></h4>
                    <?php if ($rcode): ?><p class="rel-code"><?php echo htmlspecialchars($rcode); ?></p><?php endif; ?>
                    <button class="rel-wa" onclick="event.stopPropagation();relContactWA(<?php echo $r['id']; ?>,'<?php echo htmlspecialchars(addslashes($rnome)); ?>','<?php echo htmlspecialchars(addslashes($rmarca)); ?>','<?php echo htmlspecialchars(addslashes($rcode)); ?>')">
                        <i class="fa-brands fa-whatsapp"></i>Contactar
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- ===== FOOTER ===== -->
<footer>
    <div class="ft-cta-band">
        <div class="ft-cta-text">
            <h3>Precisa de uma Peça?</h3>
            <p>Fale connosco agora — resposta imediata</p>
        </div>
        <div class="ft-cta-actions">
            <a href="https://wa.me/258848684494?text=Olá%2C%20vim%20do%20site%20Maufu%20Peças%20e%20preciso%20de%20ajuda." class="ft-cta-btn wa" target="_blank" rel="noopener">
                <i class="fa-brands fa-whatsapp"></i> WhatsApp
            </a>
            <a href="tel:+258848684494" class="ft-cta-btn ghost">
                <i class="fa-solid fa-phone"></i> Ligar Agora
            </a>
        </div>
    </div>
    <div class="ft-bot">
        <p class="ft-copy">© 2026 Maufu Peças, Lda. Todos os direitos reservados.</p>
        <p class="ft-pow">Powered by Primavera BSS</p>
    </div>
</footer>

<!-- ===== WA FAB ===== -->
<div class="wa-fab">
    <a href="https://wa.me/258848684494?text=Olá%2C%20vim%20do%20site%20Maufu%20Peças%20e%20gostaria%20de%20informações."
       class="wa-btn" target="_blank" rel="noopener" aria-label="WhatsApp">
        <i class="fa-brands fa-whatsapp"></i>
        <span class="wa-notif">1</span>
    </a>
</div>

<!-- ===== LIGHTBOX ===== -->
<div class="lightbox" id="lightbox" onclick="closeLightbox()">
    <button class="lb-close" onclick="closeLightbox()" aria-label="Fechar"><i class="fa-solid fa-xmark"></i></button>
    <?php if (count($fotos) > 1): ?>
    <button class="lb-nav lb-prev" onclick="event.stopPropagation();lbNav(-1)" aria-label="Anterior"><i class="fa-solid fa-chevron-left"></i></button>
    <button class="lb-nav lb-next" onclick="event.stopPropagation();lbNav(1)" aria-label="Próxima"><i class="fa-solid fa-chevron-right"></i></button>
    <?php endif; ?>
    <img src="" alt="Zoom" class="lightbox-img" id="lbImg" onclick="event.stopPropagation()">
    <span class="lb-counter" id="lbCounter"></span>
</div>

<script>
const WA_NUM  = '258848684494';
const PROD_ID = <?php echo $id; ?>;
const PROD    = {
    id:    <?php echo $id; ?>,
    name:  <?php echo json_encode($nome); ?>,
    brand: <?php echo json_encode($marca); ?>,
    code:  <?php echo json_encode($codigo); ?>,
    img:   <?php echo json_encode($img_principal); ?>,
    url:   window.location.href
};
const FOTOS = <?php echo json_encode($fotos); ?>;

let currentImg  = <?php echo $img_principal ? json_encode($img_principal) : "''"; ?>;
let currentFotoIdx = 0;

/* ── Gallery switch ─────────────────────────────── */
function switchImg(idx, src) {
    currentFotoIdx = idx;
    currentImg     = src;
    const mainImg  = document.getElementById('galMainImg');
    if (mainImg) {
        mainImg.style.opacity = '0';
        mainImg.style.transform = 'scale(.97)';
        setTimeout(() => {
            mainImg.src = src;
            mainImg.style.opacity = '1';
            mainImg.style.transform = 'scale(1)';
        }, 160);
    }
    // update thumbs
    document.querySelectorAll('.gal-thumb').forEach((t, i) => {
        t.classList.toggle('active', i === idx);
    });
    // update counter
    const ctr = document.getElementById('galCounter');
    if (ctr) ctr.textContent = (idx + 1) + ' / ' + FOTOS.length;
    // update lightbox img if open
    const lbImg = document.getElementById('lbImg');
    if (lbImg) lbImg.src = src;
    updateLbCounter();
}

/* ── Smooth img transition ──────────────────────── */
const mainImg = document.getElementById('galMainImg');
if (mainImg) {
    mainImg.style.transition = 'opacity .18s ease, transform .18s ease';
}

/* ── Lightbox ───────────────────────────────────── */
function openLightbox(src) {
    if (!src) return;
    const lb = document.getElementById('lightbox');
    document.getElementById('lbImg').src = src;
    updateLbCounter();
    lb.classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeLightbox() {
    document.getElementById('lightbox').classList.remove('open');
    document.body.style.overflow = '';
}
function lbNav(dir) {
    const next = (currentFotoIdx + dir + FOTOS.length) % FOTOS.length;
    switchImg(next, FOTOS[next]);
}
function updateLbCounter() {
    const ctr = document.getElementById('lbCounter');
    if (ctr && FOTOS.length > 1) {
        ctr.textContent = (currentFotoIdx + 1) + ' / ' + FOTOS.length;
    }
}

/* ── WhatsApp ───────────────────────────────────── */
function contactWA() {
    let imgUrl = PROD.img || '';
    if (imgUrl && !imgUrl.startsWith('http')) imgUrl = window.location.origin + '/' + imgUrl.replace(/^\//, '');
    const imgLine = imgUrl ? `%0A%F0%9F%93%B8 *Imagem:* ${encodeURIComponent(imgUrl)}` : '';
    const pageUrl = encodeURIComponent(PROD.url);
    const msg =
        `Olá! Tenho interesse na seguinte peça:%0A%0A` +
        `%F0%9F%94%A7 *Nome:* ${encodeURIComponent(PROD.name)}%0A` +
        `%F0%9F%8F%AD *Marca:* ${encodeURIComponent(PROD.brand)}%0A` +
        `%F0%9F%94%96 *Referência:* ${PROD.code ? encodeURIComponent('#' + PROD.code) : 'N/D'}` +
        imgLine +
        `%0A%0APoderia informar disponibilidade e preço?`;
    window.open(`https://wa.me/${WA_NUM}?text=${msg}`, '_blank', 'noopener');
}

function relContactWA(id, name, brand, code) {
    const msg =
        `Olá! Tenho interesse na seguinte peça:%0A%0A` +
        `%F0%9F%94%A7 *Nome:* ${encodeURIComponent(name)}%0A` +
        `%F0%9F%8F%AD *Marca:* ${encodeURIComponent(brand)}%0A` +
        `%F0%9F%94%96 *Referência:* ${code ? encodeURIComponent('#' + code) : 'N/D'}` +
        `%0A%0APoderia informar disponibilidade e preço?`;
    window.open(`https://wa.me/${WA_NUM}?text=${msg}`, '_blank', 'noopener');
}

/* ── Copy ───────────────────────────────────────── */
function copyProduct() {
    const txt =
        `${PROD.name}` +
        `\nMarca: ${PROD.brand}` +
        (PROD.code ? `\nReferência: #${PROD.code}` : '') +
        `\n\nVer em: ${PROD.url}` +
        `\nContacto: +258 84 868 4494`;
    navigator.clipboard.writeText(txt).then(() => showToast('Copiado para a área de transferência!')).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
        showToast('Copiado!');
    });
}

/* ── Share ──────────────────────────────────────── */
function shareProduct() {
    const data = {
        title: PROD.name + ' — Maufu Peças',
        text:  `${PROD.name} | ${PROD.brand}${PROD.code ? ' | Ref: #' + PROD.code : ''}`,
        url:   PROD.url
    };
    if (navigator.share) {
        navigator.share(data).catch(() => {});
    } else {
        navigator.clipboard.writeText(data.url).then(() => showToast('Link copiado para partilhar!')).catch(() => {});
    }
}

/* ── Toast ──────────────────────────────────────── */
function showToast(msg) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = `<i class="fa-solid fa-circle-check"></i>${msg}`;
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(34px)'; setTimeout(() => t.remove(), 350); }, 3000);
}

/* ── Keyboard ───────────────────────────────────── */
document.addEventListener('keydown', e => {
    if (document.getElementById('lightbox').classList.contains('open')) {
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft'  && FOTOS.length > 1) lbNav(-1);
        if (e.key === 'ArrowRight' && FOTOS.length > 1) lbNav(1);
    }
});

/* ── Related drag-scroll ────────────────────────── */
const relRow = document.getElementById('relRow');
if (relRow) {
    let isDragging = false, startX, scrollLeft;
    relRow.addEventListener('mousedown', e => { isDragging = true; startX = e.pageX - relRow.offsetLeft; scrollLeft = relRow.scrollLeft; relRow.style.userSelect = 'none'; });
    relRow.addEventListener('mouseleave', () => { isDragging = false; });
    relRow.addEventListener('mouseup', () => { isDragging = false; relRow.style.userSelect = ''; });
    relRow.addEventListener('mousemove', e => {
        if (!isDragging) return;
        e.preventDefault();
        relRow.scrollLeft = scrollLeft - (e.pageX - relRow.offsetLeft - startX) * 1.4;
    });
}

/* ── Touch swipe gallery ────────────────────────── */
if (FOTOS.length > 1) {
    let touchStartX = 0;
    const galEl = document.getElementById('galMain');
    if (galEl) {
        galEl.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
        galEl.addEventListener('touchend', e => {
            const dx = e.changedTouches[0].clientX - touchStartX;
            if (Math.abs(dx) > 42) {
                const next = dx < 0
                    ? (currentFotoIdx + 1) % FOTOS.length
                    : (currentFotoIdx - 1 + FOTOS.length) % FOTOS.length;
                switchImg(next, FOTOS[next]);
            }
        }, { passive: true });
    }
}
</script>
</body>
</html>