<?php
/**
 * MAUFU LOGISTICS OS V3.1 — CATÁLOGO COMPLETO
 */

$host = "sql100.infinityfree.com";
$user = "if0_40911457";
$pass = "tuLX88H1Oqp";
$db   = "if0_40911457_maufu";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) { die("Erro de Conexão: " . $conn->connect_error); }
$conn->set_charset("utf8mb4");
$conn->query("SET NAMES 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'");

/* ── filtros ──────────────────────────────────────────────── */
$marca_filter = isset($_GET['marca'])    ? strtoupper(trim($_GET['marca']))    : '';
$q_filter     = isset($_GET['q'])        ? trim($_GET['q'])                    : '';
$cat_filter   = isset($_GET['cat'])      ? trim($_GET['cat'])                  : '';
$sort         = isset($_GET['sort'])     ? trim($_GET['sort'])                 : 'recente';
$page         = isset($_GET['page'])     ? max(1, intval($_GET['page']))        : 1;
$per_page     = 20;
$offset       = ($page - 1) * $per_page;

/* ── query base ───────────────────────────────────────────── */
$where_clauses = [];
$params        = [];
$types         = '';

if ($marca_filter) {
    $where_clauses[] = "UPPER(marca) = ?";
    $params[]        = $marca_filter;
    $types          .= 's';
}
if ($q_filter) {
    $like = '%' . $q_filter . '%';
    $where_clauses[] = "(nome LIKE ? OR codigo LIKE ? OR marca LIKE ? OR descricao LIKE ?)";
    $params = array_merge($params, [$like, $like, $like, $like]);
    $types .= 'ssss';
}

$where_sql = $where_clauses ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

$order_sql = match($sort) {
    'az'      => 'ORDER BY nome ASC',
    'za'      => 'ORDER BY nome DESC',
    'marca'   => 'ORDER BY marca ASC, nome ASC',
    default   => 'ORDER BY id DESC',
};

/* ── total ────────────────────────────────────────────────── */
$count_sql  = "SELECT COUNT(*) as total FROM produtos $where_sql";
$count_stmt = $conn->prepare($count_sql);
if ($types) $count_stmt->bind_param($types, ...$params);
$count_stmt->execute();
$total_items = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = max(1, ceil($total_items / $per_page));
$count_stmt->close();

/* ── produtos ─────────────────────────────────────────────── */
$sql  = "SELECT * FROM produtos $where_sql $order_sql LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$p2   = array_merge($params, [$per_page, $offset]);
$t2   = $types . 'ii';
$stmt->bind_param($t2, ...$p2);
$stmt->execute();
$result = $stmt->get_result();

$produtos     = [];
$produtos_json = [];
while ($row = $result->fetch_assoc()) {
    $fotos        = array_filter(explode(',', $row['imagem_url']));
    $primeira     = !empty($fotos) ? reset($fotos) : '';
    $produtos[]   = $row + ['primeira_foto' => $primeira];
    $produtos_json[] = [
        'id'    => $row['id'],
        'name'  => mb_strtoupper($row['nome']),
        'code'  => $row['codigo'],
        'brand' => mb_strtoupper($row['marca']),
        'img'   => $primeira,
        'desc'  => $row['descricao'],
    ];
}
$stmt->close();

/* ── marcas para filtro ───────────────────────────────────── */
$marcas_res = $conn->query("SELECT DISTINCT UPPER(marca) as marca, COUNT(*) as qty FROM produtos GROUP BY marca ORDER BY qty DESC");
$marcas_list = [];
while ($r = $marcas_res->fetch_assoc()) $marcas_list[] = $r;

/* ── helper URL ───────────────────────────────────────────── */
function buildUrl(array $overrides = []): string {
    $params = array_merge([
        'marca' => $_GET['marca'] ?? '',
        'q'     => $_GET['q']     ?? '',
        'sort'  => $_GET['sort']  ?? 'recente',
        'page'  => $_GET['page']  ?? 1,
    ], $overrides);
    $params = array_filter($params, fn($v) => $v !== '' && $v !== null && $v !== 0 && $v !== 1 || in_array(array_search($v, $params), ['page']));
    return 'catalogo.php?' . http_build_query($params);
}
?>
<!DOCTYPE html>
<html lang="pt-pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Catálogo Completo — Maufu Peças, Lda</title>
<meta name="description" content="Catálogo completo de peças sobressalentes para veículos pesados. Scania, Iveco, DAF, MAN, Volvo — Matola, Moçambique.">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Barlow:ital,wght@0,400;0,500;0,600;0,700;0,900;1,400;1,700&family=Barlow+Condensed:ital,wght@0,400;0,600;0,700;1,600;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
/* ===== RESET & TOKENS ===== */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
    --white:#ffffff;--off:#f6f7f9;--off2:#edeef2;--border:#e0e3eb;
    --red:#e8162e;--red-light:#fff1f2;--red-mid:#fecdd3;--red-dim:rgba(232,22,46,.07);--red-glow:rgba(232,22,46,.22);
    --ink:#181c28;--muted:#7a8190;--wa:#25D366;
    --font-d:'Bebas Neue',sans-serif;--font-b:'Barlow',sans-serif;--font-c:'Barlow Condensed',sans-serif;
    --nav-h:70px;
    --sh-sm:0 2px 8px rgba(0,0,0,.06);--sh-md:0 6px 22px rgba(0,0,0,.08);--sh-lg:0 18px 44px rgba(0,0,0,.1);
    --sh-red:0 10px 28px -4px rgba(232,22,46,.3);--sh-wa:0 10px 28px -4px rgba(37,211,102,.35);
    --sidebar-w:270px;
}
html{scroll-behavior:smooth}
body{font-family:var(--font-b);background:var(--off);color:var(--ink);overflow-x:hidden;-webkit-font-smoothing:antialiased}
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:var(--off2)}
::-webkit-scrollbar-thumb{background:var(--red);border-radius:4px}

/* ===== NAV ===== */
nav{
    position:fixed;top:0;left:0;right:0;z-index:1000;height:var(--nav-h);
    background:rgba(255,255,255,.92);
    backdrop-filter:blur(22px) saturate(180%);-webkit-backdrop-filter:blur(22px) saturate(180%);
    border-bottom:1px solid var(--border);
    display:flex;align-items:center;padding:0 clamp(14px,4vw,40px);
}
.nav-inner{width:100%;max-width:1600px;margin:0 auto;display:flex;align-items:center;gap:10px}
.nav-logo{display:flex;align-items:center;gap:10px;text-decoration:none;flex-shrink:0}
.nav-logo img{height:35px;width:auto;object-fit:contain}
.nav-logo-text{display:flex;flex-direction:column;line-height:1}
.nav-logo-text .t1{font-family:var(--font-d);font-size:19px;letter-spacing:.05em;color:var(--ink)}
.nav-logo-text .t2{font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:var(--red)}
.nav-sep{width:1px;height:26px;background:var(--border);margin:0 6px;flex-shrink:0}
.nav-crumb{font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--red);display:none}
@media(min-width:768px){.nav-crumb{display:block}}
.nav-right{margin-left:auto;display:flex;align-items:center;gap:8px}
.nav-sw{display:none;align-items:center;background:var(--off);border:1.5px solid var(--border);border-radius:10px;padding:0 13px;height:40px;min-width:220px;transition:border-color .2s,box-shadow .2s}
@media(min-width:640px){.nav-sw{display:flex}}
.nav-sw:focus-within{border-color:var(--red);box-shadow:0 0 0 3px var(--red-dim)}
.nav-sw i{color:var(--muted);font-size:12px;flex-shrink:0}
.nav-sw input{background:transparent;border:none;outline:none;color:var(--ink);font-family:var(--font-b);font-size:13px;font-weight:500;width:100%;padding:0 9px}
.nav-sw input::placeholder{color:var(--muted)}
.btn-ico{width:40px;height:40px;border-radius:10px;background:var(--off);border:1.5px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:14px;cursor:pointer;transition:all .2s;text-decoration:none}
.btn-ico:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}
.call-btn{display:flex;align-items:center;gap:7px;background:var(--red);color:#fff;border:none;border-radius:10px;padding:0 15px;height:40px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;cursor:pointer;transition:background .2s,transform .15s;box-shadow:var(--sh-red);text-decoration:none}
.call-btn:hover{background:#c2001f;transform:translateY(-1px)}
.call-btn .lbl{display:none}
@media(min-width:768px){.call-btn .lbl{display:inline}}
.msrch-btn{display:flex}
@media(min-width:640px){.msrch-btn{display:none}}

/* ===== MOBILE SEARCH ===== */
.msrch-bar{position:fixed;top:var(--nav-h);left:0;right:0;z-index:990;background:var(--white);border-bottom:1px solid var(--border);padding:11px 15px;transform:translateY(-110%);transition:transform .3s ease}
.msrch-bar.open{transform:translateY(0)}
.msrch-bar input{width:100%;background:var(--off);border:1.5px solid var(--border);border-radius:10px;color:var(--ink);font-family:var(--font-b);font-size:15px;font-weight:500;padding:11px 15px;outline:none}
.msrch-bar input:focus{border-color:var(--red)}

/* ===== CATALOG HERO ===== */
.cat-hero{
    margin-top:var(--nav-h);
    background:var(--ink);
    padding:clamp(32px,5vw,52px) clamp(14px,4vw,52px);
    position:relative;overflow:hidden;
}
.cat-hero::before{
    content:'';position:absolute;inset:0;
    background-image:
        linear-gradient(rgba(232,22,46,.06) 1px,transparent 1px),
        linear-gradient(90deg,rgba(232,22,46,.06) 1px,transparent 1px);
    background-size:36px 36px;
    pointer-events:none;
}
.cat-hero::after{
    content:'';position:absolute;top:-120px;right:-80px;
    width:440px;height:440px;border-radius:50%;
    background:radial-gradient(circle,rgba(232,22,46,.12) 0%,transparent 65%);
    pointer-events:none;
}
.cat-hero-inner{max-width:1600px;margin:0 auto;position:relative;z-index:1}
.cat-hero-top{display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:16px;margin-bottom:22px}
.cat-hero-left{}
.cat-hero-eyebrow{
    font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.34em;text-transform:uppercase;
    color:rgba(255,255,255,.35);margin-bottom:9px;display:flex;align-items:center;gap:8px;
}
.cat-hero-eyebrow::before{content:'';width:18px;height:1.5px;background:var(--red);border-radius:2px;display:inline-block}
.cat-hero-title{
    font-family:var(--font-d);font-size:clamp(38px,6.5vw,80px);
    letter-spacing:.025em;line-height:.88;color:#fff;margin-bottom:10px;
}
.cat-hero-title .ac{color:var(--red)}
.cat-hero-sub{
    font-family:var(--font-c);font-size:13px;font-weight:500;letter-spacing:.06em;
    color:rgba(255,255,255,.42);
}
.cat-hero-sub b{color:rgba(255,255,255,.75);font-weight:600}

/* Quick stats */
.cat-hero-stats{display:flex;gap:clamp(16px,3vw,34px);flex-wrap:wrap}
.ch-stat{display:flex;flex-direction:column;gap:2px}
.ch-stat-val{font-family:var(--font-d);font-size:clamp(20px,2.8vw,28px);letter-spacing:.03em;color:#fff}
.ch-stat-val span{color:var(--red)}
.ch-stat-lbl{font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.24em;text-transform:uppercase;color:rgba(255,255,255,.28)}

/* Active filter strip */
.active-filters{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:18px}
.af-label{font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:rgba(255,255,255,.25)}
.af-chip{
    display:inline-flex;align-items:center;gap:6px;
    background:rgba(232,22,46,.18);border:1px solid rgba(232,22,46,.35);
    border-radius:6px;padding:4px 10px;
    font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;
    color:#ff8091;text-decoration:none;
}
.af-chip:hover{background:rgba(232,22,46,.28)}
.af-chip i{font-size:9px;opacity:.7}

/* ===== LAYOUT WRAPPER ===== */
.catalog-wrap{
    max-width:1600px;margin:0 auto;
    padding:clamp(22px,3vw,38px) clamp(14px,4vw,34px);
    display:grid;
    grid-template-columns:var(--sidebar-w) 1fr;
    gap:26px;
    align-items:start;
}
@media(max-width:1023px){.catalog-wrap{grid-template-columns:1fr}}

/* ===== SIDEBAR ===== */
.sidebar{
    background:var(--white);
    border:1.5px solid var(--border);
    border-radius:20px;
    overflow:hidden;
    position:sticky;top:calc(var(--nav-h) + 16px);
    display:none;
}
@media(min-width:1024px){.sidebar{display:block}}

.sb-section{border-bottom:1px solid var(--border);padding:18px}
.sb-section:last-child{border-bottom:none}
.sb-title{
    font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.3em;text-transform:uppercase;
    color:var(--muted);margin-bottom:13px;display:flex;align-items:center;gap:7px;
}
.sb-title::before{content:'';width:12px;height:1.5px;background:var(--red);border-radius:2px;display:inline-block}

/* Pesquisa sidebar */
.sb-search{
    display:flex;align-items:center;gap:9px;
    background:var(--off);border:1.5px solid var(--border);border-radius:10px;
    padding:0 12px;height:40px;transition:border-color .2s,box-shadow .2s;
}
.sb-search:focus-within{border-color:var(--red);box-shadow:0 0 0 3px var(--red-dim)}
.sb-search i{color:var(--muted);font-size:12px;flex-shrink:0}
.sb-search input{background:transparent;border:none;outline:none;color:var(--ink);font-family:var(--font-b);font-size:13px;width:100%}

/* Marcas */
.sb-brand-list{display:flex;flex-direction:column;gap:4px}
.sb-brand-btn{
    display:flex;align-items:center;justify-content:space-between;
    padding:9px 11px;border-radius:9px;border:none;background:transparent;
    cursor:pointer;transition:background .2s,color .2s;width:100%;text-align:left;text-decoration:none;
}
.sb-brand-btn:hover{background:var(--red-dim)}
.sb-brand-left{display:flex;align-items:center;gap:9px}
.sb-brand-dot{width:6px;height:6px;border-radius:50%;background:var(--border);flex-shrink:0;transition:background .2s}
.sb-brand-name{font-family:var(--font-d);font-size:15px;letter-spacing:.06em;color:var(--ink)}
.sb-brand-qty{
    font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.1em;
    color:var(--muted);background:var(--off2);border-radius:5px;padding:2px 7px;
}
.sb-brand-btn.active{background:var(--red-dim)}
.sb-brand-btn.active .sb-brand-dot{background:var(--red)}
.sb-brand-btn.active .sb-brand-name{color:var(--red)}
.sb-brand-btn.active .sb-brand-qty{background:var(--red-light);color:var(--red)}

/* Sort sidebar */
.sb-sort-list{display:flex;flex-direction:column;gap:4px}
.sb-sort-btn{
    display:flex;align-items:center;gap:9px;
    padding:8px 11px;border-radius:9px;border:none;background:transparent;
    cursor:pointer;transition:background .2s;width:100%;text-align:left;font-family:var(--font-c);font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);
    text-decoration:none;
}
.sb-sort-btn i{font-size:11px;width:16px;text-align:center;color:var(--muted)}
.sb-sort-btn:hover{background:var(--off2);color:var(--ink)}
.sb-sort-btn.active{background:var(--red-dim);color:var(--red)}
.sb-sort-btn.active i{color:var(--red)}

/* Limpar */
.sb-clear{
    display:flex;align-items:center;justify-content:center;gap:7px;
    background:var(--off);border:1.5px solid var(--border);border-radius:9px;
    padding:9px;width:100%;cursor:pointer;
    font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;
    color:var(--muted);transition:all .2s;text-decoration:none;
}
.sb-clear:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}

/* ===== MAIN CONTENT ===== */
.main-content{}

/* Mobile toolbar */
.mob-toolbar{
    display:flex;align-items:center;gap:8px;margin-bottom:18px;
    flex-wrap:wrap;
}
@media(min-width:1024px){.mob-toolbar{display:none}}

.mob-filter-btn{
    display:flex;align-items:center;gap:7px;
    background:var(--white);border:1.5px solid var(--border);border-radius:10px;
    padding:9px 14px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;
    color:var(--muted);cursor:pointer;transition:all .2s;
}
.mob-filter-btn:hover,.mob-filter-btn.active{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}

.mob-sort-select{
    flex:1;min-width:140px;
    background:var(--white);border:1.5px solid var(--border);border-radius:10px;
    padding:10px 13px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;
    color:var(--ink);cursor:pointer;outline:none;transition:border-color .2s;
    appearance:none;-webkit-appearance:none;
    background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%237a8190' fill='none' stroke-width='1.5' stroke-linecap='round'/%3E%3C/svg%3E");
    background-repeat:no-repeat;background-position:right 12px center;background-size:10px;
    padding-right:32px;
}
.mob-sort-select:focus{border-color:var(--red)}

/* Contagem e view */
.content-bar{
    display:flex;align-items:center;justify-content:space-between;gap:12px;
    margin-bottom:18px;flex-wrap:wrap;
}
.content-count{
    font-family:var(--font-c);font-size:12px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--muted);
    display:flex;align-items:center;gap:7px;
}
.content-count strong{color:var(--ink)}
.count-dot{width:5px;height:5px;border-radius:50%;background:var(--red);animation:blink 1.8s infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}
.view-toggle{display:flex;gap:4px}
.vt-btn{
    width:34px;height:34px;border-radius:8px;
    background:var(--white);border:1.5px solid var(--border);
    display:flex;align-items:center;justify-content:center;
    font-size:13px;color:var(--muted);cursor:pointer;transition:all .2s;
}
.vt-btn.active,.vt-btn:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}

/* ===== PRODUCT GRID ===== */
#prodGrid{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:13px;
    transition:opacity .3s;
}
@media(min-width:540px){#prodGrid{grid-template-columns:repeat(3,1fr)}}
@media(min-width:900px){#prodGrid{grid-template-columns:repeat(4,1fr)}}
@media(min-width:1024px){#prodGrid{grid-template-columns:repeat(3,1fr)}}
@media(min-width:1280px){#prodGrid{grid-template-columns:repeat(4,1fr)}}

#prodGrid.list-view{grid-template-columns:1fr}

/* ===== PRODUCT CARD ===== */
.p-card{
    background:var(--white);border:1.5px solid var(--border);border-radius:16px;
    overflow:hidden;display:flex;flex-direction:column;
    transition:transform .38s cubic-bezier(.34,1.3,.64,1),box-shadow .38s,border-color .3s;
    position:relative;cursor:pointer;
    box-shadow:0 2px 10px rgba(0,0,0,.05);
    animation:cardIn .4s both;
}
@keyframes cardIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}

.p-card::before{
    content:'';position:absolute;left:0;top:0;bottom:0;width:3px;
    background:var(--red);z-index:2;transform:scaleY(0);transform-origin:bottom;
    transition:transform .3s cubic-bezier(.34,1.3,.64,1);
}
.p-card:hover::before{transform:scaleY(1)}
.p-card:hover{
    transform:translateY(-7px) scale(1.012);
    box-shadow:0 18px 40px -8px rgba(0,0,0,.12),0 0 0 1.5px var(--red-mid);
}

/* Imagem */
.p-img{
    width:100%;aspect-ratio:4/3;overflow:hidden;position:relative;
    background:var(--off2);flex-shrink:0;
}
.p-img::before{
    content:'';position:absolute;inset:0;z-index:1;
    background-image:
        linear-gradient(rgba(232,22,46,.05) 1px,transparent 1px),
        linear-gradient(90deg,rgba(232,22,46,.05) 1px,transparent 1px);
    background-size:24px 24px;pointer-events:none;opacity:0;transition:opacity .3s;
}
.p-card:hover .p-img::before{opacity:1}
.p-img::after{
    content:'';position:absolute;inset:0;z-index:1;
    background:linear-gradient(to bottom,transparent 45%,rgba(255,255,255,.55) 100%);
    pointer-events:none;
}
.p-img img{
    width:100%;height:100%;object-fit:cover;display:block;
    transition:transform .55s cubic-bezier(.34,1,.64,1),filter .4s;
    filter:brightness(1) saturate(.9);
}
.p-card:hover .p-img img{transform:scale(1.08);filter:brightness(1.04) saturate(1.1)}

/* Actions */
.p-actions{
    position:absolute;top:9px;right:9px;z-index:4;
    display:flex;flex-direction:column;gap:4px;
    opacity:0;transform:translateY(-6px);transition:opacity .2s,transform .2s;pointer-events:none;
}
.p-card:hover .p-actions{opacity:1;transform:translateY(0);pointer-events:auto}
.p-act-btn{
    width:28px;height:28px;border-radius:6px;
    background:rgba(255,255,255,.88);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
    border:1px solid var(--border);display:flex;align-items:center;justify-content:center;
    font-size:10px;color:var(--muted);cursor:pointer;
    transition:background .15s,color .15s,border-color .15s,transform .15s;
}
.p-act-btn:hover{background:var(--red);color:#fff;border-color:var(--red);transform:scale(1.1)}

.p-badge{
    position:absolute;bottom:9px;left:9px;z-index:3;
    display:flex;align-items:center;gap:5px;
    background:rgba(255,255,255,.92);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
    color:#4ade80;
    font-family:var(--font-c);font-size:7.5px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;
    padding:3px 8px 3px 6px;border-radius:4px;border:1px solid rgba(74,222,128,.22);
}
.p-badge::before{
    content:'';width:4px;height:4px;border-radius:50%;background:#4ade80;
    box-shadow:0 0 0 2px rgba(74,222,128,.25);flex-shrink:0;animation:blink 1.8s infinite;
}

/* Brand chips on image */
.p-brand-chip{
    position:absolute;top:9px;left:9px;z-index:3;
    background:rgba(24,28,40,.75);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
    border-radius:5px;padding:3px 8px;
    font-family:var(--font-d);font-size:10px;letter-spacing:.14em;color:rgba(255,255,255,.85);
}

/* Body */
.p-body{
    padding:12px 13px 13px;flex:1;display:flex;flex-direction:column;
    background:transparent;position:relative;
}
.p-body::before{
    content:'';position:absolute;top:0;left:0;right:0;height:1px;
    background:linear-gradient(to right,var(--red),transparent 70%);opacity:.35;
}
.p-brand-lbl{
    font-family:var(--font-d);font-size:10px;letter-spacing:.22em;text-transform:uppercase;
    color:var(--red);margin-bottom:4px;
}
.p-name{
    font-family:var(--font-c);font-size:12px;font-weight:700;text-transform:uppercase;
    letter-spacing:.04em;color:var(--ink);line-height:1.28;flex:1;
    display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;
}
.p-code{
    font-size:9px;color:var(--muted);font-weight:600;font-family:'Courier New',monospace;
    letter-spacing:.1em;margin-top:5px;display:flex;align-items:center;gap:5px;
}
.p-code::before{content:'#';font-size:9px;font-weight:700;color:var(--red);opacity:.7}
.p-btns{display:flex;gap:5px;margin-top:10px}
.p-wa{
    flex:1;height:33px;background:transparent;border:1px solid rgba(37,211,102,.4);
    border-radius:7px;color:#4ade80;
    font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;
    cursor:pointer;display:flex;align-items:center;justify-content:center;gap:5px;
    transition:background .2s,border-color .2s,color .2s,transform .15s;text-decoration:none;
}
.p-wa:hover{background:var(--wa);border-color:var(--wa);color:#fff;transform:translateY(-1px);box-shadow:0 6px 18px -4px rgba(37,211,102,.45)}
.p-wa i{font-size:12px}
.p-copy-btn{
    width:33px;height:33px;flex-shrink:0;border-radius:7px;
    background:transparent;border:1.5px solid var(--border);
    display:flex;align-items:center;justify-content:center;
    color:var(--muted);font-size:11px;cursor:pointer;transition:all .18s;
}
.p-copy-btn:hover{color:var(--red);border-color:rgba(232,22,46,.4);background:rgba(232,22,46,.08)}

/* ===== LIST VIEW CARD ===== */
#prodGrid.list-view .p-card{
    flex-direction:row;align-items:stretch;
    transform:none !important;
    border-radius:14px;
}
#prodGrid.list-view .p-card:hover{
    transform:translateX(4px) !important;
    box-shadow:var(--sh-md),0 0 0 1.5px var(--red-mid);
}
#prodGrid.list-view .p-card::before{
    top:0;left:0;right:auto;bottom:0;width:3px;height:auto;
    transform-origin:top;transform:scaleY(0);
}
#prodGrid.list-view .p-card:hover::before{transform:scaleY(1)}
#prodGrid.list-view .p-img{
    width:clamp(90px,14vw,160px);aspect-ratio:1;flex-shrink:0;border-radius:0;
}
#prodGrid.list-view .p-img::after{background:none}
#prodGrid.list-view .p-brand-chip{display:none}
#prodGrid.list-view .p-badge{display:none}
#prodGrid.list-view .p-body{padding:14px 16px;flex-direction:column;justify-content:center}
#prodGrid.list-view .p-name{-webkit-line-clamp:1;font-size:14px}
#prodGrid.list-view .p-btns{margin-top:auto;padding-top:10px}

/* ===== EMPTY STATE ===== */
.empty-state{
    grid-column:1/-1;text-align:center;padding:64px 24px;
    background:var(--white);border:1.5px solid var(--border);border-radius:20px;
}
.empty-ico{
    width:64px;height:64px;border-radius:16px;
    background:var(--red-light);border:1.5px solid var(--red-mid);
    display:flex;align-items:center;justify-content:center;
    font-size:22px;color:var(--red);margin:0 auto 18px;
}
.empty-t{font-family:var(--font-d);font-size:28px;letter-spacing:.05em;color:var(--ink);margin-bottom:8px}
.empty-s{font-size:14px;color:var(--muted);margin-bottom:20px}

/* ===== PAGINATION ===== */
.pagination{
    display:flex;align-items:center;justify-content:center;gap:6px;
    margin-top:34px;flex-wrap:wrap;
}
.pg-btn{
    min-width:38px;height:38px;padding:0 12px;border-radius:9px;
    background:var(--white);border:1.5px solid var(--border);
    display:flex;align-items:center;justify-content:center;
    font-family:var(--font-c);font-size:12px;font-weight:700;letter-spacing:.1em;
    color:var(--muted);text-decoration:none;transition:all .2s;
}
.pg-btn:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}
.pg-btn.active{background:var(--red);border-color:var(--red);color:#fff;box-shadow:var(--sh-red)}
.pg-btn.disabled{opacity:.35;pointer-events:none}
.pg-ellipsis{font-family:var(--font-c);font-size:13px;font-weight:700;color:var(--muted);padding:0 4px}
.pg-info{
    font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;
    color:var(--muted);text-align:center;margin-top:10px;
}

/* ===== MOBILE FILTER DRAWER ===== */
.drawer-overlay{
    display:none;position:fixed;inset:0;z-index:1200;
    background:rgba(0,0,0,.5);backdrop-filter:blur(4px);
}
.drawer-overlay.open{display:block}
.filter-drawer{
    position:fixed;bottom:0;left:0;right:0;z-index:1300;
    background:var(--white);border-radius:24px 24px 0 0;
    max-height:85vh;overflow-y:auto;
    transform:translateY(100%);transition:transform .38s cubic-bezier(.34,1.2,.64,1);
    padding-bottom:env(safe-area-inset-bottom,0px);
}
.filter-drawer.open{transform:translateY(0)}
.fd-handle{width:40px;height:4px;border-radius:4px;background:var(--border);margin:12px auto 18px}
.fd-title{
    font-family:var(--font-d);font-size:26px;letter-spacing:.04em;color:var(--ink);
    padding:0 20px 14px;border-bottom:1px solid var(--border);margin-bottom:0;
}
.fd-section{padding:16px 20px;border-bottom:1px solid var(--off2)}
.fd-section-t{
    font-family:var(--font-c);font-size:9px;font-weight:700;letter-spacing:.28em;text-transform:uppercase;
    color:var(--muted);margin-bottom:10px;
}
.fd-brand-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:7px}
.fd-brand-btn{
    display:flex;align-items:center;gap:8px;
    padding:10px 12px;border-radius:10px;border:1.5px solid var(--border);
    background:transparent;cursor:pointer;transition:all .2s;text-decoration:none;
}
.fd-brand-btn:hover,.fd-brand-btn.active{border-color:var(--red-mid);background:var(--red-light)}
.fd-brand-btn.active .fd-dot{background:var(--red)}
.fd-brand-btn.active .fd-bname{color:var(--red)}
.fd-dot{width:7px;height:7px;border-radius:50%;background:var(--border);flex-shrink:0;transition:background .2s}
.fd-bname{font-family:var(--font-d);font-size:16px;letter-spacing:.06em;color:var(--ink)}
.fd-sort-list{display:grid;grid-template-columns:repeat(2,1fr);gap:7px}
.fd-sort-btn{
    display:flex;align-items:center;gap:7px;
    padding:10px 12px;border-radius:10px;border:1.5px solid var(--border);
    background:transparent;cursor:pointer;transition:all .2s;font-family:var(--font-c);
    font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);
    text-decoration:none;
}
.fd-sort-btn:hover,.fd-sort-btn.active{border-color:var(--red-mid);background:var(--red-light);color:var(--red)}
.fd-actions{padding:16px 20px;display:flex;gap:10px}
.fd-clear{
    flex:1;height:46px;background:var(--off);border:1.5px solid var(--border);
    border-radius:12px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;
    color:var(--muted);cursor:pointer;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:7px;
}
.fd-apply{
    flex:2;height:46px;background:var(--red);border:none;border-radius:12px;
    font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;
    color:#fff;cursor:pointer;box-shadow:var(--sh-red);
}

/* ===== FOOTER ===== */
footer{background:var(--ink);border-top:1px solid rgba(255,255,255,.05);position:relative;overflow:hidden}
footer::before{content:'';position:absolute;top:-180px;right:-180px;width:520px;height:520px;border-radius:50%;background:radial-gradient(circle,rgba(232,22,46,.07) 0%,transparent 65%);pointer-events:none}
.ft-cta-band{background:var(--red);padding:clamp(24px,3.5vw,38px) clamp(14px,4vw,52px);display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;position:relative;z-index:1}
.ft-cta-band::before{content:'';position:absolute;inset:0;background:linear-gradient(110deg,rgba(0,0,0,.15) 0%,transparent 55%);pointer-events:none}
.ft-cta-text{position:relative;z-index:1}
.ft-cta-text h3{font-family:var(--font-d);font-size:clamp(22px,3.5vw,40px);letter-spacing:.03em;color:#fff;line-height:1;margin-bottom:5px}
.ft-cta-text p{font-family:var(--font-c);font-size:12px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.72)}
.ft-cta-actions{display:flex;gap:10px;flex-wrap:wrap;position:relative;z-index:1}
.ft-cta-btn{display:inline-flex;align-items:center;gap:7px;padding:11px 20px;border-radius:10px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.17em;text-transform:uppercase;text-decoration:none;transition:all .2s}
.ft-cta-btn.wa{background:var(--wa);color:#fff;box-shadow:var(--sh-wa)}
.ft-cta-btn.wa:hover{background:#1da851;transform:translateY(-1px)}
.ft-cta-btn.ghost{background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.28)}
.ft-cta-btn.ghost:hover{background:rgba(255,255,255,.2)}
.ft-bot{padding:16px clamp(14px,4vw,52px);max-width:1600px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:9px}
.ft-copy{font-family:var(--font-c);font-size:10px;font-weight:600;letter-spacing:.2em;text-transform:uppercase;color:rgba(255,255,255,.2)}
.ft-pow{font-family:var(--font-c);font-size:10px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:rgba(255,255,255,.13)}

/* ===== WA FAB ===== */
.wa-fab{position:fixed;bottom:26px;right:26px;z-index:9000}
.wa-btn{
    width:56px;height:56px;border-radius:50%;background:#25D366;
    display:flex;align-items:center;justify-content:center;
    font-size:25px;color:#fff;text-decoration:none;
    box-shadow:0 8px 22px rgba(37,211,102,.42),0 2px 8px rgba(0,0,0,.14);
    transition:transform .2s,box-shadow .2s;position:relative;
}
.wa-btn::before{content:'';position:absolute;inset:-4px;border-radius:50%;background:rgba(37,211,102,.24);animation:waPulse 2.2s ease-in-out 1s infinite}
@keyframes waPulse{0%,100%{transform:scale(1);opacity:1}70%{transform:scale(1.5);opacity:0}}
.wa-btn:hover{transform:scale(1.1);box-shadow:0 12px 30px rgba(37,211,102,.52)}
.wa-notif{position:absolute;top:-3px;right:-3px;width:16px;height:16px;border-radius:50%;background:var(--red);border:2px solid var(--white);font-size:8px;font-weight:900;color:#fff;display:flex;align-items:center;justify-content:center}

/* ===== TOAST ===== */
.toast{position:fixed;top:calc(var(--nav-h) + 13px);right:16px;z-index:9100;background:var(--white);border:1px solid var(--border);border-radius:13px;padding:11px 17px;display:flex;align-items:center;gap:9px;box-shadow:var(--sh-lg);font-family:var(--font-c);font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--ink);animation:tIn .4s cubic-bezier(.34,1.56,.64,1);transition:opacity .3s,transform .3s}
@keyframes tIn{from{opacity:0;transform:translateX(34px) scale(.9)}}
.toast i{color:#22c55e;font-size:15px}

/* ===== UTILS ===== */
.btn-ghost{display:inline-flex;align-items:center;gap:7px;color:var(--muted);text-decoration:none;padding:9px 15px;border-radius:9px;font-family:var(--font-c);font-size:11px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;border:1.5px solid var(--border);transition:all .2s;background:var(--white)}
.btn-ghost:hover{color:var(--red);border-color:var(--red-mid);background:var(--red-light)}

/* Loading skeleton */
.skeleton{background:linear-gradient(90deg,var(--off2) 25%,var(--border) 50%,var(--off2) 75%);background-size:200% 100%;animation:shimmer 1.4s infinite}
@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}
</style>
</head>
<body>

<!-- ===== MOBILE SEARCH ===== -->
<div class="msrch-bar" id="msrchBar">
    <input type="text" id="msrchInput" placeholder="Pesquisar peça, marca ou código..."
           value="<?php echo htmlspecialchars($q_filter); ?>"
           onkeyup="mobileSearchDebounce(this.value)">
</div>

<!-- ===== NAV ===== -->
<nav>
    <div class="nav-inner">
        <a href="/" class="nav-logo">
            <img src="img/logo_Maufu.png" alt="Maufu Peças">
            <div class="nav-logo-text">
                <span class="t1">MAUFU</span>
                <span class="t2">Peças &amp; Logística</span>
            </div>
        </a>
        <div class="nav-sep"></div>
        <span class="nav-crumb">Catálogo Completo</span>
        <div class="nav-right">
            <div class="nav-sw">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" id="srchInput" placeholder="Pesquisar peça ou código..."
                       value="<?php echo htmlspecialchars($q_filter); ?>"
                       onkeyup="desktopSearchDebounce(this.value)">
            </div>
            <button class="btn-ico msrch-btn" onclick="toggleMsrch()" aria-label="Pesquisar">
                <i class="fa-solid fa-magnifying-glass"></i>
            </button>
            <a href="/" class="btn-ico" title="Voltar ao Início" aria-label="Início">
                <i class="fa-solid fa-house"></i>
            </a>
            <a href="tel:+258848684494" class="call-btn" aria-label="Ligar agora">
                <i class="fa-solid fa-phone"></i>
                <span class="lbl">Ligar</span>
            </a>
        </div>
    </div>
</nav>

<!-- ===== CATALOG HERO ===== -->
<div class="cat-hero">
    <div class="cat-hero-inner">
        <div class="cat-hero-top">
            <div class="cat-hero-left">
                <p class="cat-hero-eyebrow">Maufu Peças, Lda</p>
                <h1 class="cat-hero-title">
                    Catálogo<br><span class="ac">Completo</span>
                </h1>
                <p class="cat-hero-sub">
                    <?php if ($marca_filter): ?>
                        Peças da marca <b><?php echo htmlspecialchars($marca_filter); ?></b>
                    <?php elseif ($q_filter): ?>
                        Resultados para <b>"<?php echo htmlspecialchars($q_filter); ?>"</b>
                    <?php else: ?>
                        <b><?php echo $total_items; ?></b> referências disponíveis · Matola A, Moçambique
                    <?php endif; ?>
                </p>
            </div>
            <div class="cat-hero-stats">
                <div class="ch-stat">
                    <span class="ch-stat-val"><?php echo $total_items; ?><span>+</span></span>
                    <span class="ch-stat-lbl">Referências</span>
                </div>
                <div class="ch-stat">
                    <span class="ch-stat-val"><?php echo count($marcas_list); ?></span>
                    <span class="ch-stat-lbl">Marcas</span>
                </div>
                <div class="ch-stat">
                    <span class="ch-stat-val">24<span>h</span></span>
                    <span class="ch-stat-lbl">Entrega</span>
                </div>
            </div>
        </div>

        <?php if ($marca_filter || $q_filter): ?>
        <div class="active-filters">
            <span class="af-label">Filtros:</span>
            <?php if ($marca_filter): ?>
            <a href="catalogo.php<?php echo $q_filter ? '?q='.urlencode($q_filter) : ''; ?>" class="af-chip">
                <i class="fa-solid fa-tag"></i> <?php echo htmlspecialchars($marca_filter); ?> <i class="fa-solid fa-xmark"></i>
            </a>
            <?php endif; ?>
            <?php if ($q_filter): ?>
            <a href="catalogo.php<?php echo $marca_filter ? '?marca='.urlencode($marca_filter) : ''; ?>" class="af-chip">
                <i class="fa-solid fa-magnifying-glass"></i> <?php echo htmlspecialchars($q_filter); ?> <i class="fa-solid fa-xmark"></i>
            </a>
            <?php endif; ?>
            <a href="catalogo.php" class="af-chip" style="background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.15);color:rgba(255,255,255,.45)">
                Limpar tudo <i class="fa-solid fa-xmark"></i>
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- ===== MAIN LAYOUT ===== -->
<div class="catalog-wrap">

    <!-- ===== SIDEBAR ===== -->
    <aside class="sidebar">

        <!-- Pesquisa -->
        <div class="sb-section">
            <p class="sb-title">Pesquisar</p>
            <div class="sb-search">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" id="sbSearchInput" placeholder="Peça, marca, código..."
                       value="<?php echo htmlspecialchars($q_filter); ?>"
                       onkeyup="desktopSearchDebounce(this.value)">
            </div>
        </div>

        <!-- Marcas -->
        <div class="sb-section">
            <p class="sb-title">Marca</p>
            <div class="sb-brand-list">
                <a href="catalogo.php<?php echo $q_filter ? '?q='.urlencode($q_filter) : ''; ?><?php echo $sort !== 'recente' ? ($q_filter ? '&' : '?').'sort='.$sort : ''; ?>"
                   class="sb-brand-btn <?php echo !$marca_filter ? 'active' : ''; ?>">
                    <div class="sb-brand-left">
                        <div class="sb-brand-dot"></div>
                        <span class="sb-brand-name">Todas</span>
                    </div>
                    <span class="sb-brand-qty"><?php echo array_sum(array_column($marcas_list, 'qty')); ?></span>
                </a>
                <?php foreach ($marcas_list as $m): ?>
                <?php
                $href_params = [];
                if ($m['marca']) $href_params['marca'] = $m['marca'];
                if ($q_filter)   $href_params['q'] = $q_filter;
                if ($sort !== 'recente') $href_params['sort'] = $sort;
                $href = 'catalogo.php' . ($href_params ? '?' . http_build_query($href_params) : '');
                $is_active = $marca_filter === $m['marca'];
                ?>
                <a href="<?php echo $href; ?>" class="sb-brand-btn <?php echo $is_active ? 'active' : ''; ?>">
                    <div class="sb-brand-left">
                        <div class="sb-brand-dot"></div>
                        <span class="sb-brand-name"><?php echo htmlspecialchars($m['marca']); ?></span>
                    </div>
                    <span class="sb-brand-qty"><?php echo $m['qty']; ?></span>
                </a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Ordenação -->
        <div class="sb-section">
            <p class="sb-title">Ordenar Por</p>
            <div class="sb-sort-list">
                <?php
                $sorts = [
                    'recente' => ['label'=>'Mais Recente',  'icon'=>'fa-clock'],
                    'az'      => ['label'=>'A → Z',         'icon'=>'fa-arrow-down-a-z'],
                    'za'      => ['label'=>'Z → A',         'icon'=>'fa-arrow-up-z-a'],
                    'marca'   => ['label'=>'Por Marca',     'icon'=>'fa-tag'],
                ];
                foreach ($sorts as $k => $s):
                    $sp = [];
                    if ($marca_filter) $sp['marca'] = $marca_filter;
                    if ($q_filter) $sp['q'] = $q_filter;
                    if ($k !== 'recente') $sp['sort'] = $k;
                    $shref = 'catalogo.php' . ($sp ? '?' . http_build_query($sp) : '');
                ?>
                <a href="<?php echo $shref; ?>" class="sb-sort-btn <?php echo $sort === $k ? 'active' : ''; ?>">
                    <i class="fa-solid <?php echo $s['icon']; ?>"></i>
                    <?php echo $s['label']; ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Limpar -->
        <div class="sb-section">
            <a href="catalogo.php" class="sb-clear">
                <i class="fa-solid fa-rotate-left"></i> Limpar Filtros
            </a>
        </div>

    </aside>

    <!-- ===== MAIN ===== -->
    <div class="main-content">

        <!-- Mobile toolbar -->
        <div class="mob-toolbar">
            <button class="mob-filter-btn" onclick="openDrawer()" id="filterBtn">
                <i class="fa-solid fa-sliders"></i> Filtrar
                <?php if ($marca_filter): ?>
                <span style="background:var(--red);color:#fff;border-radius:50%;width:16px;height:16px;display:inline-flex;align-items:center;justify-content:center;font-size:9px;margin-left:2px">1</span>
                <?php endif; ?>
            </button>
            <select class="mob-sort-select" onchange="applyMobSort(this.value)">
                <option value="recente" <?php echo $sort==='recente'?'selected':''; ?>>Mais Recente</option>
                <option value="az" <?php echo $sort==='az'?'selected':''; ?>>A → Z</option>
                <option value="za" <?php echo $sort==='za'?'selected':''; ?>>Z → A</option>
                <option value="marca" <?php echo $sort==='marca'?'selected':''; ?>>Por Marca</option>
            </select>
            <div class="view-toggle" style="margin-left:auto">
                <button class="vt-btn active" id="gridBtn" onclick="setView('grid')" title="Grelha" aria-label="Vista grelha">
                    <i class="fa-solid fa-grid-2"></i>
                </button>
                <button class="vt-btn" id="listBtn" onclick="setView('list')" title="Lista" aria-label="Vista lista">
                    <i class="fa-solid fa-list"></i>
                </button>
            </div>
        </div>

        <!-- Content bar -->
        <div class="content-bar">
            <div class="content-count">
                <span class="count-dot"></span>
                <strong><?php echo $total_items; ?></strong> resultado<?php echo $total_items !== 1 ? 's' : ''; ?>
                <?php if ($marca_filter): ?> · <?php echo htmlspecialchars($marca_filter); ?><?php endif; ?>
                <?php if ($total_pages > 1): ?> · Pág. <?php echo $page; ?>/<?php echo $total_pages; ?><?php endif; ?>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
                <div class="view-toggle" style="display:none" id="desktopViewToggle">
                    <button class="vt-btn active" id="gridBtnD" onclick="setView('grid')" title="Grelha" aria-label="Vista grelha">
                        <i class="fa-solid fa-grid-2"></i>
                    </button>
                    <button class="vt-btn" id="listBtnD" onclick="setView('list')" title="Lista" aria-label="Vista lista">
                        <i class="fa-solid fa-list"></i>
                    </button>
                </div>
                <?php if ($q_filter || $marca_filter): ?>
                <a href="catalogo.php" class="btn-ghost">
                    <i class="fa-solid fa-rotate-left"></i> Limpar
                </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- ===== PRODUCT GRID ===== -->
        <div id="prodGrid">
            <?php if (empty($produtos)): ?>
            <div class="empty-state">
                <div class="empty-ico"><i class="fa-solid fa-magnifying-glass"></i></div>
                <h3 class="empty-t">Sem Resultados</h3>
                <p class="empty-s">
                    <?php if ($q_filter): ?>
                        Nenhuma peça encontrada para "<?php echo htmlspecialchars($q_filter); ?>".
                    <?php else: ?>
                        Nenhum produto disponível com os filtros selecionados.
                    <?php endif; ?>
                </p>
                <a href="catalogo.php" class="btn-ghost"><i class="fa-solid fa-rotate-left"></i> Ver todos os produtos</a>
            </div>
            <?php else: ?>
            <?php foreach ($produtos as $i => $p): ?>
            <?php
                $fotos   = array_filter(explode(',', $p['imagem_url']));
                $img     = !empty($fotos) ? reset($fotos) : '';
                $nome    = mb_strtoupper($p['nome']);
                $marca   = mb_strtoupper($p['marca']);
                $codigo  = $p['codigo'];
                $delay   = min($i * 40, 400);
            ?>
            <div class="p-card" style="animation-delay:<?php echo $delay; ?>ms"
                 onclick="window.location='detalhes.php?id=<?php echo $p['id']; ?>'">
                <div class="p-img">
                    <?php if ($marca): ?>
                    <div class="p-brand-chip"><?php echo htmlspecialchars($marca); ?></div>
                    <?php endif; ?>
                    <div class="p-badge">Disponível</div>
                    <div class="p-actions">
                        <button class="p-act-btn" title="Partilhar" onclick="shareProduct(<?php echo $p['id']; ?>, event)">
                            <i class="fa-solid fa-share-nodes"></i>
                        </button>
                        <button class="p-act-btn" title="Copiar info" onclick="copyProduct(<?php echo $p['id']; ?>, event)">
                            <i class="fa-solid fa-copy"></i>
                        </button>
                    </div>
                    <img src="<?php echo htmlspecialchars($img); ?>"
                         alt="<?php echo htmlspecialchars($nome); ?>"
                         loading="<?php echo $i < 8 ? 'eager' : 'lazy'; ?>"
                         onerror="this.src='https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&q=80&w=600'">
                </div>
                <div class="p-body">
                    <?php if ($marca): ?><p class="p-brand-lbl"><?php echo htmlspecialchars($marca); ?></p><?php endif; ?>
                    <h4 class="p-name"><?php echo htmlspecialchars($nome); ?></h4>
                    <?php if ($codigo): ?><p class="p-code"><?php echo htmlspecialchars($codigo); ?></p><?php endif; ?>
                    <div class="p-btns">
                        <button class="p-wa" onclick="event.stopPropagation();contactWA(<?php echo $p['id']; ?>)">
                            <i class="fa-brands fa-whatsapp"></i>Contactar
                        </button>
                        <button class="p-copy-btn" title="Copiar" onclick="copyProduct(<?php echo $p['id']; ?>, event)">
                            <i class="fa-solid fa-copy"></i>
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- ===== PAGINATION ===== -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php
            // Prev
            $prevPage = $page - 1;
            $prevHref = $prevPage >= 1 ? buildUrl(['page' => $prevPage]) : '#';
            ?>
            <a href="<?php echo $prevHref; ?>" class="pg-btn <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                <i class="fa-solid fa-chevron-left"></i>
            </a>
            <?php
            // Page numbers
            $range = 2;
            for ($i = 1; $i <= $total_pages; $i++):
                if ($i === 1 || $i === $total_pages || ($i >= $page - $range && $i <= $page + $range)):
            ?>
            <a href="<?php echo buildUrl(['page' => $i]); ?>"
               class="pg-btn <?php echo $i === $page ? 'active' : ''; ?>">
                <?php echo $i; ?>
            </a>
            <?php
                elseif ($i === $page - $range - 1 || $i === $page + $range + 1):
            ?>
            <span class="pg-ellipsis">···</span>
            <?php
                endif;
            endfor;
            ?>
            <?php
            $nextPage = $page + 1;
            $nextHref = $nextPage <= $total_pages ? buildUrl(['page' => $nextPage]) : '#';
            ?>
            <a href="<?php echo $nextHref; ?>" class="pg-btn <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                <i class="fa-solid fa-chevron-right"></i>
            </a>
        </div>
        <p class="pg-info">Página <?php echo $page; ?> de <?php echo $total_pages; ?> · <?php echo $total_items; ?> resultados</p>
        <?php endif; ?>

    </div><!-- /main-content -->
</div><!-- /catalog-wrap -->

<!-- ===== FOOTER ===== -->
<footer>
    <div class="ft-cta-band">
        <div class="ft-cta-text">
            <h3>Precisa de uma Peça?</h3>
            <p>Fale connosco agora — resposta imediata</p>
        </div>
        <div class="ft-cta-actions">
            <a href="https://wa.me/258848684494?text=Olá%2C%20vim%20do%20catálogo%20Maufu%20Peças%20e%20preciso%20de%20ajuda." class="ft-cta-btn wa" target="_blank" rel="noopener">
                <i class="fa-brands fa-whatsapp"></i> WhatsApp
            </a>
            <a href="tel:+258848684494" class="ft-cta-btn ghost">
                <i class="fa-solid fa-phone"></i> Ligar Agora
            </a>
        </div>
    </div>
    <div class="ft-bot">
        <p class="ft-copy">© 2026 Maufu Peças, Lda. Todos os direitos reservados.</p>
        <p class="ft-pow">Powered by Primavera BSS</p>
    </div>
</footer>

<!-- ===== WA FAB ===== -->
<div class="wa-fab">
    <a href="https://wa.me/258848684494?text=Olá%2C%20vim%20do%20catálogo%20Maufu%20Peças%20e%20gostaria%20de%20informações."
       class="wa-btn" target="_blank" rel="noopener" aria-label="WhatsApp">
        <i class="fa-brands fa-whatsapp"></i>
        <span class="wa-notif">1</span>
    </a>
</div>

<!-- ===== MOBILE FILTER DRAWER ===== -->
<div class="drawer-overlay" id="drawerOverlay" onclick="closeDrawer()"></div>
<div class="filter-drawer" id="filterDrawer">
    <div class="fd-handle"></div>
    <h2 class="fd-title">Filtrar</h2>

    <div class="fd-section">
        <p class="fd-section-t">Marca</p>
        <div class="fd-brand-grid">
            <a href="catalogo.php<?php echo $q_filter ? '?q='.urlencode($q_filter) : ''; ?><?php echo $sort !== 'recente' ? ($q_filter ? '&' : '?').'sort='.$sort : ''; ?>"
               class="fd-brand-btn <?php echo !$marca_filter ? 'active' : ''; ?>">
                <div class="fd-dot"></div>
                <span class="fd-bname">Todas</span>
            </a>
            <?php foreach ($marcas_list as $m):
                $fp = [];
                if ($m['marca']) $fp['marca'] = $m['marca'];
                if ($q_filter)   $fp['q'] = $q_filter;
                if ($sort !== 'recente') $fp['sort'] = $sort;
                $fhref = 'catalogo.php' . ($fp ? '?' . http_build_query($fp) : '');
            ?>
            <a href="<?php echo $fhref; ?>" class="fd-brand-btn <?php echo $marca_filter === $m['marca'] ? 'active' : ''; ?>">
                <div class="fd-dot"></div>
                <span class="fd-bname"><?php echo htmlspecialchars($m['marca']); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="fd-section">
        <p class="fd-section-t">Ordenar Por</p>
        <div class="fd-sort-list">
            <?php foreach ($sorts as $k => $s):
                $sp2 = [];
                if ($marca_filter) $sp2['marca'] = $marca_filter;
                if ($q_filter) $sp2['q'] = $q_filter;
                if ($k !== 'recente') $sp2['sort'] = $k;
                $shref2 = 'catalogo.php' . ($sp2 ? '?' . http_build_query($sp2) : '');
            ?>
            <a href="<?php echo $shref2; ?>" class="fd-sort-btn <?php echo $sort === $k ? 'active' : ''; ?>">
                <i class="fa-solid <?php echo $s['icon']; ?>"></i>
                <?php echo $s['label']; ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="fd-actions">
        <a href="catalogo.php" class="fd-clear"><i class="fa-solid fa-rotate-left"></i> Limpar</a>
        <button class="fd-apply" onclick="closeDrawer()">Aplicar Filtros</button>
    </div>
</div>

<script>
const products = <?php echo json_encode($produtos_json); ?>;
const WA_NUM   = '258848684494';
const SITE_URL = window.location.origin + '/catalogo.php';

/* ── Desktop view toggle ────────────────────────────── */
if (window.innerWidth >= 1024) {
    document.getElementById('desktopViewToggle').style.display = 'flex';
}

/* ── View toggle ─────────────────────────────────────── */
let currentView = localStorage.getItem('catalogView') || 'grid';
function setView(v) {
    currentView = v;
    localStorage.setItem('catalogView', v);
    const grid = document.getElementById('prodGrid');
    grid.classList.toggle('list-view', v === 'list');
    ['gridBtn','gridBtnD'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.classList.toggle('active', v === 'grid');
    });
    ['listBtn','listBtnD'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.classList.toggle('active', v === 'list');
    });
}
setView(currentView);

/* ── Mobile search ───────────────────────────────────── */
let mOpen = false;
function toggleMsrch() {
    mOpen = !mOpen;
    document.getElementById('msrchBar').classList.toggle('open', mOpen);
    if (mOpen) document.getElementById('msrchInput').focus();
}

/* ── Search debounce ─────────────────────────────────── */
let searchTimer;
function desktopSearchDebounce(val) {
    document.getElementById('srchInput').value = val;
    document.getElementById('sbSearchInput') && (document.getElementById('sbSearchInput').value = val);
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => navigateWithSearch(val), 500);
}
function mobileSearchDebounce(val) {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => navigateWithSearch(val), 600);
}
function navigateWithSearch(val) {
    const url = new URL(window.location.href);
    if (val.trim()) {
        url.searchParams.set('q', val.trim());
    } else {
        url.searchParams.delete('q');
    }
    url.searchParams.delete('page');
    window.location.href = url.toString();
}

/* ── Mobile sort ─────────────────────────────────────── */
function applyMobSort(val) {
    const url = new URL(window.location.href);
    if (val && val !== 'recente') {
        url.searchParams.set('sort', val);
    } else {
        url.searchParams.delete('sort');
    }
    url.searchParams.delete('page');
    window.location.href = url.toString();
}

/* ── Filter drawer ───────────────────────────────────── */
function openDrawer() {
    document.getElementById('drawerOverlay').classList.add('open');
    document.getElementById('filterDrawer').classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeDrawer() {
    document.getElementById('drawerOverlay').classList.remove('open');
    document.getElementById('filterDrawer').classList.remove('open');
    document.body.style.overflow = '';
}

/* ── WhatsApp contact ────────────────────────────────── */
function contactWA(id) {
    const p = products.find(x => x.id == id);
    if (!p) return;
    let imgUrl = p.img || '';
    if (imgUrl && !imgUrl.startsWith('http')) imgUrl = window.location.origin + '/' + imgUrl.replace(/^\//, '');
    const imgLine = imgUrl ? `%0A%F0%9F%93%B8 *Imagem:* ${encodeURIComponent(imgUrl)}` : '';
    const msg = `Olá! Tenho interesse na seguinte peça:%0A%0A` +
                `%F0%9F%94%A7 *Nome:* ${encodeURIComponent(p.name)}%0A` +
                `%F0%9F%8F%AD *Marca:* ${encodeURIComponent(p.brand)}%0A` +
                `%F0%9F%94%96 *Referência:* ${p.code ? encodeURIComponent('#' + p.code) : 'N/D'}` +
                imgLine + `%0A%0APoderia informar disponibilidade e preço?`;
    window.open(`https://wa.me/${WA_NUM}?text=${msg}`, '_blank', 'noopener');
}

/* ── Copy product ────────────────────────────────────── */
function copyProduct(id, e) {
    if (e) e.stopPropagation();
    const p = products.find(x => x.id == id);
    if (!p) return;
    const txt = `${p.name} | Marca: ${p.brand}${p.code ? ' | Ref: #' + p.code : ''}\nVer em: ${SITE_URL}?produto=${p.id}\nContacto: +258 84 868 4494`;
    navigator.clipboard.writeText(txt).then(() => showToast('Copiado para a área de transferência!')).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
        showToast('Copiado!');
    });
}

/* ── Share product ───────────────────────────────────── */
function shareProduct(id, e) {
    if (e) e.stopPropagation();
    const p = products.find(x => x.id == id);
    if (!p) return;
    const shareData = { title: p.name + ' — Maufu Peças', text: `${p.name} | ${p.brand}${p.code ? ' | Ref: #' + p.code : ''}`, url: `${SITE_URL}?produto=${p.id}` };
    if (navigator.share) navigator.share(shareData).catch(() => {});
    else navigator.clipboard.writeText(shareData.url).then(() => showToast('Link copiado para partilhar!')).catch(() => {});
}

/* ── Toast ───────────────────────────────────────────── */
function showToast(msg) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = `<i class="fa-solid fa-circle-check"></i>${msg}`;
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(34px)'; setTimeout(() => t.remove(), 350); }, 3000);
}

/* ── Keyboard shortcuts ──────────────────────────────── */
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { if (mOpen) toggleMsrch(); closeDrawer(); }
    if (e.key === '/' && !['INPUT','TEXTAREA'].includes(document.activeElement.tagName)) {
        e.preventDefault();
        const si = document.getElementById('srchInput');
        if (si) { si.focus(); si.select(); }
    }
});

/* ── Card animation stagger fix ─────────────────────── */
document.querySelectorAll('.p-card').forEach((card, i) => {
    card.style.animationDelay = Math.min(i * 40, 400) + 'ms';
});
</script>
</body>
</html>